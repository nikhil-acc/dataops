import pytest
import json
import warnings
import filecmp
import os 

warnings.filterwarnings("ignore", category=DeprecationWarning)

from google.cloud import storage

@pytest.fixture(scope="module")
def remote_state(pytestconfig):
    # get terrafrom state bucket and prefix
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')
    
    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    # filter and return only object resource
    for resource in resources:
        if resource["type"] == "google_storage_bucket_object":
            return resource
    return

def test_object_exists(remote_state):
    # get bucket and object name from state file
    bucket_name = remote_state["instances"][0]["attributes"]["bucket"]
    file = remote_state["instances"][0]["attributes"]["name"]

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    # check that object exists
    assert storage.Blob(bucket=bucket, name=file).exists(storage_client)
    
def test_object_integrity(remote_state):
    # get bucket and object name from state file
    bucket_name = remote_state["instances"][0]["attributes"]["bucket"]
    file = remote_state["instances"][0]["attributes"]["name"]

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    # download object to temp file
    storage.Blob(bucket=bucket, name=file).download_to_filename("./object")
    dir_path = os.path.dirname(os.path.realpath(__file__))
    # check that downloaded object is identical to the original file
    assert filecmp.cmp("./object",dir_path.replace("test","https_to_gcs/latest.zip"))