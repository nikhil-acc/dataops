# datapltf-https-to-gcs-module

The purpose of this module is to get single binary file from https source protected by bearer token and push it to GCS bucket.

## Variables

All variables are mandatory and have no default values.

| Variable | Description |
| -------- | ----------- |
| `access_token` | Bearer access token for https source. |
| `source_url` | Source url to get binary file. |
| `target_bucket` | Bucket where the target object is created. |
| `target_object` | Object name to be created in the bucket. You can specify the full path including prefix. |

## Known issues and limitations

Terraform can't handle binary data passed in a variable from one resource to another. That's the reason we can't get content downloaded by `http` data source and push it directly to storage object. The content has to be converted to base64 since GCS storage object resource doesn't accept binary data. We have to save content as a local file and then push it to the bucket. As a result there are two unfortunate consequences:

- `http` data source raises a warning that data is binary and not UTF-8: `Response body is not recognized as UTF-8`.
- `local_sensitive_file` is recreated on each execution, even is there are no changes to the source file. Object in the bucket remains unchanged unless there is an actual update to the source.