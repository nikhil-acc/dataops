-- SELECT 1 AS c1
SELECT * from `${project}.${dataset}.table_with_partition` LIMIT 10;
