"""
Description : DAG to create the dataproc serverless for scala job
Author: Nikhil
Date : 13/06/2024
Modified Date : 
Usage: DAG file and config.yaml will be placed in the dags folder"""

import os
from datetime import timedelta, datetime
# ****************************************************
# STEP 1 - Importing necessary libraries
# *****************************************************
import airflow
import yaml
from airflow import DAG, models
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.google.cloud.operators.dataproc import (
    DataprocCreateBatchOperator,
    DataprocDeleteBatchOperator,
    DataprocGetBatchOperator,
    DataprocListBatchesOperator,
)

# ****************************************************
# STEP 2 - Default Parameters
# *****************************************************
default_args = {
    "owner": "test-prj-gcp-edp-npe",
    "depends_on_past": False,
    "start_date": airflow.utils.dates.days_ago(1),
    "email": ["Your email address"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

timestamp = datetime.now().strftime("%Y%m%d%H")

# ****************************************************
# STEP 3 - Define DAG properties: ID, defaults and schedule
# *****************************************************
dir_path = os.path.dirname(os.path.abspath(__file__))
config_file_path = os.path.join(dir_path, "config.yaml")
with open(config_file_path) as yaml_file:
    configuration = yaml.safe_load(yaml_file)

    print(configuration["config"]["network_project_id"])
    print(configuration["config"]["cluster_project_id"])
    print(configuration["config"]["airflow_project_id"])
    print(configuration["config"]["region"])
    print(configuration["config"]["jar_file_path"])
    print(configuration["config"]["jar_file_name"])
    print(configuration["config"]["jar_main_class"])
    print(timestamp)

network_project_id = configuration["config"]["network_project_id"]
cluster_project_id = configuration["config"]["cluster_project_id"]
airflow_project_id = configuration["config"]["airflow_project_id"]
region = configuration["config"]["region"]
jar_file_path = configuration["config"]["jar_file_path"]
jar_file_name = configuration["config"]["jar_file_name"]
jar_bucket    = configuration["config"]["jar_bucket"]
jar_main_class = configuration["config"]["jar_main_class"]
cluster_name = configuration["config"]["cluster_name"]
dataproc_sa = configuration["config"]["dataproc_sa"]
subnet = configuration["config"]["subnet"]
batch_id = f"batch-creates-{cluster_name}-{timestamp}"
jar_file_uris = [f"gs://{jar_bucket}/{jar_file_path}/{jar_file_name}"]
batch_config = {
    "spark_batch": {
        "main_class": jar_main_class,
        "jar_file_uris": jar_file_uris,
    },
    "environment_config": {
        "execution_config": {
            "service_account": dataproc_sa,
            "subnetwork_uri": f"projects/{network_project_id}/regions/{region}/subnetworks/{subnet}",
             "network_tags": ["dataproc"],
        },
    },
}

with DAG(
    "dataproc_serverless_batch_scala_withconfig",
    schedule_interval=timedelta(days=1),
    template_searchpath=["/home/airflow/gcs/data/"],
    max_active_runs=1,
    catchup=True,
    default_args=default_args,
) as dag:

    start_pipeline = DummyOperator(task_id="start_pipeline", dag=dag)
    create_batch = DataprocCreateBatchOperator(
        task_id="batch_create",
        project_id=cluster_project_id,
        region=region,
        gcp_conn_id = cluster_project_id,
        batch=batch_config,
        batch_id=batch_id,
        dag=dag,
    )

    list_batches = DataprocListBatchesOperator(task_id="list_all_batches", project_id=cluster_project_id, region=region, gcp_conn_id = cluster_project_id, dag=dag
    )

    get_batch = DataprocGetBatchOperator(
        task_id="get_batch", batch_id=batch_id, project_id=cluster_project_id, region=region, gcp_conn_id = cluster_project_id, dag=dag
    )

    delete_batch = DataprocDeleteBatchOperator(
        task_id="delete_batch", batch_id=batch_id, project_id=cluster_project_id, region=region, gcp_conn_id = cluster_project_id, dag=dag
    )

# Task dependencies
start_pipeline >> create_batch >> list_batches >> get_batch >> delete_batch
