"""
Example tests for the validation script.

Run it with this from repo root:
( cd test/df/pythonflow/ && python3 -munittest validation_test.py; )
"""

import unittest

from validation import job_has_output_bucket


class ValidationTests(unittest.TestCase):
    def test_job_has_output_bucket_is_required(self):
        errors = list(job_has_output_bucket({}))
        assert len(errors) == 1

    def test_job_has_output_bucket_bad_name_format(self):
        errors = list(job_has_output_bucket({"outputBucket": "invalid-bucket-name"}))
        assert len(errors) == 1
