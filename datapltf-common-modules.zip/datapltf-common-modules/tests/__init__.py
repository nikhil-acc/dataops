import json
import os
import shlex
import subprocess
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from textwrap import dedent
from typing import (
    cast,
    Dict,
    Iterator,
    Literal,
    NotRequired,
    overload,
    Tuple,
    TypedDict,
    Unpack,
)


TESTS_DIR = Path(__file__).parent
UNIT_TESTS_DIR = TESTS_DIR / "unit"
FUNCTIONAL_TESTS_DIR = TESTS_DIR / "functional"
INTEGRATION_TESTS_DIR = TESTS_DIR / "integration"
REPO_ROOT = TESTS_DIR.parent
VALIDATION_RUNNER_PY = REPO_ROOT / "validation_runner.py"
NO_CLEANUP = os.environ.get("NO_CLEANUP", "f").lower() in ["t", "true", "1"]
CLEANUP = not NO_CLEANUP

assert (
    VALIDATION_RUNNER_PY.exists()
), f"Test setup is broken, could not find {VALIDATION_RUNNER_PY.name} script."


@contextmanager
def tmp_dir_path() -> Iterator[Path]:
    tmp_dir = TemporaryDirectory()
    yield Path(tmp_dir.name)
    if CLEANUP:
        tmp_dir.cleanup()


def assert_output(expected: str, actual: str, msg: str | None = None):
    expected = expected.strip()
    actual = dedent(actual).strip()
    if msg:
        assert expected == actual, msg
    else:
        assert expected == actual


def sh_quoted_json(thing) -> str:
    return shlex.quote(json.dumps(thing).replace("\\", "\\\\"))


def print_out(out: str, err: str):
    print(f"--- START_ERROR ---\n{err}\n--- END_ERROR ---\n")
    print(f"--- START_OUTPUT ---\n{out}\n--- END_OUTPUT ---\n")


PathLike = str | Path


class TerraformGlobalKwargs(TypedDict):
    chdir: NotRequired[PathLike]


class TerraformInitKwargs(TerraformGlobalKwargs):
    no_color: NotRequired[bool]
    upgrade: NotRequired[bool]


TerraformVars = Dict[str, str]


class TerraformPlanKwargs(TerraformGlobalKwargs):
    vars: NotRequired[TerraformVars]
    destroy: NotRequired[bool]
    no_color: NotRequired[bool]


class TerraformApplyKwargs(TerraformGlobalKwargs):
    vars: NotRequired[TerraformVars]
    destroy: NotRequired[bool]
    auto_approve: NotRequired[bool]
    no_color: NotRequired[bool]


class TerraformOutputKwargs(TerraformGlobalKwargs):
    no_color: NotRequired[bool]
    json: NotRequired[bool]
    state: NotRequired[PathLike]


TerraformCliKwargs = (
    TerraformInitKwargs
    | TerraformPlanKwargs
    | TerraformApplyKwargs
    | TerraformOutputKwargs
)

# def to_terraform_cli_options(options: Dict[str, str | bool, TerraformVars]) -> Iterator[str]:


def to_terraform_cli_options(options: TerraformCliKwargs) -> Iterator[str]:
    """Convert to terraform cli options terraform() kwargs."""
    for name, value in options.items():
        option_name = f'-{name.replace("_", "-")}'
        if isinstance(value, bool):
            yield option_name
        elif isinstance(value, str) or isinstance(value, Path):
            yield f"{option_name}={value}"
        elif isinstance(value, dict):
            for var_name, var_value in value.items():
                yield f"-var={var_name}={var_value}"
        else:
            raise ValueError(f"Unsupported value: {repr(value)}")


@overload
def terraform(
    subcommand: Literal["init"], **kw: Unpack[TerraformInitKwargs]
) -> Tuple[int, str, str]: ...
@overload
def terraform(
    subcommand: Literal["plan"], **kw: Unpack[TerraformPlanKwargs]
) -> Tuple[int, str, str]: ...
@overload
def terraform(
    subcommand: Literal["apply"], **kw: Unpack[TerraformApplyKwargs]
) -> Tuple[int, str, str]: ...
@overload
def terraform(
    subcommand: Literal["output"], **kw: Unpack[TerraformOutputKwargs]
) -> Tuple[int, str, str]: ...
def terraform(subcommand: str, **kw) -> Tuple[int, str, str]:
    """Run terraform commands."""
    command_line = ["terraform"]
    if "chdir" in kw:
        command_line.append(f"-chdir={kw['chdir']}")
        del kw["chdir"]
    command_line.append(subcommand)
    command_line.extend(to_terraform_cli_options(cast(TerraformCliKwargs, kw)))
    if os.environ.get("VERBOSE", "f").lower() in ["t", "true", "1"]:
        print(command_line)
    cp = subprocess.run(
        command_line, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    return cp.returncode, cp.stdout, cp.stderr


class Workspace:
    """A terraform root workspace on which to run CLI commands."""

    def __init__(self, dest_dir: Path):
        self.dest_dir = dest_dir

    def init(self):
        return terraform("init", chdir=self.dest_dir, no_color=True)

    def ensure_init(self):
        """"""
        _terraform = self.dest_dir / ".terraform"
        _terraform_lock = self.dest_dir / ".terraform.lock.hcl"
        if _terraform.is_dir() and _terraform_lock.is_file():
            return False
        status, out, err = self.init()
        if status != 0:
            raise RuntimeError(
                f"terraform init failed with exit code [{status}]\nSTDOUT\n{out}\nSTDERR\n{err}"
            )
        return True

    def plan(self, **kw: Unpack[TerraformPlanKwargs]):
        kw["chdir"] = self.dest_dir
        kw["no_color"] = True
        return terraform("plan", **kw)

    def apply(self, **kw: Unpack[TerraformApplyKwargs]):
        kw["chdir"] = self.dest_dir
        kw["no_color"] = True
        return terraform("apply", **kw)

    def output(self, **kw: Unpack[TerraformOutputKwargs]):
        kw["chdir"] = self.dest_dir
        kw["no_color"] = True
        return terraform("output", **kw)


@contextmanager
def WorkspaceFixture(*, main_tf: str) -> Iterator[Workspace]:
    """Create a temporary workspace given the TF code in main_tf."""
    with tmp_dir_path() as tmpdir:
        (tmpdir / "main.tf").write_text(main_tf)
        yield Workspace(tmpdir)


def tf_vars_from_env(other_vars: TerraformVars) -> TerraformVars:
    """Create variables by pulling defaults from environment variables when available."""
    all_vars: TerraformVars = {}
    if "USE_CASE" in os.environ:
        all_vars["use_case"] = os.environ["USE_CASE"]
    all_vars.update(other_vars)
    return all_vars
