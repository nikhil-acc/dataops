import json
from pathlib import Path
from textwrap import dedent
from typing import List

import pytest

from hypothesis import example, given, settings

from tests import assert_output, sh_quoted_json, tmp_dir_path
from tests.functional import parse_output, sh_echo, validation_runner
from tests.strategies import validation_error_lists


def test_script_non_zero_exit():
    error_message = "An error occurred!"
    script = dedent(
        f"""#!/bin/sh
                       echo "{error_message}" >&2
                       exit 1"""
    )
    exitcode, out, err = validation_runner(script, "", "")
    assert exitcode != 0
    assert_output(
        err,
        """
                The validation script exited with non-zero exit code [1].
                STDOUT:
                
                STDERR:
                An error occurred!""",
    )
    assert out == ""


def test_sh_echo():
    assert sh_echo("hi") == "hi\n"


def test_sh_quoted_json():
    thing = ["000\n000000"]
    echo_out = sh_echo(sh_quoted_json(thing))
    print(f"echo_out={repr(echo_out)}")
    assert json.loads(echo_out) == thing


@given(validation_errors=validation_error_lists)
@example(["000\r000000"])
@settings(deadline=None)
def test_validation_errors(validation_errors: List[str]):
    script = dedent(
        f"""#!/bin/sh
                    echo {sh_quoted_json(validation_errors)}
                    """
    )
    with tmp_dir_path() as tmp_dir:
        exitcode, out, err = validation_runner(script, "", "", tmp_dir=tmp_dir)
    assert exitcode == 0, err
    assert parse_output(out) == validation_errors


@pytest.mark.parametrize(
    "bad_script",
    [
        ("#!/usr/bin/env aflkjaf;kajs;fdka;sf"),
        ("#!/bin/sh\nexit 3"),
        ("#!/usr/bin/env python3\nraise Exception('error')"),
    ],
)
def test_script_failure(tmp_dir: Path, bad_script: str):
    exitcode, out, err = validation_runner(bad_script, "", "", tmp_dir=tmp_dir)
    print(err)
    assert exitcode == 2
    assert out == ""
    assert err != ""


def test_unexpected_errors(tmp_dir: Path):
    """An invalid shebang causes python's Popen to throw an exception."""
    exitcode, out, err = validation_runner("#!invalidshebang", "", "", tmp_dir=tmp_dir)
    print(err)
    assert exitcode == 7
    assert out == ""
    assert err != ""


def test_validation_runner_cleans_up(tmp_dir: Path):
    validation_runner("#!/bin/sh\necho []", "", "", tmp_dir=tmp_dir)
    files = [entry for entry in tmp_dir.glob("*")]
    assert len(files) == 0


def test_validation_runner_cleans_up_even_on_error(tmp_dir: Path):
    validation_runner("#!invalid shebang BOOM!", "", "", tmp_dir=tmp_dir)
    files = [entry for entry in tmp_dir.glob("*")]
    assert len(files) == 0


def test_script_input(tmp_dir: Path):
    script = dedent(
        """
                    #!/usr/bin/env python3
                    import sys
                    import json
                    i = json.load(sys.stdin)
                    ft = json.loads(i['flex_template'])
                    jp = json.loads(i['job_parameters'])
                    print(json.dumps([i['job_parameters'], i['flex_template']]))
                    """
    ).strip()
    exitcode, out, err = validation_runner(
        script, '{"type":"template"}', '{"type":"params"}', tmp_dir=tmp_dir
    )
    print(err)
    assert exitcode == 0
    result = json.loads(out)
    assert json.loads(result["errors"]) == ['{"type":"params"}', '{"type":"template"}']
    assert err == ""


def test_script_input2(tmp_dir: Path):
    script = dedent(
        """
                    #!/usr/bin/env python3
                    import sys
                    import json
                    try:
                        i = json.load(sys.stdin)
                        errors = []
                        if 'flex_template' not in i:
                            errors.append("script input missing flex_template field")
                        if 'job_parameters' not in i:
                            errors.append("script input missing job_parameters field")
                        try:
                            json.loads(i['flex_template'])
                        except Exception as err:
                            errors.append(str(err))
                        try:
                            json.loads(i['job_parameters'])
                        except Exception as err:
                            errors.append(str(err))
                        if len(i.keys()) > 2:
                            errors.append(f"Received more keys than expected: {i.keys()}")
                    except Exception as err:
                        errors.append("Input is not JSON")
                    json.dump(errors, sys.stdout)
                    """
    ).strip()
    exitcode, out, err = validation_runner(
        script, '{"type":"template"}', '{"type":"params"}', tmp_dir=tmp_dir
    )
    print(err)
    assert exitcode == 0
    assert err == ""
    result = json.loads(out)
    errors = json.loads(result["errors"])
    assert errors == []
