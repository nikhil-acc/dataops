import json
import subprocess
from pathlib import Path
from subprocess import PIPE
from typing import List, Tuple

from tests import VALIDATION_RUNNER_PY


def validation_runner(
    script: str, flex_template: str, job_parameters: str, *, tmp_dir: Path | None = None
) -> Tuple[int, str, str]:
    """Run the validation_runner.py script and return the results for testing."""
    cmd = ["python3", str(VALIDATION_RUNNER_PY)]
    if tmp_dir:
        cmd.append(f"--tmp-dir={tmp_dir}")
    query = {
        "script": script,
        "flex_template": flex_template,
        "job_parameters": job_parameters,
    }
    cp = subprocess.run(
        cmd, input=json.dumps(query).encode("utf-8"), stderr=PIPE, stdout=PIPE
    )
    return cp.returncode, cp.stdout.decode("utf-8"), cp.stderr.decode("utf-8")


def sh_echo(echo_str: str):
    cp = subprocess.run(["/bin/sh", "-c", f"echo {echo_str}"], stdout=PIPE)
    cp.check_returncode()
    return cp.stdout.decode("utf-8")


def parse_output(output: str) -> List[str]:
    """
    Parse the output of running validation_runner returning the errors.
    """
    result = json.loads(output)
    assert "errors" in result, "Output did not have 'errors' attribute."
    return json.loads(result["errors"])
