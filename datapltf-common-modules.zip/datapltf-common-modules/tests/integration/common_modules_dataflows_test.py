"""
Test dataflows within the context of common modules .
"""

import re
from textwrap import dedent
from typing import Dict
from uuid import uuid4

from pytest_httpserver import HTTPServer

from tests import (
    INTEGRATION_TESTS_DIR,
    print_out,
    sh_quoted_json,
    tf_vars_from_env,
    Workspace,
)

FlexTemplate = Dict


def test_dataflow_job_without_validation_script(httpserver: HTTPServer):
    """Test when there is no validation script for a given template."""
    uid = uuid4().hex
    template_name = f"{uid}.json"
    flex_template: FlexTemplate = {"metadata": {"parameters": []}}
    httpserver.expect_oneshot_request(f"/{template_name}").respond_with_json(
        flex_template
    )
    httpserver.expect_oneshot_request(f"/{template_name}-validation").respond_with_data(
        status=404
    )
    tf = Workspace(INTEGRATION_TESTS_DIR / "dataflows-validation")
    tf.ensure_init()
    status, out, err = tf.plan(
        vars=tf_vars_from_env(
            {
                "flex_template_artifactory_fullurl": httpserver.url_for(
                    f"/{template_name}"
                ),
                "custom_parameters": r"{}",
            }
        )
    )
    print_out(out, err)
    assert status == 0, err


def test_dataflow_job_validation_with_validation_errors(httpserver: HTTPServer):
    """Test when there is a script and it returns validation errors."""
    uid = uuid4().hex
    template_name = f"{uid}.json"
    flex_template: FlexTemplate = {"metadata": {"parameters": []}}
    httpserver.expect_oneshot_request(f"/{template_name}").respond_with_json(
        flex_template
    )
    validation_errors = ["Cannot have parameter1 with value 'd'"]
    validation_script = f"#!/bin/sh\necho {sh_quoted_json(validation_errors)}"
    httpserver.expect_oneshot_request(f"/{template_name}-validation").respond_with_data(
        response_data=validation_script, status=200
    )
    tf = Workspace(INTEGRATION_TESTS_DIR / "dataflows-validation")
    tf.ensure_init()
    status, out, err = tf.plan(
        vars=tf_vars_from_env(
            {
                "flex_template_artifactory_fullurl": httpserver.url_for(
                    f"/{template_name}"
                ),
                "custom_parameters": r"{}",
            }
        )
    )
    print_out(out, err)
    assert status == 1
    validation_error_msg = "\n".join(f"{i+1}. {validation_error}\n" for i, validation_error in enumerate(validation_errors))
    # For some reason terraform seems to wrap the validation message at about 80 character lines
    expected_error_msg = dedent(
        f"""
    You have misconfigured your lastflow dataflow job, there are 1 validation
    errors:
    {validation_error_msg}
    """
    ).strip()
    assert expected_error_msg in err


def test_dataflow_job_validation_without_validation_errors(httpserver: HTTPServer):
    """Test when there is a script and it returns no errors."""
    uid = uuid4().hex
    template_name = f"{uid}.json"
    flex_template: FlexTemplate = {"metadata": {"parameters": []}}
    httpserver.expect_oneshot_request(f"/{template_name}").respond_with_json(
        flex_template
    )
    validation_script = "#!/bin/sh\necho '[]'"
    httpserver.expect_oneshot_request(f"/{template_name}-validation").respond_with_data(
        response_data=validation_script, status=200
    )
    tf = Workspace(INTEGRATION_TESTS_DIR / "dataflows-validation")
    tf.ensure_init()
    status, out, err = tf.plan(
        vars=tf_vars_from_env(
            {
                "flex_template_artifactory_fullurl": httpserver.url_for(
                    f"/{template_name}"
                ),
                "custom_parameters": r"{}",
            }
        )
    )
    print_out(out, err)
    assert status == 0
    assert len(re.findall(r"Plan: \d+ to add, 0 to change, 0 to destroy.", out)) > 0
