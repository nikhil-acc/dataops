import json
from textwrap import dedent

from tests import (
    INTEGRATION_TESTS_DIR,
    print_out,
    sh_quoted_json,
    terraform,
    VALIDATION_RUNNER_PY,
    Workspace,
    WorkspaceFixture,
)


def test_terraform_init():
    status, out, err = terraform(
        "init", chdir=INTEGRATION_TESTS_DIR / "tf0", no_color=True
    )
    print(err)
    assert status == 0
    assert out != ""
    assert err == ""


def test_terraform_plan():
    status, out, err = terraform(
        "plan", chdir=INTEGRATION_TESTS_DIR / "tf0", no_color=True, vars={"x": "asfd"}
    )
    print(err)
    assert status == 0
    assert out != ""
    assert err == ""


def test_Workspace():
    tf = Workspace(INTEGRATION_TESTS_DIR / "tf0")
    tf.plan()


MAIN_TF = dedent(
    r"""
variable "script" {
    type = string
}

variable "flex_template" {
    type = string
}

variable "job_parameters" {
    type = string
}
variable "validation_runner" {
    type = string
    default = null
}

data "external" "validation" {
    program = ["python3", var.validation_runner]

    query = {
        script = var.script
        flex_template = var.flex_template
        job_parameters = var.job_parameters
    }
}

output "result" {
    value = data.external.validation.result
}
"""
)


def test_unexpected_error():
    script = "#!Asfla lkjasl askf jalk la jf"
    with WorkspaceFixture(main_tf=MAIN_TF) as tf:
        tf.ensure_init()
        status, out, err = tf.plan(
            vars={
                "script": script,
                "flex_template": "{}",
                "job_parameters": "{}",
                "validation_runner": VALIDATION_RUNNER_PY,
            }
        )
        print_out(out, err)
        assert status == 1, err
        assert "State: exit status 7" in err
        assert "External Program Execution Failed" in err
        assert "Planning failed." in out


def test_expected_error():
    error = "SOME ERROR"
    exception = "EXCEPTION OCCURRED"
    script = dedent(
        f"""
    #!/usr/bin/env python3
    import sys
    print("{error}", file=sys.stderr)
    raise RuntimeError("{exception}")
    """
    ).strip()
    with WorkspaceFixture(main_tf=MAIN_TF) as tf:
        tf.ensure_init()
        status, out, err = tf.plan(
            vars={
                "script": script,
                "flex_template": "{}",
                "job_parameters": "{}",
                "validation_runner": VALIDATION_RUNNER_PY,
            }
        )
        print_out(out, err)
        assert status == 1, err
        assert error in err
        assert f"RuntimeError: {exception}" in err
        assert "State: exit status 2" in err
        assert "External Program Execution Failed" in err
        assert "Planning failed." in out


def test_validation_errors():
    validation_errors = ["error1", "error2"]
    script = f"#!/bin/sh\necho {sh_quoted_json(validation_errors)}"
    with WorkspaceFixture(main_tf=MAIN_TF) as tf:
        tf.ensure_init()
        status, out, err = tf.apply(
            auto_approve=True,
            vars={
                "script": script,
                "flex_template": "{}",
                "job_parameters": "{}",
                "validation_runner": VALIDATION_RUNNER_PY,
            },
        )
        print_out(out, err)
        assert status == 0, err
        assert "Apply complete!" in out
        status, out, err = tf.output(json=True)
        print_out(out, err)
        assert status == 0, err
        result = json.loads(out)
        assert validation_errors == json.loads(result["result"]["value"]["errors"])


VALIDATION_MAIN_TF = dedent(
    r"""
variable "script" { }
variable "validation_runner" { }
data "external" "validation" {
    program = ["python3", var.validation_runner]
    query = {
        script = var.script
        flex_template = "{}"
        job_parameters = "{}"
    }
}
locals {
    errors = jsondecode(data.external.validation.result.errors)
}
resource "terraform_data" "dataflow" {
    lifecycle {
        precondition {
            condition     = length(local.errors) == 0
            error_message = "Validation failure:\n${join("\n", local.errors)}"
        }
    }
}"""
)


def test_failed_validation():
    print(VALIDATION_MAIN_TF)
    validation_errors = ["parameter value is wrong"]
    expected_error_msg = "\n".join(["Validation failure:"] + validation_errors)
    script = f"#!/bin/sh\necho {sh_quoted_json(validation_errors)}"
    with WorkspaceFixture(main_tf=VALIDATION_MAIN_TF) as tf:
        tf.ensure_init()
        status, out, err = tf.plan(
            vars={
                "script": script,
                "validation_runner": VALIDATION_RUNNER_PY,
            }
        )
        print_out(out, err)
        assert status == 1, out
        assert expected_error_msg in err
        assert "Planning failed." in out


def test_successful_validation():
    print(VALIDATION_MAIN_TF)
    script = "#!/bin/sh\necho '[]'"
    with WorkspaceFixture(main_tf=VALIDATION_MAIN_TF) as tf:
        tf.ensure_init()
        status, out, err = tf.plan(
            vars={
                "script": script,
                "validation_runner": VALIDATION_RUNNER_PY,
            }
        )
        print_out(out, err)
        assert status == 0, err
