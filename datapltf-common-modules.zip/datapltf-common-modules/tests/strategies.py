import string

from hypothesis import strategies as st


validation_errors = st.text(string.printable, min_size=10)
validation_error_lists = st.lists(validation_errors, min_size=0)
