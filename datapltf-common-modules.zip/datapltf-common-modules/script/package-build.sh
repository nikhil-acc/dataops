#!/bin/bash
for lib_base in $(find ${CI_PROJECT_DIR}/test/lib/base -maxdepth 1 -mindepth 1 -type d); 
do
cd $lib_base; 
mvn deploy -s ${CI_PROJECT_DIR}/common_config/settings.xml;
done
for lib_util in $(find ${CI_PROJECT_DIR}/test/lib/util -maxdepth 1 -mindepth 1 -type d); 
do
cd $lib_util; 
mvn deploy -s ${CI_PROJECT_DIR}/common_config/settings.xml;
done
for dfj in $(find "${CI_PROJECT_DIR}/test/df" -maxdepth 1 -mindepth 1 -type d); do
    if [ -e "$dfj/pom.xml" ]; then
        cd "$dfj" || exit
        mvn clean package -s "${CI_PROJECT_DIR}/common_config/settings.xml"
    else
        echo "Skipping $dfj as it does not contain a pom.xml file."
    fi
done
