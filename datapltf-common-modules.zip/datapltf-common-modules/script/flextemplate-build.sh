#!/usr/bin/env bash

abort() {
    echo "[ABORT] $*" 2>&1
    exit 1
}

parse-cli() {
    while (( "$#" ))
    do case $1 in
        --job-path)                          shift; JOB_PATH="$1";                          shift;;
        --container-image)                   shift; CONTAINER_IMAGE="$1";                   shift;;
        --artifactory-user-token)            shift; ARTIFACTORY_USER_TOKEN="$1";            shift;;
        --flex-template-artifactory-fullurl) shift; FLEX_TEMPLATE_ARTIFACTORY_FULLURL="$1"; shift;;
        *) abort "Unknown arg: $1"
       esac
    done
}

expect-var() {
    if [[ -z "${!1}" ]]
    then abort "$1 must be set."
    fi
}

expect-vars() {
    for var_name in "$@"
    do expect-var "$var_name"
    done
}

validate-template() {
    local flex_template_path="$1"
    if ! jq -e < "$1"
    then abort "Invalid JSON for template $flex_template_path"
    fi
}

validation-script() {
    local job_path="$1" validation_scripts=()
    validation_scripts=("$job_path"/validation.*)
    if [[ "${validation_scripts[0]}" != "$job_path/validation.*" ]]
    then echo "${validation_scripts[0]}"
    fi
}

main() {
    parse-cli "$@"
    expect-vars JOB_PATH ARTIFACTORY_USER_TOKEN FLEX_TEMPLATE_ARTIFACTORY_FULLURL CONTAINER_IMAGE
    local flex_template_path="${JOB_PATH}/flex-template.json"
    set -xe
    CONTAINER_IMAGE="$CONTAINER_IMAGE" \
    envsubst '$CONTAINER_IMAGE' < "${JOB_PATH}/flex-template.envsubst.json" > "$flex_template_path"
    validate-template "$flex_template_path"
    curl -sSf -XPUT \
        -H "Authorization: Bearer $ARTIFACTORY_USER_TOKEN" \
        --upload-file "$flex_template_path" \
        "${FLEX_TEMPLATE_ARTIFACTORY_FULLURL}"
    local validation_script_path
    # Publish the validation script if it exists.
    validation_script_path="$(validation-script "$JOB_PATH")"
    if [[ -n "${validation_script_path}" ]]
    then curl -sSf -XPUT \
            -H "Authorization: Bearer $ARTIFACTORY_USER_TOKEN" \
            --upload-file "$validation_script_path" \
            "${FLEX_TEMPLATE_ARTIFACTORY_FULLURL/.json/.json-validation}"
    fi
}

main "$@"