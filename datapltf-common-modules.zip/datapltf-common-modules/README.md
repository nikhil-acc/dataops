# DataPlatform Common Module

---

## Table of Contents

* [Prerequisites](#prerequisites)
* [Module development](#module-development)
* [Contribution](#contribution)
* [Cloud resources](#cloud-resources)
  * [Generic use case variables](#generic-use-case-variables)
  * [Data buckets](#datalake-buckets)
  * [Artifact buckets](#artifact-buckets)
  * [BigQuery datasets tables and views](#bigquery-datasets-tables-and-views)
    * [Folders](#bq-folders)
    * [Variables](#bq-variables)
  * [PubSub topics](#pubsub-topics)
  * [PubSub Lite](#pubsub-lite)
  * [Cloud Functions](#cloud-functions)
    * [Folders](#cf-folders)
    * [Variables](#cf-variables)
  * [Cloud Functions v2](#cloud-functions-v2)
    * [Variables](#cf-variables-v2)
  * [GCS notification](#gcs-notification)
  * [Dataflow](#dataflow)
    * [Folders](#df-folders)
    * [Variables](#df-variables)
    * [Flex Templates](#dataflow-flextemplate-docker-image-build)
    * [Dataflow Job and Template Validation](#dataflow-job-validation)
  * [Dataproc](#Dataproc)
    * [Dataproc Serverless](#dataproc-serverless)
      * [Folders](#dp-folders)
      * [Variables](#dp-variables)
    * [Dataproc Streaming](#dataproc-streaming)
      * [Folders](#dps-folders)
      * [Variables](#dps-variables)
  * [Composer](#composer)
    * [Folders](#com-folders)
    * [Variables](#com-variables)
  * [Dashboard](#dashboard)
    * [Folders](#dash-folders)
    * [Variables](#dash-variables)
  * [Alert Channels](#alert-channels)
    * [Variables](#altch-variables)
  * [Alert Policies](#alert-policies)
    * [Folders](#alt-folders)
    * [Variables](#alt-variables)
  * [Secrets](#secrets)
    * [Variables](#scrt-variables)
  * [Logsinks](#logsinks)
    * [Variables](#logsink-variables)
  * [SLOs](#slos)
    * [Folders](#slo-folders)
    * [Variables](#slo-variables)
  * [Log-metric](#log-metric)
  * [Custom-metric](#custom-metric)
  * [Hidden variables](#hidden-variables)
  * [Cloud Run Job](#cloud-run-job)
    * [Variables](#crjob-variables)
  * [Cloud Run V2 Service](#cloud-run-v2-service)
    * [Variables](#crs-v2-service-variables)
* [Common Config](#common-config)
* [Bell Corporate Security Requirements](#security)

---

The purpose of this module is to create all resources required for the use case: service account, buckets, BigQuery tables, PubSub topics, etc. It's not supposed to be used as a traditional terraform module (referenced from .tf files), but cloned into a deployment project. This approach allows to create only a single variables file in the deployment project, avoiding the need to write complete terraform code.

<a name="prerequisites"/>

## Prerequisites

* Terraform 1.1.3 +
* GNU make 3.0 +
* Google service account credentials.
* If your gitlab project is outside of NBD group then you need additional setup:
  * Create FID to access Unified Artifactory.
  * Submit Service Request to grant AD group **npdaa-dataplatform-ua-view** to your FID, so it's able to access terraform modules.
  * Configure gitlab Ci/CD variables ARTIFACTORY_USERNAME=< FID > and ARTIFACTORY_USER_TOKEN=< FID_password > on your gitlab group level, so projects have access to terraform modules.
  * Add this line into your Makefile step that pulls common module:

  ```
  echo "machine artifactory.int.bell.ca\nlogin ${ARTIFACTORY_USERNAME}\npassword ${ARTIFACTORY_USER_TOKEN}" > ~/.netrc
  ```

<a name="module-development"/>

## Module development

This module uses makefile to simplify local testing. To run locally the only required environment variable is GOOGLE_CREDENTIALS. You need service account token with the right permissions in order to create objects. Local testing is only allowed on NPE environment.

```
export GOOGLE_CREDENTIALS=./repo-key.json
```

Once credentials are set you can plan, apply and destroy:

```
make plan
make apply
make destroy
make plan-apply-destroy
```

The last one is to test creation and destruction of all objects in one go.
Please always destroy objects after testing is done.

<a name="contribution"/>

## Contribution

Make your changes in the feature branch and merge to master only when everything is tested and working. Master must always be clean and run without errors. Pipeline is configured to run on master or when merge request targets master or when commit is added to merge request that targets master.

<a name="cloud-resources"/>

## Cloud resources

Please note: all variable values are in lower case. You can find an example of `terraform.tfvars` [here](test/example.tfvars).
**WARNING:** Changing the values of some variables (e.g. `domain`, `use_case`, project IDs) will force recreation of all resources. At the same time changing other variables (e.g. `owner_primary_pein`, `owner_secondary_pein`) updates existing resources. Always check the output of the plan to make sure you don't destroy resources if you don't intend to do that. There are safety measures in place - by default you can't destroy buckets and BigQuery tables if they already have data.

<a name="generic-use-case-variables"/>

### Generic use case variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | -------- | --------- |
| `use_case` | Name of the use case, keep it short, but descriptive. Must be defined in Makefile through `TF_VAR_use_case` if you need to enable parallel development. | | |
| `domain` | Name of the domain. | | |
| `dr_enabled` | bool value to indicate use case needs Disaster Recovery function or not | Yes | `false` |
| `owner_primary_pein` | Bell employee # of the primary owner of the use case. | | |
| `owner_secondary_pein` | Bell employee # of the secondary owner of the use case. | | |
| `dataeng_project` | Dataeng project name. Ingestion runs here, also buckets and BigQuery dataset are created here. | | |
| `common_project` | Common project name. Artifact Registry lives here. Normally it's always prod and you don't need to define this variable. | Yes | `prj-netw-prod-npda-common-01` |
| `airflow_project` | Airflow project name. Cloud Composer runs here. | Yes | |
| `force_delete_data` | If true, allows to kdestroy buckets and BQ tables contaning data. Please note it must be set before you want to destroy resources. If it was not set to true when objects were created then you need to change it, apply chnages and only after that you can destroy. This variable is always false in production, user input is ignored. | Yes | `false` |
| `data_access` | Set of strings to grant read access to buckets and BQ datasets. Access can be granted only to groups and each entry must have a `group:` prefix. e.g. `group:GCP-NPDA-Npe-Admins-DataEng-Charging@bell.ca`, `data_access` also grants browser role on the dataeng project level. ***See note below*** | Yes | [] |
| `artifact_registries` | Set of strings, list of artifact registries to grant read access to. Undefined variable means no access is grantred. The list of available repositories: "art-datapltf-prod-nane1-docker-release-01","art-datapltf-prod-nane1-maven-release-01","art-datapltf-prod-nane1-docker-snapshot-01","art-datapltf-prod-nane1-maven-snapshot-01" | Yes | [] |
| `secret_accessors` | Set of strings to grant secretAccessor role to external group/serviceAccount. The use-case service account is automatically added to the set.
| `additional_api_access` | Grants use-case service account access to the selected GCP APIs. Supported APIs: `cloud_dlp` | Yes | [] |
| `additional_project_iam_sa_roles` | WARNING! This is a temporary solution and will be removed soon, don't use it for production deployments. Grants a list of service accounts project iam roles. Used to give access to invoke cloud functions or access a database. | Yes | {} |

| `service_account` | Use existing service account to grant resource level permissions required. | Yes |
| `xfer_service_account` | Use existing xfer service account to grant resource level permissions required. | Yes |


**Note:** `data_access` casing needs to match the casing in GCP and not in BARS. If the group is called `GCP-NPDA-Npe-Admins-DataEng-Charging` in BARS but `gcp-npda-npe-admins-dataeng-charging@bell.ca` in GCP then `data_access` needs to have the lower case version. If not the permission will be added but terraform will throw an error and permission will not be managed by terraform anymore even though it was created by it.

<a name="datalake-buckets"/>

### Data buckets

Data buckets are created in `dataeng` project to store data: raw files, intermediate results, structured data, etc. All data buckets must have lifecycle rules defined to setup data retention.
Please note, Dataflow has dependency on a `bucket-data` resource named "dftemp". If dataflow resources are required in use cases, please ensure the bucket with EXACT name is in `bucket-data` in `terraform.tfvars`, otherwise the deployment will fail.
Dynamic dataflow jobs created by composer dags must use the same "dftemp" bucket from `dataeng` project.

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | -------- | --------- |
| `buckets_data` | This variable is a map of objects - you can have more then one bucket for a single use case. Map key is a bucket suffix - short description of the bucket purpose and index, e.g. "raw-01".| Yes | `{}` |

Bucket object structure, all object's fields are mandatory and don't have default values:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `region` | Bucket region, for now the only allowed regions are `nane1` and `nane2`. |
| `storage_class` | Bucket storage class: `STANDARD`, `REGIONAL`, `NEARLINE`, `COLDLINE`, `ARCHIVE`. See [documentation](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket#storage_class) for more details. |
| `versioning` | Enables objects versioning. |
| `data_tier` | Data tier, possible values: `raw`, `temp`, `lnd`, `expl`, `esd`. |
| `lifecycle_rules` | The list of predefined lifecycle rules, e.g. "retention-14days" - data retention of 14 days. Existing lifecycle rules are defined [here](locals.tf). If rule you need is missing there you can create it and submit MR |
| `external_access` | List of permissions to be granted to xfer account on the bucket. You need to follow the principle of least required privileges. Don't grant storage admin, if external application needs only object creator. You can find a full list of storage role in the [official documentation](https://cloud.google.com/iam/docs/understanding-roles#cloud-storage-roles). |

<a name="artifact-buckets"/>

### Artifact buckets

Artifact buckets are created in `dataeng` to store use case artifacts (config files, source code, libraries, etc.). Object structure is similar to data buckets, but there are no lifecycle rules and data tier here.
Please note, Dataflow and Cloud Function have dependency on a `bucket-artifact` resource named "dataflow" and "cloudfunction" respectively. If dataflow and/or cloudfunction resources are required in use cases, please ensure the bucket with EXACT name(s) are(is) in `bucket-artifact` in `terraform.tfvars`, otherwise the deployment will fail.

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | -------- | --------- |
| `buckets_artifact` | This variable is a map of objects - you can have more then one artifact bucket for a single use case. Map key is a bucket suffix - short description of the bucket purpose and index, e.g. "code-01".| Yes | `{}` |

Object structure, all object fields are mandatory and don't have default values: 

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `region` | Bucket region; for now only allowed regions are `nane1` and `nane2`. |
| `storage_class` | Bucket storage class: `STANDARD`, `REGIONAL`, `NEARLINE`, `COLDLINE`, `ARCHIVE`. See [documentation](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket#storage_class) for more details. |
| `versioning` | Enables objects versioning. |

<a name="bigquery-datasets-tables-and-views"/>

### BigQuery datasets, tables and views

### Prerequisites

#### BigQuery slot reservation and assignments

It's stongly advised to use BigQuery slots reservations in Dataeng project if use case is processing data using BigQuery. You can add reservation to your project here:

- Dev https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-common-environment-setup/-/blob/master/env/development/bqslots/vars.hcl?ref_type=heads
- Stg https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-common-environment-setup/-/blob/master/env/staging/bqslots/vars.hcl?ref_type=heads
- Prod https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-common-environment-setup/-/blob/master/env/production/bqslots/vars.hcl?ref_type=heads

#### Runner permissions

Gitlab runner requires the following permissions:

| Role | GCP project | Comment |
|------|-------------|---------|
| `roles/bigquery.admin` | Dataeng project (e.g. `prj-netw-dev-npda-dataeng-01`) | Required to deploy all BQ resources |
| `roles/storage.admin` | Dataeng project (e.g. `prj-netw-dev-npda-dataeng-01`) | Required to create external tables |
| `roles/bigquery.resourceViewer` | BigQuery admin project (e.g. `prj-netw-npe-npda-bigquery-01`) | Required to check BQ reservations |

<a name="bq-folders"/>

#### Migration from version <=2.0.0 to >=2.5.0

Naming convention change is introduced in the version 2.1.0. You can find details here https://confluence.bell.corp.bce.ca/display/NBD/Comparison+of+Data+Naming+Conventions. Short summary - `raw`, `stg` and `esd` are deprecated. `raw` is merged into `lnd`, `stg` is merged into `wrk`, `esd` is replace by `curated`. There is also a new tier `semantic`.

##### Scenario 1: You are not using deprecated tiers

- Rename Bigquery dataset folders to be a full dataset name, e.g. `lnd` => `wrlssrtsv_polystar_lnd`.
- Rename `bq_datasets` variable to `bigquery_datasets`.
- Rename all map keys in `bigquery_datasets` to be full dataset names matching folder names.
- Deploy changes in all environments.

##### Scenario 2: You are using deprecated tiers

- Move non-impacted datasets from `bq_datasets` variable to `bigquery_datasets`.
- Create new schemas and tables to replace deprectaed ones using `bigquery_datasets` variable.
- Deploy changes in all environments.
- Move data from deprecated schemas/tables to newly created ones. You may need to create a script for this and temporarely add it to your gitlab pipeline. Make sure to delete data from the old tables!
- Remove `bq_datasets` from variables file.
- Deploy changes in all environments.

#### Folders

Folder `bq` contains subfolders corresponding to dataset tiers: `lnd`, `expl`, `curated`, `semantic`.

##### Tables

These subfolders contain json files corresponding to table schemas, with one json file per table. The name of the file must match the table name. [Example](bq/lnd/table_with_just_description.json).

##### Views

These subfolders contain sql files with view SQL with one sql file per table. The name of the file must match the sql name passed in the `bq_datasets.tier.views`. [Example](bq/expl/v_test_same_dataset.sql).

<a name="bq-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | -------- | --------- |
| `bq_datasets` | Map of objects, key is dataset tier: `raw`, `lnd`, `expl`, `esd`. | Yes | `{}` |
| `bigquery_datasets` | Map of objects, key is an arbitrary name as long as it ends with one of the following dataset tiers: `semantic`, `wrk`, `lnd`, `expl`, `esd`. | Yes | `{}` |
| `bq_path` | Path to bq data files to use for the bq_datasets | Yes | `${path.cwd}/bq` |
| `bq_admin_project` | Bigquery admin project where reservations are defined. | Yes | null |
| `bq_location` | Bigquery location where reservations are defined. | Yes | `northamerica-northeast1` |

##### Dataset object structure

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | -- | -- |
| `region` | Dataset's region, for now the only allowed regions are `nane1` and `nane2`. | No | |
| `context` | List of descriptive names to enrich the Dataset's ID with additional context. | Yes | [] |
| `description` | Provide custom description for the dataset. Default is `<domain> dataset for <usecase>`. | Yes | |
| `authorized_datasets` | List of datasets that are authorized to access the current dataset. | Yes | [] |
| `storage_billing_model` | Storage billing model to use for the dataset (`LOGICAL` or `PHYSICAL`) | Yes | PHYSICAL |
| `tables` | Map of objects that describes tables to create, key must correspond to schema json file name, see BQ folders structure above. | Yes | {} |
| `views` | Map of objects that describes views to create, key must correspond to sql file name, see BQ folders structure above. | Yes | {} |
| `materialized_views` | Map of objects that describes materialized views | Yes | {} |
| `external_tables` | Map of objects that describes tables with external sources | Yes | {} |

##### Authorized Datasets object structure

If a dataset needs to have authorized datasets associated with it, then for each authorized dataset you need to specify the following in an object:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `project_id` | This is the project id where the dataset you want to authorize access resides. |
| `dataset_id` | This is the dataset id of the dataset you want to authorize access |

Example: [here](test/example.tfvars)

##### Tables object structure

If a table contains partitions, all object fields (except `description`) are required as mentioned below and don't have default values:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `description` | (Optional) Description for the table. |
| `partition_field` | Field used to determine how to create a time-based partition, must be either a scalar `DATE`, `TIMESTAMP`, or `DATETIME` column. If time-based partitioning is enabled without this value, the table is partitioned based on the load time. |
| `partition_type` | Partition granularity. The supported types are `DAY`, `HOUR`, `MONTH`, and `YEAR`, which will generate one partition per day, hour, month, and year, respectively. Keep in mind that a BigQuery table limit is 4000 partitions per table, so you can't create a table with hourly partition and have retention of one year, because it would require 8760 partitions. If empty then table is not partitioned and values for other fields are ignored, but still required. |
| `require_partition_filter` | If set to true, queries over this table require a partition filter that can be used for partition elimination to be specified. |
| `retention_days` | Number of days for which to keep the storage for a partition. |
| `ref_data_bucket` (Optional) | Reference data bucket for the table. |
| `source_format`  (Optional) | Format of the source data: CSV, NEWLINE_DELIMITED_JSON). |
| `source_uris`  (Optional) | List of URIs to use as source for this table. Can't set this and ref_data_bucket |
| `clustering`  (Optional) | Specifies column names to use for data clustering. Up to four top-level columns are allowed, and should be specified in descending priority order. |


If table is not partitioned,  you can leave the structure empty or optionally provide a description. For example: `"table_with_no_partition" = {}`.

##### Views object structure

If a view is to be defined then the following fields have to be present per view:

| Variable | Description | Optional | Default   |
| -------- | ------------|----------|------------------------------ |
| `service_account_data_access` | Set of strings to grant `BigQuery Data Viewer` role to the specified view. Access can be granted only to service accounts and each entry must have a `serviceAccount:` prefix. e.g. `serviceAccount:sa-datapltf-npe-featviews-02@prj-netw-npe-npda-dataeng-02.iam.gserviceaccount.com`. This is useful if you need to follow the authorized view access pattern. | Yes | [] |

##### Materialized Views object structure

If a materialized view is to be defined then the following fields have to be present per view:

| Variable | Description | Optional | Default   |
| -------- | ------------|----------|------------------------------ |
| `service_account_data_access` | Set of strings to grant `BigQuery Data Viewer` role to the specified view. Access can be granted only to service accounts and each entry must have a `serviceAccount:` prefix. e.g. `serviceAccount:sa-datapltf-npe-featviews-02@prj-netw-npe-npda-dataeng-02.iam.gserviceaccount.com`. This is useful if you need to follow the authorized view access pattern. | Yes | [] |
| `enable_refresh` | Boolean type. This specifies whether to use BigQuery's automatic refresh for this materialized view when the base table is updated. | Yes | true |
| `refresh_interval_ms` | Number type. This specifies the maximum frequency at which this materialized view will be refreshed. | Yes | 1800000 |
| `refresh_interval_ms` | Number type. This specifies the maximum frequency at which this materialized view will be refreshed. | Yes | 1800000 |
| `custom_parameters` | map(string) type. This specifies the additional parameters to be passed as per requirement of a use case to render to sql query. | Yes | {} |

Example: [here](test/example.tfvars)

##### External tables object structure

| Variable | Description | Optional | Default   |
| -------- | ------------|----------|------------------------------ |
| `source_format` |Tthe format of the source data. For CSV files, specify "CSV". For Google sheets, specify "GOOGLE_SHEETS". For newline-delimited JSON, specify "NEWLINE_DELIMITED_JSON". For Avro files, specify "AVRO". For Google Cloud Datastore backups, specify "DATASTORE_BACKUP". For Apache Iceberg tables, specify "ICEBERG". For ORC files, specify "ORC". For Parquet files, specify "PARQUET". [Beta] For Google Cloud Bigtable, specify "BIGTABLE". | No | |
| `source_uris` | A list of source URIs from which to get the data | No | |
| `description`| Description for the table. |  Yes | "" |
| `autodetect` | Let BigQuery try to autodetect the schema and format of the table.| Yes | false|
| `compression` | The compression type of the data source. Valid values are "NONE" or "GZIP". | Yes | API default |
| `connection_id`| The connection specifying the credentials to be used to read external storage, such as Azure Blob, Cloud Storage, or S3. The connection_id can have the form {{project}}.{{location}}.{{connection_id}} or projects/{{project}}/locations/{{location}}/connections/{{connection_id}}. | Yes | API default|
| `ignore_unknown_value` |Indicates if BigQuery should allow extra values that are not represented in the table schema. If true, the extra values are ignored. If false, records with extra columns are treated as bad records, and if there are too many bad records, an invalid error is returned in the job result. | Yes | API default |
| `max_bad_records` | The maximum number of bad records that BigQuery can ignore when reading data. | Yes | API default |
| `csv_options` | Additional properties to set if source_format is set to "CSV". | Yes | API default|
| `csv_options.field_delimiter` | The separator for fields in a CSV file. | Yes | API default|
| `csv_options.quote` | The value that is used to quote data sections in a CSV file. | Yes | " |
| `csv_options.allow_jagged_rows`| Indicates if BigQuery should accept rows that are missing trailing optional columns. | Yes | API default |
| `csv_options.allow_quoted_newlines` | Indicates if BigQuery should allow quoted data sections that contain newline characters in a CSV file. | Yes | false |
| `csv_options.skip_leading_rows` | The number of rows at the top of a CSV file that BigQuery will skip when reading the data. | Yes | API default |
| `csv_options.encoding` | The character encoding of the data. The supported values are UTF-8 or ISO-8859-1. | Yes | UTF-8 |
| `hive_partitioning_options` | Configures hive partitioning support. | Yes | {} |
| `hive_partitioning_options.mode` | What mode of hive partitioning to use when reading data, AUTO, STRINGS, CUSTOM | Yes | API default |
| `hive_partitioning_options.require_partition_filter` | If set to true, queries over this table require a partition filter that can be used for partition elimination to be specified. | Yes | API default |
| `hive_partitioning_options.source_uri_prefix` | When hive partition detection is requested, a common for all source uris must be required. The prefix must end immediately before the partition key encoding begins. | Yes | API default |
| `avro_options` | Additional options if source_format is set to "AVRO" | Yes | {} |
| `avro_options.use_avro_logical_types` | If is set to true, indicates whether to interpret logical types as the corresponding BigQuery data type (for example, TIMESTAMP), instead of using the raw type (for example, INTEGER). | Yes | API default |
| `parquet_options` | Additional properties to set if source_format is set to "PARQUET" | Yes | {} |
| `parquet_options.enum_as_string`| Indicates whether to infer Parquet ENUM logical type as STRING instead of BYTES by default. | Yes | API default |
| `parquet_options.enable_list_inference` | Indicates whether to use schema inference specifically for Parquet LIST logical type. | Yes | API default |
| `json_options` | Additional properties to set if source_format is set to "NEWLINE_DELIMITED_JSON". | Yes | {} |
| `json_options.encoding` | The character encoding of the data. The supported values are UTF-8, UTF-16BE, UTF-16LE, UTF-32BE, and UTF-32LE. The default value is UTF-8. | Yes | API default |

<a name="pubsub-topics"/>

### PubSub topics

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | -------- | --------- |
| `pubsub_topics` | Map of objects, key is PubSub topic suffix. | Yes | `{}` |
| `xfer_pubsub` | Enables service account for external data ingestion into PubSub topic. Value is a list of strings corresponds to the map key in `pubsub_topics` variable. Xfer service account has write permissions to these topics. | Yes | `[]` |

PubSub object structure, all object's fields are mandatory and don't have default values except for `schema`:

| Variable        | Description                                                                             |
| --------------- | --------------------------------------------------------------------------------------- |
| `regions`       | List of allowed regions, supported values: `nane1` and `nane2`.                         |
| `schema`        | Object defining the schema to create for this topic. Structure defined below (Optional) |
| `subscriptions` | Map of objects that describes subscriptions.                                            |
| `bq_subscriptions` | Map of objects that describes Write to BigQuery subscriptions.                       |

PubSub subscription/bq_subscription object structure, all object's fields are mandatory and don't have default values:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `ack_deadline_seconds` | This value is the maximum time after a subscriber receives a message before the subscriber should acknowledge the message. |
| `dead_letter_topic` | The name of the topic to which dead letter messages should be published. If value is empty string then dead lettering is disabled. |
| `max_delivery_attempts` | The maximum number of delivery attempts for any message. The value must be between 5 and 100. Ignored is `dead_letter_topic` is an empty string. |
| `maximum_backoff` | The maximum delay between consecutive deliveries of a given message. Value should be between 0 and 600 seconds. |
| `minimum_backoff` | The minimum delay between consecutive deliveries of a given message. Value should be between 0 and 600 seconds. |
| `enable_message_ordering` | If `true`, messages published with the same orderingKey in PubsubMessage will be delivered to the subscribers in the order in which they are received by the Pub/Sub system. |
| `message_retention_duration` | How long to retain unacknowledged messages in the subscription's backlog, from the moment a message is published.  |
| `retain_acked_messages` | Indicates whether to retain acknowledged messages. |
| `enable_exactly_once_delivery` | If `true`, messages published with the same orderingKey in PubsubMessage will be delivered to the subscribers in the order in which they are received by the Pub/Sub system. |
| `filter` | The subscription only delivers the messages that match the filter. |
| `write_metadata` | This value is only for `bq_subscription` objects. If `true` the bq_subscription will write additional pubsub metadata columns to your table. See [here](https://cloud.google.com/pubsub/docs/bigquery#properties_subscription) for more details.  |
| `bigquery_dataset` | This value is only for `bq_subscription` objects. Full name if BigQuery dataset, e.g. `wrlssrtsv_polystar_raw`.  |
| `bq_table` | This value is only for `bq_subscription` objects. Name of the BigQuery table. |


PubSub schema object structure, all fields are mandatory

| Variable   | Description                                                                        |
| ---------- | ---------------------------------------------------------------------------------- |
| `name`     | Name of the schema to create.                                                      |
| `type`     | Type of the schema, possible values are `AVRO` and `PROTOCOL_BUFFER`.              |
| `encoding` | Encoding used by the topic for the scema. Possible values are `BINARY` and `JSON`. |

PubSub schema file location is under `pubsub/schemas` folder. The name of the file should match the name
of the PubSub Topic (by convention) and the file extension should be `avsc` for `AVRO` type and
`proto` for `PROTOCOL_BUFFER` type.

```
pubsub/
├─ schemas/
│  ├─ pubsub-topic-name-1.avsc
│  ├─ pubsub-topic-name-2.proto
```

You can find more details about these parameters in the [official documentation](https://cloud.google.com/pubsub/docs/pull).

<a name="pubsub-lite"/>

### PubSub Lite

This modules supports the following features of PubSub Lite :

* Creation of reservation
* Creation of Regional topic only (no support for Zonal)
* Creation of Subscrition along with subscribers
* Addition of IAM for roles pubsublite.viewer and pubsublite.subscriber for all `subscribers` account

#### PubSub Lite reservation

| Variable              | Description                                  | Optional | Default |
| --------------------- | -------------------------------------------- | -------- | ------- |
| `pubsub_lite_reservation`  | Map of objects describing PubSub Lite reservation. Key will be the name of reservation | Yes | {} |

| Field                 | Description                                  |
| --------------------- | -------------------------------------------- |
| `region`              | Region to use `nane1` or `nane2`             |
| `throughput_capacity` | The throughput capacity for this reservation |

#### PubSub Lite topic

| Variable              | Description                                  | Optional | Default |
| --------------------- | -------------------------------------------- | -------- | ------- |
| `pubsub_lite_topics`  | Map of objects describing PubSub Lite topic. Key will be the name of topic. Topics can only be created under `nane1` or `nane2` and it only supports Regional topic not Zonal | Yes | {} |

| Field                        | Description                                                                                                                 |
| ------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `region`                        | Region to use for the topic `nane1` or `nane2`                                                                              |
| `partition_count`               | Number of partitions to use for the topic                                                                                   |
| `total_publish_mib_per_sec`     | Number of Mib/s the topic should support totally for publishers. Will be divided by the number of partitions in the config  |
| `total_subscribe_mib_per_sec`   | Number of Mib/s the topic should support totally for subscribers. Will be divided by the number of partitions in the config |
| `retention_per_partition_bytes` | Size in bytes (per partition) to retain                                                                                     |
| `reservation`                   | Name of the reservation (created before) to use                                                                             |
| `subscriptions`                 | Map of objects that describes subscriptions. (described in next table)                                                      |

#### PubSub Lite subscriptions

This describes the field `subscriptions` from variable `pubsub_lite_topics`

| Variable               | Description                                                                                                                       |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| `delivery_requirement` | Delivery requirement based on documentation ( `DELIVER_IMMEDIATELY`, `DELIVER_AFTER_STORED`, `DELIVERY_REQUIREMENT_UNSPECIFIED` ) |
| `subscribers`          | List of users/service account to give subcriber role to                                                                           |

<a name="cloud-functions"/>

### Cloud Functions

<a name="cf-folders"/>

#### Folders

Folder `gcf` contains subfolders corresponding to Cloud Functions name suffixes, and under each subfolder are the source codes for the particular function, name of subfolder must match the  suffix of function name in tfvars value.

```
.
├── gcf
│   └── gcf1
      └── config.yaml
│     └── pom.xml
│     └── src
│       └── ...
│   └── gcf2
      └── config.yaml
│     └── pom.xml
│     └── src
│       └── ...
```

If you're publishing a Java library or need to pull a private library sitting in Artifact Registry, your `pom.xml` needs to include configs for Google Artifact Registry. The configs can be obtained by running the following command:
`gcloud artifacts print-settings mvn --project=AR_PROJECT --repository=AR_MVN_REPO --location=AR_REGION`

* Second level subfolders, also put one `config.yaml`, which is used to pass on terraform managed resource variables into the Cloud Function as runtime environment variables. Use case developers should make every effort in using these passed variables, combined with the resource information already known from other method, to construct resource names used in coding, to eliminate all hard coding. If more commonly needed variable, pls. contact common module development team. The content and format of `config.yaml` as show here [Example](df/newfunc/config.yaml). Below is the list of strings which are replaced with terraform runtime variable values in `config.yaml`:

  ```
     tf_host_project
     tf_dataflow_subnet
     tf_airflow_project
     tf_common_project
     tf_dataeng_project
     tf_domain
     tf_env
     tf_region
     tf_short_region
     tf_use_case
     tf_gcf_name
  ```

<a name="cf-variables"/>

#### Variables

Please note, Cloud Functions has a dependency on a `buckets_artifact` resource named "cloudfunction" to be created using `buckets_artifact` module. Ensure the bucket with EXACT name is in `buckets_artifact` in `terraform.tfvars` if cloudfunction is needed for the use case, otherwise the deployment will fail.

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `cloudfunction` | Map of objects, key is PubSub topic suffix. | Yes | `{}` |

cloudfunction object structure, all object's fields are mandatory and don't have default values:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `region` | Cloud Functions region, for now the only allowed regions are `nane1` and `nane2`. |
| `memory` | Memory allocated for the cloud function. |
| `runtime` | What language Cloud Function is coded. |
| `event_type` | What event triggers the cloud function. Currently the only supported value is `google.pubsub.topic.publish`. |
| `resource` | What resources to monitor for above mentioned event to happen in order to trigger this function. |
| `entry_point` | Function code entry point. |
| `vpc_connector` | The VPC Network Connector that this cloud function can connect to. It should be set up as fully-qualified URI. The format of this field is projects/\*/locations/\*/connectors/*.|
| `max_instances` | Maximum instances allocated to the cloud function |


<a name="cloud-functions-v2"/>

### Cloud Functions V2

<a name="cf-variables-v2"/>

#### Variables

Please note, Cloud Functions has a dependency on a `buckets_artifact` resource named "cloudfunction" to be created using `buckets_artifact` module. Ensure the bucket with EXACT name is in `buckets_artifact` in `terraform.tfvars` if cloudfunction is needed for the use case, otherwise the deployment will fail. Source code for V2 Cloud functions should not be packaged with the terraform module, instead a zipfile is referenced and downloaded from artifactory.

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `cloud_functions_v2` | Map of objects | Yes | `{}` |

Cloud Function V2 object structure

| Variable | Description | Optional | Default |
| ----------------- | ------------------------------------------------------ |  -------- | --------- |
| `region` | Cloud Functions region, for now the only allowed regions are `nane1` and `nane2`. | No | |
| `runtime` | Cloud function runtime | No | |
| `source_zip_full_url` | Artifactory url to source code zip file | No | |
| `entry_point` | Function code entry point. | No | |
| `build_env_variables` | Map of build environment varibles | Yes | |
| `docker_repository` | User managed repository created in Artifact Registry. Must be in same project | Yes | gcf-artifacts (created by gcp) |
| `invokers` | List of group, user, sa to grant invoker permission to the cloud function `group:group@email.com`/`serviceAccount:sa-name@email.com` | Yes | |
| `timeout_seconds` | Timeout in seconds | Yes | 60 |
| `available_memory` | Memory allocated for the cloud function. | Yes | 256M |
| `max_instance_request_concurrency` | Sets the maximum number of concurrent requests that each instance can receive | Yes | 1 |
| `available_cpu` | The number of CPUs used in a single container instance | Yes | 1 |
| `runtime_env_variables` | Map of runtime environment varibles. LOG_EXECUTION_ID=true is added to match GCP defaults  | Yes | |
| `max_instance_count` | The limit on the maximum number of function instances that may coexist at a given time | Yes | 10 |
| `min_instance_count` | The limit on the minimum number of function instances that may coexist at a given time | Yes | 1 | 
| `vpc_connector` | Name of vpc connector. Mandatory due to Bell policy  | No | |
| `all_traffic_on_latest_revision` | Whether 100% of traffic is routed to the latest revision  | Yes | true |
| `secret_environment_variables` | Secret environment variables configuration | Yes |  |
| `secret_volumes` | Secret volumes configuration | Yes |  |
| `event_trigger` | Event trigger | Yes |  |

event_trigger object structure

| Variable | Description | Optional | Default |
| ----------------- | ------------------------------------------------------ |  -------- | --------- |
| `trigger_region` | trigger region | Yes |  cloud function region |
| `event_type` | The type of event to observe | No |  |
| `event_filters` | Criteria used to filter events. Set of objects | Yes |  |
| `pubsub_topic` | The name of a Pub/Sub topic in the same project that will be used as the transport topic for the event delivery | Yes |  |
| `service_account_email` | The email of the trigger's service account. | Yes | usecase-serviceaccount |
| `retry_policy` | Retry Policy. Possible values: RETRY_POLICY_RETRY, RETRY_POLICY_DO_NOT_RETRY  | Yes | |

event_filters object structure

| Variable | Description | Optional | Default |
| ----------------- | ------------------------------------------------------ |  -------- | --------- |
| `attribute ` | The name of a CloudEvents attribute | No |  |
| `value` | The value for the attribute. If the operator field is set as match-path-pattern, this value can be a path pattern instead of an exact value | No |  |
| `operator` | The operator used for matching the events with the value of the filter. If not specified, only events that have an exact key-value pair specified in the filter are matched. The only allowed value is match-path-pattern | Yes |  |



<a name="gcs-notification"/>

### GCS notification

Creates PubSub notifications on bucket events. [Official documentation](https://cloud.google.com/storage/docs/pubsub-notifications).

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `gcs_notifications` | Map of objects to create PubSub notifications for Cloud Storage. Key is bucket index and it must correspond to data bucket index from `buckets_data`. | Yes | `{}` |

Object structure, all object's fields are mandatory and don't have default values:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `topic` | PubSub topic index, it must correspond to topic created by the same deployment. |
| `payload_format` | Payload type, allowed values: `JSON_API_V1`, `NONE`. |
| `event_types` | List of events to trigger notification. Allowed values: `OBJECT_FINALIZE`, `OBJECT_METADATA_UPDATE`, `OBJECT_DELETE`, `OBJECT_ARCHIVE`. |
| `object_name_prefix` | Prefix path filter for this notification config. Cloud Storage will only send notifications for objects in this bucket whose names begin with the specified prefix. |
| `custom_attributes` | A set of key/value attribute pairs to attach to each Cloud PubSub message published for this notification subscription. |

<a name="dataflow"/>

### Dataflow

<a name="df-folders"/>

#### Folders

Recommended dataflow job source code structure is as follows:

```
For JAVA based df:
.
├── df
│   └── df1
│     └── src
│       └── ...
│     └── pom.xml
│     └── flex-template.json
│     └── Dockerfile

For PYTHON based df:
.
├── df
│   └── df2
│     └── example.py
│     └── requirements.txt
│     └── flex-template.json
│     └── Dockerfile
```

* `df/` - all dataflow job source code are under `df/` folder in gitlab project repo
  * First level subfolders are the dataflow job names matching exactly to the `dataflows` variable keys, [Example](./test/df/).
  * Second level subfolders, there is one source code `src/java/main/...` in case of JAVA based df. In case of PYTHON based df, there is python file defined like (df/pythonflow/pythonflow.py).
  * Second level subfolders, a `Dockerfile` is defined which is used by kakino during building the flextemplate images, there are 3 placeholder variables `POM_ARTIFACTID`, `POM_VER`, `POM_MAINCLASS` in case of JAVA based df and `FLEX_TEMPLATE_PYTHON_REQUIREMENTS_FILE`, `FLEX_TEMPLATE_PYTHON_PY_FILE` in case of PYTHON based df that will be replaced by value from runtime, don't change them.
  * Second level subfolders, has one matching `pom.xml` for maven build for the source code. [Example](df/lastflow/pom.xml) in case of JAVA based df. In case of Python based df, a requirements.txt file needs to be defined which will contain all the necessary dependencies to be installed.
  * Second level subfolders, also put one `flex-template.json`, which is used to define the pipeline options (custom parameters) at runtime.[Example](df/lastflow/flex-template.envsubst.json).


IMPORTANT NOTE: Dataflow in `npe` and `dev` pulls images from snapshot AR, `stg` and `prod` - from release AR.

It is up to each team to build and push a container image and use that versioned container image in their flex-template.json and push that to artifactory for use in their terraform dataflows configuration. For inspiration see the [test/](./test/) folder in this repo along with the [.gitlab-ci.yml](.gitlab-ci.yml) section `lastflow-snapshot` and `pythonflow-snapshot` for container image building and `lastflow-flextemplate-snapshot` and `pythonflow-flextemplate-snapshot` for flex-template build and release.


<a name="df-variables"/>

#### Variables

Please note, dataflow has a dependency on a `buckets_artifact` and `bucket-data` resources named `dataflow` and `dftemp` respectively to be created, please ensure the buckets with EXACT names are in `buckets_artifact` and `bucket_data` in `terraform.tfvars` otherwise dataflow flextemplate and image creation will fail.
Any `src` folder content change will trigger rebuild of images. if no change, the rebuild will be skipped.

Please note, there are three types of dataflow jobs: `static` is suitable to be created by terraform pipeline, and when source code changed, a new updated dataflow image, flextemplate and static dataflow job will be created as new or as an update to running dataflow job on GCP. It might involve draining the previous version of dataflow job and replace with new version. If above standard behavior of terraform does not meet usecase needs, and the running dataflow jobs need to be live-updated without draining/replacing, then this type of dataflow job is not suitable for terraform pipeline to create them... terraform pipeline will still create the image and flextemplate for those `dynamic` dataflow jobs, but the creation and triggering of the dataflow jobs (dynamic dataflow jobs) will be by composer dag. The third type `pipeline` will create a [Dataflow Data Pipeline](https://cloud.google.com/dataflow/docs/guides/data-pipelines) that will create and trigger the dataflow job. This is useful for scheduled batch jobs.

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `host_project` | The host project used to provide shared VPC for all environments. | Yes | `{}` |
| `dataflow_subnet` | When resources need to be created in the shared VPC, a dedicated subnet per environment is needed, most common usage is for dataflow (currently dataflow is the only use case). | Yes | `{}` |
| `dataflows` | Map of objects, key is dataflow job name. | Yes | `{}` |

Please note: var.dataflows variable's key name must match the /df subfolder name and match the `<artifactId>package_name</artifactId>` in the accompanying `pom.xml`

Dataflow object structure:

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------------------------ | --- | --------------------- |
| `type` | Which type of dataflow jobs, the only allowed types are `static`, `dynamic` and `pipeline`. | NO | |
| `flex_template_artifactory_fullurl` | Full https URL to a flex template json file in artifactory. | NO | 
| `region` | Which region to create dataflow in, for now the only allowed regions are `nane1` and `nane2`. | NO | |
| `sdk_language` | Used in `dataflow.tf`, programming language used | NO | |
| `enable_streaming_engine` | Defines is dataflow job should use steaming engine. | NO | |
| `custom_parameters` | (key=value) Parameters passed to the dataflow job | NO | | 
| `worker_machine_type` | Machine type for dataflow ex: n1-standard-4 | NO | |
| `worker_ip_configuration` | Used for Data Pipelines. Allowed values: `WORKER_IP_PUBLIC`, `WORKER_IP_PRIVATE`, `WORKER_IP_UNSPECIFIED`  | YES | `WORKER_IP_PRIVATE` |
| `num_workers` | The number of Compute Engine instances to use when executing your pipeline. | NO ||
| `max_num_workers` |  The maximum number of Compute Engine instances to be made available to your pipeline during execution. Note that this can be higher than the initial number of workers (specified by num_workers) to allow your job to scale up, automatically or otherwise. | NO ||
| `additional_experiments` | variable for `experiments` flag. values as a list. ex:["enable_stackdriver_agent_metrics","enable_google_cloud_profiler","enable_google_cloud_heap_sampling","use_runner_v2"] | NO | |
| `enabled` | Optional variable to enable/disable the dataflow job (default value is `true`)| NO | |
| `on_delete` | Optional variable to specify whether jobs should be drained or canceled on terraform destroy | YES | `drain`
| `skip_wait_on_job_termination` | Optional variable to specify whether terraform should await job teardown on terraform destroy (default value is `true`)| NO ||
| `pipeline_type` | Data Pipeline type. Possible values: `PIPELINE_TYPE_UNSPECIFIED`, `PIPELINE_TYPE_BATCH`, `PIPELINE_TYPE_STREAMING` | YES | `PIPELINE_TYPE_BATCH` | 
| `pipeline_state` | Data Pipeline state. Possible values: `STATE_UNSPECIFIED`, `STATE_RESUMING`, `STATE_ACTIVE`, `STATE_STOPPING`, `STATE_ARCHIVED`, `STATE_PAUSED` | YES |  `STATE_ACTIVE`
| `schedule_cron` | Cron expression for Data Pipeline schedule | YES ||
| `schedule_time_zone` | Time zone for Data Pipeline schedule | YES ||


<a name="dataflow-flextemplate-docker-image-build"/>

#### dataflow-flextemplate-docker-image-build

Dataflow flextemplate docker image builds occur in the `build` stage using kaniko. Details of kaniko can be found here:(<https://cloud.google.com/blog/products/containers-kubernetes/introducing-kaniko-build-container-images-in-kubernetes-and-google-container-builder-even-without-root-access>, <https://docs.gitlab.com/ee/ci/docker/using_kaniko.html>). This is outside of terraform's management. The gitlab pipeline runs kaniko builds in parallel for each dataflow job in df/. Any jobs added to df/ must also be added to the build stage in the .gitlab-ci.yml.

<a name="dataflow-flextemplate-docker-image-build"/>

#### Flex template release
Previous versions of common modules would generate the flex template and upload it to GCS at deploy time. It would expect a metadata.json in your df/$DATAFLOW_JOB/ directory and create a flex template from that. This has been deprecated and is no longer supported. Now the `dataflows` terraform depends on an already released flex templates in artifactory. You specify the full URL to the exact template version with the `flex_template_artifactory_fullurl` attribute. This allows deploying flex template based jobs independent of df/ structure. It decouples the df/$DATAFLOW_JOB structure from deployment and is no longer needed. It allows deploying another team's flex templates requiring no additional code. It also allows deploying multiple dataflow jobs based on the same flex template but with different parameters.

Runtime job parameter values (as defined in the flex template) are configured using the custom_parameters attribute of the dataflow job which accepts key=value pairs.

<a name="dataflow-job-validation"/>
#### Dataflow Job and Template Validation
The google dataflow resource does not provide much help in terms of validating whether a dataflow job deployment will succeed on apply. This creates the situation where terraform plans that have no chance of succeeding are created and potential outages at apply time when existing jobs fail on the creation of the replacement job.

There are some basic validations done within the terraform that will ensure specific job configurations aren't misconfigured in obvious ways such as a missing required parameter or a parameter value not matching the regex defined in the flex template. These validations will fail the plan stage helping to prevent outages.

On top of these basic validations, common modules supports running custom validations created by flex template authors as described below.

Each flex template can have an optional validation script associated with it. Common modules finds this script by trying to download a file published next to the flex template. It has the same name as the flex template except with `-validation` appended to the end. So if a template url is:
- https://artifactory.int.bell.ca/artifactory/npdaadp-generic-snapshot/flex-templates/kafkaavrotobigquery/snapshot.json

then the validation script should be located at:
- https://artifactory.int.bell.ca/artifactory/npdaadp-generic-snapshot/flex-templates/kafkaavrotobigquery/997d7eca.json-validation

This script will be executed by common modules and given a particular job's parameters and the flex template that will be used. It is expected to return a list of validation errors for all errors found. Ideally it does not fail-fast so that the user of the template can try to rectify all the issues in a single commit.

The script should accept a JSON string on STDIN and output a JSON array of strings representing all the validation errors on STDOUT. It will run in the context of the gitlab runner performing the terraform plan so the script should use a language that is supported by that environment. The recommendation is to use python since it is ubiquitous and the standard library has everything required for the task such as working with JSON. The script should also have a shebang as no interpreter is assumed. Common modules just downloads it, sets it as executable and runs it directly. [test/df/pythonflow/validation.py can be used as inspiration](./test/df/pythonflow/validation.py).

This is an example of a plan stage failing validation due to numerous misconfigurations of a particular job:

![image](/uploads/d8cf6880ff962884d79583c5b13c0ff6/image.png)


<a name="dataproc-serverless"/>

### Dataproc

<a name="dp-folders"/>

#### Folders

The structure for creating a Dataproc cluster and submitting jobs for serverless is as follows:

```
.
├── ..
├── dataproc-serverless.tf
├── ..  
├── variables.tf    
│     
```

* The `dataproc-serverless.tf` contains a module which manages Dataproc serverless jobs. It configures running of batch jobs using a specified JAR file and job parameters. The module allows you to define and schedule multiple batch jobs within a Dataproc serverless cluster.
  * The source for this module would be zip file containing the terraform module.
  * The zip module contains terraform files. composer_dag.tf sets up the composer environment, creates bucket object which will hold DAG and config files. dp_jar.tf file contains code to push Jar from Artifact registry to GCS Bucket.
  * Latest Tag can be reffered : [here](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-dataproc-serverless-job-module/-/tags)
  
 
<a name="dp-variables"/>

#### Variables

Provides various input parameters required by the Terraform module, such as:

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `dataproc_serverless_jar_bucket` | The bucket name for storing the JAR file | No |  |
| `artifactory_identity_token` | credentials for Artifactory. | No |  |
| `serverless_jobs` | Map of objects that describes the Composer workflows for dataproc serverless. | No | {} |
| `dataproc_subnet` | Subnetwork for the Dataproc serverless. | No |  |
| `dataproc_serverless_cluster_name` | Name of the Dataproc cluster to be used. | No |  |
| `host_project` | Host project for the VPC. | No |  |
| `composer_environment_name` | Composer name for DAG. | No |  |

##### Serverless job object structure

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `jar_main_class` | Main class in the JAR file. | No |  |
| `jar_file_path` | Path of the JAR file inside the composer workflows | No |  |
| `jar_file_name` | Name of the JAR file inside the composer workflows | No |  |
| `source_url` | Path to artifactory where Jar file (containing Spark/Scala Code) is stored | No |  |

Example : [here](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules/-/blob/master/test/example.envsubst.tfvars)

<a name="dataproc-streaming"/>

<a name="dps-folders"/>

#### Folders

The dataproc job submission to dataproc cluster source code structure is as follows:

```
.
├── ..
├── dataproc-streaming.tf
├── ..  
├── variables.tf    
│     
```

  * The `dataproc-streaming.tf` contains a module which manages Dataproc streaming jobs. It configures running of streaming jobs using a specified JAR file and job parameters. The module allows you to define and schedule multiple streaming jobs within a Dataproc cluster.
  * The source for this module would be zip file containing the terraform module and the DAG file for adding resiliency to the pipeline.
  * The zip module contains terraform files. composer_dag.tf sets up the composer environment, creates bucket object which will hold DAG and config files. dataproc_job.tf contains resource block to submit the Job to the dataproc cluster. dp_jar.tf file contains code to push Jar from Artifact registry to GCS Bucket.
  * The zip module also creates the Directed Acyclic Graph (DAG) which is designed to Manage and monitor the Dataproc streaming job submitted from the terraform Configuration. The config for DAG file is passed through the `config.yaml` file. The config file is been referred in the `composer_dag.tf` file where the bucket object is created on fly and also the config.yaml.
  * The Job submitted to the Dataproc cluster through the Terraform module is in a `RUNNING` or `PENDING` state, the DataprocSubmitJobOperator will not be triggered. If the job is in a `DONE`, `ERROR`, `CANCELLED`, or any state other than `RUNNING` or `PENDING`, the DataprocSubmitJobOperator will be triggered to resubmit the job. This ensures that the streaming job remains active and continuously running. The Job is filtered based on the job-name label which is passed in the dp job submit configuration.
  * Latest Tag can be reffered : [here](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-dataproc-streaming-job-module/-/tags)
  
 
<a name="dps-variables"/>

#### Variables

Provides various input parameters required by the Terraform module, such as:

| Input Variables | Description | Optional | Default  |
| ----------------- | ------------------------------------------------------ |----------|-------------|
| `streaming_jobs` | Map of objects, key would be job name, eg: `dpstreaming` , `dpstreamingworkflow`. Specifies the Composer workflows for dataproc on VMs. | No | {} |
| `dataproc_streaming_jar_bucket` | The bucket name for storing the JAR file | No |  |
| `dp_streaming_sparklogconf` | Configuration for Spark logging. | No |  |
| `dp_streaming_log_info` | Logging level. | No |  |

##### streaming job object structure

| Variable | Description | Optional | Default |
| ----------------- | ------------------------------------------------------ |----------|-------------|
| `jar_file_path` and `jar_file_name` | Path and Name of the JAR file | No |  |
| `dp_job_name_label` | Label for the Dataproc job. | No |  |
| `jar_main_class` | Main class in the JAR file. | No |  |
| `cluster_name` | Name of the Dataproc cluster to be used. | No |  |
| `schdl_interval` | DAG Schedule Interval | No |  |
| `source_url` | Path to artifactory where Jar file (containing Spark/Scala Code) is stored | No |  |
| `args_drivers` | The arguments to be passed to the driver | No |  |

Example : [here](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules/-/blob/master/test/example.envsubst.tfvars)


<a name="composer"/>

### Composer

BigQuery operator by default uses compute from the same project where Airflow is deployed. Ingestion workflow should always use compute from dataeng project, so we create connection from Airflow to dataeng project, connection name is the same as dataeng project name. If you forget to specify connection for BQ operator then your workflow fails, because use case service account has to privileges to run BQ jobs in airflow GCP project.

<a name="com-folders"/>

#### Folders

<a name="com-folders"/>

The composer workflow source code structure is as follows:

```
.
├── com
│   └── dag1
│     └── config.yaml
      └── sql-name.sql
│     └── dag1.py
│   └── dag2
│     └── config.yaml
│     └── dag2.py
│     └── sql
│         └── sql-name.sql
```

All composer workflow source code should be placed under `com` folder in the gitlab project repo.
  - The first level subfolders are the composer workflow names. These names should match the keys used in the "composer_workflow" variable.

In each dag subfolder there are 3 types of files:

- Exactly one `.py` file whose name matches the dag subfolder name. All the dag code should be in this file. It is uploaded into the Cloud Composer bucket `dags/DAG_NAME/` folder.
- One or more `.sql` files to be used by the dag `.py` code. These .sql files can be placed next to the code or in an sql/ directory for cleaner organization. They will be uploaded into the `data/DAG_NAME/sql/` subfolder in the composer bucket.
- One optional `config.yaml` file which is a terraform template used to pass terraform apply time values to the composer dags. Avoid hardcoding static values and instead make use of the terraform template variables such as `tf_env`. By using terraform template variables, the config will be valid in any environment. If more variables are required, contact the common module development team. Below is the list of terraform template variables availble to your config.yaml ([Example config.yaml](df/newworkflow/config.yaml)).

```
tf_airflow_project
tf_dataeng_project
tf_domain
tf_env
tf_region
tf_short_region
tf_use_case
tf_com_bucket 
tf_com_dag
tf_custom_parameters
```

Since version 2.0.0 of the composer module, it is possible to have the module generate the config from the given values when defining the workflows in terraform. So a com/myworkflow/myworkflow.py without the config.yaml template with the following terraform:

```terraform
composer_workflows = {
  myworkflow = {
    config = {
      mykey = "myvalue-${var.env}"
    }
  }
}
```

will generate a config.yaml deployed next to the dag.py code that looks like:

```yaml
config:
  mykey = "myvalue-npe"
metadata:
  airflow_project: "prj-netw-npe-npda-airflow-01"
  com_bucket: "northamerica-northeast1-afl-f7774af8-bucket"
  com_dag: "myworkflow"
  dataeng_project: "prj-gcp-edp-npe-npda-dpltf-01"
  dataproc_service_account: null
  dataproc_subnetwork_uri: null
  domain: "datapltf"
  env: "npe"
  region: "northamerica-northeast1"
  short_region: "nane1"
  use_case: "test"
```
Notice it adds a section `metadata` with the common variables often used in the dags so no need to put them in the `config` section.


#### Dataproc templates

Also new in 2.0.0 is the ability to use dataproc templates. Dataproc templates are JSON files that contain most of the information needed to run a particular dataproc job. They are similar to dataflow flex templates except they are not an official Google technology but are inspired by it. They are created and released in the [templates-dataproc](https://gitlab.int.bell.ca/nbd/smartcore/templates-data-engineering/templates-dataproc) repo.

In order to use dataproc templates, You add a `dataprocs` section to any dag in your `composer_workflows`. This `dataprocs` section allows configuring one or more dataproc jobs. 


The format to configure a dataproc job using a dataproc template is:
```terraform
jobname = {
  dataproc_template_fullurl = REQUIRED: url to released dataproc template in artifactory
  args                      = OPTIONAL: array of cli args that are passed to the job
  properties                = OPTIONAL: map of spark properties
}
```

`jobname` is only to identify the configuration in the dag code and can be anything the user wants.

Example dataproc configuration which adds a single dataproc called `rdbmstogcs` to the `mydag` composer dag:
```terraform
modules "common_modules" {
  dataproc_subnet    = "snet-npda-nane1-dev-01"
  composer_workflows = {
    mydag = {
      dataprocs = {
        rdbmstogcs = {
          dataproc_template_fullurl = "https://artifactory.int.bell.ca/artifactory/dataproc/rdbmstogcs/dataproc-template/latest.json"
          args = [
            "--jdbc-url=jdbc:teradata://EDWTDPROD.bell.corp.bce.ca/database=BA_CURRENT_VIEWS",
            "--jdbc-username=Network_BigData",
            "--jdbc-password=scrt-${var.domain}-${var.env}-${var.use_case}-edw-teradata-fttx-pw",
            "--table=mytable",
            "--output-path=gs://bkt-${var.domain}-${var.env}-nane1-${var.use_case}-dataproc/path/to/output/"
          ]
        }
      }
    }
  }
}
```

This composer_workflows config will generate a section in your config.yaml for use directly with the operator api, so in the mydag.py dag code the config.yaml is read in as usualy and the dataproc configuration is available at `config["dataprocs"]["rdbmstogcs"]`:

```python
dir_path = os.path.dirname(os.path.abspath(__file__))
config_file_path = os.path.join(dir_path, "config.yaml")
with open(config_file_path) as yaml_file:
    configuration = yaml.safe_load(yaml_file)
    pp(configuration)

metadata = configuration["metadata"]

default_args = {
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

suffix="a"
with DAG(
    f"rdbmstogcs_{metadata['use_case']}{suffix}",
    default_args=default_args,
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
) as dag:
    mysparkjob_job = DataprocCreateBatchOperator(
        task_id="rdbmstogcs",
        project_id=metadata["dataeng_project"],
        region=metadata["region"],
        batch=configuration["dataprocs"]["rdbmstogcs"], # IMPORTANT PART HERE
        batch_id=f"rdbmstogcs-{metadata['use_case']}",
        dag=dag,
        gcp_conn_id=metadata["dataeng_project"],
        impersonation_chain=metadata["dataproc_service_account"],
    )
    mysparkjob_job
```

<a name="com-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `composer_environment_name` | Name of the target composer environment | No | `` |
| `composer_workflows` | Map of map of strings, key is composer workflow dag id (both local and remote artifactory-) and the map(string) key-value pairs to pass optional additional parameters to be merged into config.yaml | Yes | `{}` |
| `com_path` | Optional path to where the com/ files are located | Yes | `${path.root}` |

Composer's object structure.

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `sqls` | Set of strings. The .sql file names used in particular workflow. Please note, the composer workflow runs in composer environment pre-created for all use cases. You can reference composer environment by defining `composer_suffix`. |

<a name="dashboard"/>

### Dashboard

<a name="dash-folders"/>

#### Folders

<a name="dash-folders"/>

The dashboard template example json code structure is as follows:

All dashboard template example json codes are under `/dash` folder in gitlab project repo.

* There are currently 6 type of resources (`airflow`, `bigquery`, `cloudfunction`, `dataflow`, `datalake` and `pubsub`) being tenant to dashboard, the file names' first part is matching exactly to the `dashboards` variable keys. The last part is static: `-dashboard.json`. the example templates can be copied to use case project as a starter, use case developers can create their own dashboards as they see fit, follow the same file naming and template variable names to use dashboard.tf to create the dashboards in dataeng-xx project. There are 3 variables can be replaced by terraform runtime resource variables, they are: `${tf_monitored_project}`, `${tf_monitored_usecase}` and `${tf_dashboard_name}`in example code json files.

<a name="dash-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `dashboards` | Set of String, defines type of resources to monitor. Currently offer `airflow`, `bigquery`, `cloudfunction`, `dataflow`, `datalake`, `pubsub` | Yes | `[]` |

<a name="alert-channels"/>

### Alert Channels

<a name="altch-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `alert_channels` | Map of Objects, defines alert channels of various types. | Yes | `{}` |

Alert Channel object structure, all object's fields are mandatory and don't have default values:

| Variable | Description |
| ----------------- | ------------------------------------------------------ |
| `channel_type` | Which type of alert channel, the only allowed types include `email`,`sms`,`pagerduty`,`slack`,`webhooks`,`pub/sub`,`mobile app` | No |  |
| `display_name` | String, friendly name to be displayed in GUI. | No |  |
| `enabled` | Bool, activate this channel or not | No |  |
| `labels` | Map of strings, used to provide relevant value to the channel_type, for exmaple, phone `number` to `sms` type; or `email_address` to `email` type; or `slack notification chanel` type for `slack` See [documentation](https://cloud.google.com/monitoring/support/notification-options?_ga=2.262843788.-162307305.1654667144&_gac=1.175908118.1654667191.EAIaIQobChMI5I2Bt5Od-AIVRDVyCh3xkQvwEAAYASAAEgLXcPD_BwE#email) for more details.   | No |  |

<a name="alert-policies"/>

### Alert Policies

<a name="alt-folders"/>

#### Folders

Alert policies are configured using JSON template files (ex: [./test/alt/bigquery-alert.json](./test/alt/bigquery-alert.json)). These files are templates that are passed through terraforms `templatefile()` function which provide template variables to use within the policy files. Currently the following template variables are available `${tf_monitored_project}`, `${tf_monitored_usecase}`, `${tf_alert_name}`, `${tf_env}`, `${tf_use_case}`, `${tf_domain}` along with a set of bucket name variables described next. Each bucket defined in `buckets_data` and `buckets_artifact` has a template variable with the format `tf_<IDENTIFIER>_<TYPE>_bucket_name`. The `<TYPE>` is either `data` or `artifact` and corresponds to the buckets configuration vars buckets_data or buckets_artifact. The `<IDENTIFIER>` corresponds to the identifier given within the buckets_data/buckets_artifact configuration. For example `${tf_landing_data_bucket_name}` corresponds to the bucket name for `var.buckets_data["landing"]` bucket.

By default common-modules picks up these files in the folder `${path.cwd}/alt/` which works out of the box if you are using common-modules by cloning it into your project. If your needs are different you can specify the location of the `alt/` folder using the optional `alt_path` variable. For example when your project's deployment is a terraform module under `terraform/` folder you can store your policies under `terraform/alt/` allowing the CI to scoop them up with the terraform module. In your terraform, within your `module` block, you would use `alt_path = "${path.module}/alt"`.

Specify one or more of the following alert types in the `alerts` variable: `airflow`, `bigquery`, `cloudfunction`, `dataflow`, `datalake`, `pubsub` and `cloudrun`. Each alert specidied in the `alerts` will need a policy defined under the `alt_path` folder. The file name should have the format ALERT-alert.json, ex: `airflow-alert.json`, `bigquery-alert.json`, etc.

<a name="alt-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `alerts` | Set of String, defines type of resources to alert on. Currently offer `airflow`, `bigquery`, `cloudfunction`, `dataflow`, `datalake`, `pubsub`, `cloudrun`, `bigtable` | Yes | `[]` |
| `alt_path` | path to alt/ folder containing alert policy files in json format | Yes | `"${path.cwd}/alt"` |

<a name="secrets"/>

### Secrets

Create a slot for the secret in Secret Manager.

<a name="scrt-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `secrets` | Set of String, defines name of secrets. | Yes | `[]` |
| `secret_accessors` | Set of String, defines a set of members for accessing created secrets. | Yes | `[]` |
| `create_secret_version` | Boolean, defines if a random secret version would be created or not. | Yes | `true` |
| `secret_values` | Map of secret name -> secret values used to create secret versions. Will take precendent over the random values created if create_secret_version is true. Should be base64 encoded. | Yes | `{}` |

<a name="bucket-files-variables"/>

#### Variables


| Variable       | Description | Optional | Default |
|----------------| ------------------------------------- |----------|---------|
| `bucket_files` | List of files to be uploaded to specified GCS buckets, referenced by bucket key. Each entry in the list is an object with the following fields: | No       | NA      |
| -`bucket_name` | The name of the GCS bucket (referenced in buckets_data) to which the file will be uploaded. | No       | NA      |
| -`source`      | The local or remote path of the file to be uploaded. | No       | NA      |
| -`destination` | The destination path within the GCS bucket where the file will be stored. | No       | NA      |


<a name="logsinks"/>

### Logsinks

<a name="logsink-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `cross_project_logsink_service` | Set of String, defines name of services that needs to sink logs to bigquery dataset named `logsink` per domain/usecase. Currently offer `cloud_function`, `dataflow_job`, `pubsub_subscription`, `pubsub_topic` | Yes | `[]` |

<a name="slos"/>

### SLOs

<a name="slo-folders"/>

#### Folders

All slos template example json codes are under `/slo` folder in gitlab project repo. Check those files to better understand the structure of json SLO definition.
The SLOs template example json code structure is as follows:

```
{
  "displayName": "${tf_slo_name}", <== Keep it a variable.
  "goal": 0.9,
  "rollingPeriod": "604800s",      <== Compliance period, should be either calendar or rolling.
  "serviceLevelIndicator": {
    "requestBased": {              <== Evaluation method, sould be request or window based.
      "distributionCut": {         <== Request based evaluation supports goodTotalRatio and distributionCut; windows based - goodBadMetricFilter, goodTotalRatioThreshold, metricSumInRange, metricMeanInRange.
        "distributionFilter": "metric.type=\"pubsub.googleapis.com/topic/message_sizes\" resource.type=\"pubsub_topic\"", <== Definition is different per evaluation methods, see examples for details.
        "range": {
          "min": null,
          "max": 10000
        }
      }
    }
  }
}
```

* There are currently 6 type of services (`airflow`, `bigquery`, `cloudfunction`, `dataflow`, `datalake` and `pubsub`) being tenant to SLOs, the file names' first part is matching exactly to the `slo_services` variable keys. The middle part is static: `-slo-`. The last part is slo name. The example templates can be copied to use case project as a starter, use case developers can create their own slos as they see fit, follow the same file naming and template variable names to use slo.tf to create the slos in dataeng-xx project. These variables can be replaced by terraform runtime resource variables: `${tf_monitored_project}`, `${tf_monitored_usecase}`, `${tf_slo_name}`, `${tf_composer_cluster}` and `${tf_service_id}` in example code json files.

You can find more information in the [official documentation](https://cloud.google.com/stackdriver/docs/solutions/slo-monitoring/ui/create-slo).

<a name="slo-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `slo_services` | Set of String, defines name of services that needs slo. Currently offer `airflow`, `bigquery`, `cloudfunction`, `dataflow`, `datalake`, `pubsub`. the slo itself is named after the json file name | Yes | `[]` |

<a name="log-metric"/>

### Log Metrics

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `name` | Name of the metric | no | |
| `filter` | An advanced logs filter (<https://cloud.google.com/logging/docs/view/advanced-filters>) which is used to match log entries. | no |  |
| `bucket_name` | Custom Log bucket name where log metric would be defined against. Must be with-in the project. If specifed needs to be in the format `projects/{project-id}/locations/{log-bucket-location}/buckets/{bucket-name}` | yes | `"projects/{var.dataeng_project}/locations/global/buckets/_Default"` |
| `metric_kind` | Whether the metric records instantaneous values, changes to a value, etc  | no |  |
| `value_type` | Whether the measurement is an integer, a floating-point number, etc. For counter metrics, set this to `INT64`. Possible values are `BOOL`, `INT64`, `DOUBLE`, `STRING`, `DISTRIBUTION`, and `MONEY`. | no | |
| `labels` | labels block consisting of map of key and value  | no | |
| `label_key` | The label key  |  |  |
| `label_value_type` | The type of data that can be assigned to the label. Default value is STRING. Possible values are `BOOL`, `INT64`, and `STRING` |  | `STRING` |
| `label_description` | description of this label|  |  |
| `label_extractor` | label key string to an extractor expression which is used to extract data from a log entry field and assign as the label value.  |  | null |
|`value_extractor`| A valueExtractor is required when using a distribution logs-based metric to extract the values to record from a log entry. Two functions are supported for value extraction - EXTRACT(field) or REGEXP_EXTRACT(field, regex). | no | |
|`bucket_options`| The bucketOptions are required when the logs-based metric is using a DISTRIBUTION value type and it describes the bucket boundaries used to create a histogram of the extracted values | no | |

<a name="custom-metric"/>

### Custom-metric

Custom metrics are used to define custom monitoring metrics in Google Cloud Monitoring. Each metric is identified by a unique name and includes various attributes such as `display_name`, `description`, `metric_kind`, and `value_type`. `labels` can be added to provide additional context to the metric data.

Please note that the `name` field in the `custom_based_metrics` variable is used as the key in the map and is not a field within the object itself. Make sure to define the custom metric with the `name` as the map key to ensure proper resource creation.

## Variables

| Variable       | Description                                                                                                   | Optional | Default   |
|----------------|---------------------------------------------------------------------------------------------------------------|----------|-----------|
| `display_name` | Display name for the custom metric                                                                            | no       |           |
| `description`  | Description of the custom metric                                                                              | no       |           |
| `metric_kind`  | Specifies the kind of metric. Possible values: `GAUGE`, `DELTA`, `CUMULATIVE`                                 | no       |           |
| `value_type`   | Specifies the type of measurement. Possible values: `BOOL`, `INT64`, `DOUBLE`, `STRING`, `DISTRIBUTION`, `MONEY` | no       |           |
| `unit`         | Unit of measurement for the metric                                                                            | no       |           |
| `labels`       | Labels block consisting of a set of key-value pairs                                                           | yes      |           |
| `key`          | The label key                                                                                                | yes      |           |
| `value_type`   | The type of data that can be assigned to the label. Default value is `STRING`. Possible values are `BOOL`, `INT64`, and `STRING` | yes | `STRING` |
| `description`  | Description of this label                                                                                     | yes      |           |


<a name="hidden-variables"/>

### Hidden variables

If you are using `make` to deploy then you don't need to set them, values are populated automatically from gitlab environment variables.

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `env` | Environment name, allowed values: `npe`, `dev`, `stg`, `prod`. | Yes | `$CI_ENVIRONMENT_NAME` |
| `gitlab_project` | Name of the gitlab project which deploys the use case. | Yes | `$CI_PROJECT_NAME` |

<a name="cloud-run-job"/>

### Cloud Run Job

<a name="crjob-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `cloud_run_jobs` | Map of Objects, defines a set of various cloud run jobs. | Yes | `{}` |

Unless a default value is specified, all the object's fields are mandatory except for `env_vars` and `env_secret_vars`, which are optional.

| Variable | Description | Default |
| -------- | ----------- | ------- |
| `region` | Cloud Run Job region, for now the only allowed regions are `nane1` and `nane2`. ||
| `image` | Specifies the image the cloud run job needs to execute. ||
| `vpc_connector` | The VPC Network Connector that this cloud run job can connect to. It should be set up as fully-qualified URI. The format of this field is projects/\*/locations/\*/connectors/*.||
| `CPU` | The only supported values for CPU are '1', '2', '4', and '8'. ||
| `memory` | Specifies the memory specification for the cloud run job. ||
| `timeout` | Specifies the maximum amount of time the job runs per try. |`"600s"`|
| `env_vars` | (Optional) List of environment variables to set in the container. Contains name and value pairs. ||
| `env_secret_vars` | (Optional) List of environment variables to set in the container. Contains source for the environment variable's secret value and define secret, secret name and it's version. ||

<a name="cloud-run-v2-service"/>

### Cloud Run V2 Service

<a name="crs-v2-service-variables"/>

#### Variables

| Variable | Description | Optional | Default |
| ----------------- | ------------------------------------- | -------- | --------- |
| `cloud_run_v2_services` | Map of Objects, defines a set of various cloud run v2 services. | Yes | `{}` |

Unless a default value is specified, all the object's fields are mandatory.

| Variable | Description | Default | Optional |
| -------- | ----------- | ------- | -------- |
| `region` | Cloud Run V2 Service region. Allowed regions are `nane1` and `nane2`. | | No |
| `image` | Specifies the image the cloud run job needs to execute. | | No |
| `cpu` | Supported values for CPU are '1', '2', '4', and '8'. | | No |
| `memory` | Specifies the memory specification for the cloud run v2 service. | | No |
| `timeout` | Maximum amount of time the job runs per try. | `"600s"` | Yes |
| `members` | List of IAM members as string. [IAM members must have one of the values outlined here](https://cloud.google.com/billing/docs/reference/rest/v1/Policy#Binding) | | Yes |
| `cpu_idle` | Specifies if the CPU should be allowed to idle. | `true` | Yes |
| `startup_cpu_boost` | Specifies if the CPU should have a startup boost. | `false` | Yes |
| `scaling` | Configuration for scaling options, including minimum and maximum instance counts. | `{"min_instance_count": 0, "max_instance_count": 10}` | Yes |
| `vpc_access` | Configuration for VPC access, including the connector name and egress settings. | | No |
| `env_vars` | List of environment variables to set in the container. Contains name and value pairs. | | Yes |
| `env_secret_vars` | List of environment variables to set in the container. Contains source for the environment variable's secret value and define secret, secret name, and its version. | | Yes |
| `liveness_probe` | Configuration for liveness probes, including initial delay, timeout, and HTTP get path. | | Yes |
| `startup_probe` | Configuration for startup probes, similar to liveness probes but used at startup. | | Yes |
| `volumes` | Configuration for mounting volumes, including secrets, cloud SQL instances, and more. | | Yes |
| `volume_mounts` | Configuration for where volumes should be mounted within the container. | | Yes |


<a name="common_config"/>

### Common Config

* at root level, there is a folder named `common_config`. This is the place some common config are kept, to be shared by dataflow, cloud funciton and library developers when they config their access to Bell's private Artifact Registry, and for dataflow, also the flextemplate template is stored in this folder and called by  `dataflow.tf` modules when creating flextemplates

  * `flextemplate.json`, which is used in generating flextemplate json file in preparation for launching felxtemplate dataflow jobs. [Example](common_config/flextemplate.json). This file is shared by all dataflow jobs and is to be used without modification. otherwise it might cause json parsing error when launching dataflow jobs.
  * `settings.xml` is shared by all dataflow jobs, library package builds. the purpose of this file is to provide the proxy setting to enable maven to download dependendies, extensions and plugins from internet repo.
  * `pom.insert.example.xml`, this file's content need to be inserted into each and every `pom.xml` accompanying the source code in dataflows, cloud functions and libraries to provide config for Bell Artifact Registry repo, as well as `wagon` credential helper to enable to access to the repo
This folder needs to be copied to use case project pipeline repo

<a name="security"/>

# Bell Corporate Security Requirements

Cloud Native Services Security Scorecard:
https://confluence.bell.corp.bce.ca/display/NBD/EDP+Cloud+Native+Services+Security+Requirements

The following settings/configurations must be left up to Google to manage on behalf of Bell
* None of Google's default security settings can be disabled (DR10)
* Encryption at rest within GCP must not be disabled (ER1)
* Default security confguration must not be altered during initial configuration of the GCP services (H3)

DR8 - Configuration/settings files are found at the following location (ephemeral deployment for testing): https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules/-/blob/master/test/example.envsubst.tfvars

DR9 - Application dependencies and versioning is found at the following location: https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules/-/blob/master/pyproject.toml
