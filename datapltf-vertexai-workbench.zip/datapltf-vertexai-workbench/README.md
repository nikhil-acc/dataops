# Vertex AI notebooks


## Prerequisites

The gitlab runner that's used to deploy Vertex AI notebooks requires the following perimssions:

- **Vertex AI notebooks and Cloud Storage Buckets**:
  - "roles/notebooks.admin",
  - "roles/storage.admin",
  - "roles/resourcemanager.projectIamAdmin"
- **Service account**:
  - "roles/iam.serviceAccountAdmin",
  - "roles/iam.serviceAccountUser"
- **BigQuery (optional)**:
  - "roles/bigquery.dataEditor"


## Variables Limitations
| Feild Name| limitations |
| ---      | ---      |
| project  | Only `a-z`,  `0-9` and `-` are allowed in project name |
| region   | Only `nane1` |
| env      | Only `npe` or `prod` |
| domain.  | Valid values for business domain are (`media`, `tv`, `iot`, `busnet`, `datapltf`, `dp`, `topology`, `nso`, `internet`, `charging`, `nc`, `unifcomm`, `wlnaccess`, `wlncore`, `wlsscore`, `wlssaccess`, `financewf`, `ticketing`).|
| use_case | Less than 12 characters. Only a-z0-9- are allowed.|
| owner_primary_pein |Only a-z0-9- are allowed. |
| owner_secondary_pein |Only a-z0-9- are allowed. |
| machine_type| Machine type must be one of `n1-standard-1`, `n1-standard-2`, `n1-standard-4`, `n1-standard-8`, `n2-standard-2`, `n2-standard-4`, `n2-standard-8`, `n2-standard-16`.|
| boot_disk_type | Valid values for GPU accelerator type are (`DISK_TYPE_UNSPECIFIED`, `PD_STANDARD`, `PD_SSD`, `PD_BALANCED`, `PD_EXTREME`). |
| boot_disk_size_gb | Between 2 to 500|
| location |Default `northamerica-northeast1-a`. Location must have pattern of 'continent-region-zone'. Please refer to https://cloud.google.com/compute/docs/regions-zones. |
| network |Network must have pattern of 'projects/your_project_name/global/networks/your_network_name'. |
| subnet |Subnet must have pattern of 'projects/your_project_name/regions/your_region/subnetworks/your_subnet_name'. |
| instance_owners |A valid list of AD groups|
| vm_image_project | Defalut `deeplearning-platform-release`; Must have pattern of 'projects/{project_id}'.|
| vm_image_family |Default `common-cpu`; Valid values for VM image family are (`common-cu113`, `common-cu110`, `common-cpu`, `tf-ent-latest-gpu`, `tf-ent-latest-cpu`, `tf-latest-gpu`, `tf-latest-cpu`, `pytorch-latest-gpu`, `pytorch-latest-cpu`). |
| bucket_age | Default to 360, between 1 to 730  |
| gpu_accelerator_type | Optional. Valid values for GPU accelerator type are (`ACCELERATOR_TYPE_UNSPECIFIED`, `NVIDIA_TESLA_P4`, `NVIDIA_TESLA_T4`). |
| gpu_core_count |Optional. Between 1 to 8 |

## Sample inputs

It is expected that you've already created your exploration google cloud project and have asked Bell hybrid cloud to create a /27 subnet that is ICN compliant. 
Please read 'Variables Limitations' for all variables validation rules. Inputs wrapped in quotes are strings.

- To deploy a notebook in 'gcp-project-a' for the following AD groups 'ad_group_1@bell.ca' and 'ad_group_2@bell.ca'. 
This will create a single notebook, bucket and custom service account which has exclusive access to all resources for each group provided.

```hcl
inputs = {
  project              = "gcp-project-a"
  env                  = "env"
  domain               = "domain"
  use_case             = "use_case"
  owner_primary_pein   = "owner_primary_pein"
  owner_secondary_pein = "owner_secondary_pein"
  machine_type         = "machine_type"
  boot_disk_type       = "boot_disk_type"
  boot_disk_size_gb    = boot_disk_size_gb
  instance_owners      = ["ad_group_1@bell.ca", "ad_group_2@bell.ca"]
  network              = "projects/gcp-project-a/global/networks/vpc-netw-env-domain-env-name-01"
  subnet               = "projects/gcp-project-a/regions/region/subnetworks/snet-domain-env-name-01"
}
```

- To deploy a notebook with gpu in 'gcp-project-b' for the following AD groups 'ad_group_1@bell.ca'. 
This will create a single notebook, bucket and custom service account which has exclusive access to all resources for ad_group_1.

```hcl
inputs = {
  project              = "gcp-project-b"
  env                  = "env"
  domain               = "domain"
  use_case             = "use_case"
  owner_primary_pein   = "owner_primary_pein"
  owner_secondary_pein = "owner_secondary_pein"
  machine_type         = "machine_type"
  boot_disk_type       = "boot_disk_type"
  boot_disk_size_gb    = boot_disk_size_gb
  instance_owners      = ["ad_group_1@bell.ca"]
  network              = "projects/gcp-project-b/global/networks/vpc-netw-env-domain-env-name-01"
  subnet               = "projects/gcp-project-b/regions/region/subnetworks/snet-domain-env-name-01"
  gpu_accelerator_type = "gpu_accelerator_type"
  gpu_core_count       = gpu_core_count
}
```


## Help

For questions, comments, concern etc. please reach out to Yuecai Zhu: yuecai.zhu@bell.ca.