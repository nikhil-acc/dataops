def pytest_addoption(parser):
    parser.addoption("--tfstate_bucket", action="store", default="")
    parser.addoption("--tfstate_prefix", action="store", default="")