from google.cloud import storage
import json
import logging
import logging.config
import pytest
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

# read logging configuration file and create logger
logging.config.fileConfig('logging.conf')
logger = logging.getLogger('notebook')


@pytest.fixture(scope="module")
def storage_client():
    # create a client
    return storage.Client()


@pytest.fixture(scope="module")
def get_notebook_bucket_iam_policies(pytestconfig, storage_client):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption("--tfstate_bucket")
    blob_name = pytestconfig.getoption("--tfstate_prefix")

    # connnect to terrafrom state bucket on gcp
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    try:
        # filter and return only notebook_bucket_iam_policies resource
        notebook_bucket_iam_policies = [
            resource["instances"] for resource in resources if resource["name"] == "notebook_bucket_iam_policies"
        ]

        return [instance["attributes"]["id"] for instance in notebook_bucket_iam_policies[0]]
    except IndexError as e:
        logger.error("Google notebook bucket IAM policies do not exist in state file!.", e)
        return []


def test_google_notebooks_buckets_iam_policies(get_notebook_bucket_iam_policies, storage_client):
    # initalise variables
    result = 0
    formatted_instance_information = {}
    binding = []

    # format instance data so it is easy to process. result = { bucket: service account }
    for instance in get_notebook_bucket_iam_policies:
        formatted_instance_information[instance.split(
            "/")[1]] = instance.split("/")[4]

    # loop through each bucket and and ensure its service account has binding policy on it, if not add 1 to result
    for bucket_name in formatted_instance_information.keys():
        bucket = storage_client.bucket(bucket_name)
        policy = bucket.get_iam_policy(requested_policy_version=3)

        # filter and return only bindings that have the role of "roles/storage.objectUser" which we gave our custom service account in the module
        binding = [binding["members"] for binding in policy.bindings if binding["role"]
                   == "roles/storage.objectUser"]

        if formatted_instance_information[bucket_name] not in binding[0]:
            result += 1
            logger.error("{} does not have policy binding on {} ".format(
                formatted_instance_information[bucket_name], bucket_name))

    assert result == 0
