from google.cloud import storage
from google.cloud import notebooks_v1
import json
import pytest
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)


@pytest.fixture(scope="module")
def notebooks_client():
    # create a client
    return notebooks_v1.NotebookServiceClient()


@pytest.fixture(scope="module")
def get_notebook_resource(pytestconfig):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')

    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    try:
        # filter and return only google_notebooks_instance resource ids
        google_notebooks_instances = [
            resource['instances'] for resource in resources if resource["type"] == "google_workbench_instance"
        ]

        return [instance['attributes']['id'] for instance in google_notebooks_instances[0]]
    except IndexError as e:
        raise ("Google notebook instance(s) do not exist in state file!")


def test_google_notebooks_instance_exists(notebooks_client, get_notebook_resource):
    # get parent from first notebook resource in list as it will be common to all resources as per module design.
    notebook_parent = '/'.join(get_notebook_resource[0].split('/')[0:4])

    # initialize request argument(s)
    request = notebooks_v1.ListInstancesRequest(parent=notebook_parent,)

    # make the request
    page_result = notebooks_client.list_instances(request=request)
    result = []

    # store the response in list
    for response in page_result:
        result.append(getattr(response, 'name'))

    # compare instance id(s) in state file to instances in the cloud.
    assert result.sort() == get_notebook_resource.sort()
