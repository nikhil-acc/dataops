# Dataproc



## Prerequisites

Gitlab runner that's used to deploy Dataproc requires the following perimssions:

- **Dataproc**:
  - "roles/dataproc.admin",
  - "roles/storage.admin",
  - "roles/resourcemanager.projectIamAdmin",
  - "roles/servicemanagement.quotaAdmin",
- **Network and FW rules (optional)**:
  - "roles/compute.networkAdmin", 
  - "roles/compute.securityAdmin",
  - "roles/compute.admin",
- **Service account (optional)**:
  - "roles/iam.serviceAccountAdmin"

# Bell Corporate Security Requirements

EDP Dataproc Security Scorecard:
https://confluence.bell.corp.bce.ca/display/NBD/EDP+Dataproc+Security+Requirements

The following settings/configurations must be left up to Google to manage on behalf of Bell
* None of Google's default security settings can be disabled (DR10)
* Encryption at rest within GCP must not be disabled (ER1)
* Default security confguration must not be altered during initial configuration of the GCP services (H3)

DR8 - Configuration/settings files are found at the following location (ephemeral deployment for testing): https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-dataproc-module/-/blob/main/test/terragrunt.hcl

DR9 - Application dependencies and versioning is found at the following location (OS image): https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-dataproc-module/-/blob/main/test/terragrunt.hcl#L33

