from google.cloud import storage
from google.cloud import dataproc_v1 as dataproc
import pytest
import json
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


@pytest.fixture(scope="module")
def dataproc_cluster_client(remote_state):
    # create a client
    region = remote_state["instances"][0]["attributes"]["region"]
    return dataproc.ClusterControllerClient(
        client_options={
            "api_endpoint": f"{region}-dataproc.googleapis.com:443"}
    )


@pytest.fixture(scope="module")
def remote_state(pytestconfig):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')

    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    # filter and return only dataproc resource
    for resource in resources:
        if resource["type"] == "google_dataproc_cluster":
            return resource
    return


def test_cluster_exists(dataproc_cluster_client, remote_state):
    # get service information from metastore_resource
    project = remote_state["instances"][0]["attributes"]["project"]
    region = remote_state["instances"][0]["attributes"]["region"]
    cluster_name = remote_state["instances"][0]["attributes"]["name"]

    # initialize request argument, make request and check response
    result = dataproc_cluster_client.get_cluster(
        request={
            "project_id": project,
            "region": region,
            "cluster_name": cluster_name,
        }
    )
    assert result.status.state == 2, f"Expected cluster status is RUNNING(2), actual status is {result.status.state}"  # noqa: E501
