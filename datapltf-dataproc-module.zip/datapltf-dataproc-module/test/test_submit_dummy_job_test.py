from google.cloud import storage
from google.cloud import dataproc_v1 as dataproc
import pytest
import re
import json
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


@pytest.fixture(scope="module")
def dataproc_cluster_client(remote_state):
    # create a client
    region = remote_state["region"]
    return dataproc.JobControllerClient(
        client_options={
            "api_endpoint": f"{region}-dataproc.googleapis.com:443"}
    )


@pytest.fixture(scope="module")
def remote_state(pytestconfig):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')

    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    results = {}

    # filter dataproc and artifact bucket resource ids
    resource_ids = [
        resource["instances"][0]["attributes"]["id"] for resource in resources
        if resource["name"] in ("artifacts_bucket", "dataproc_cluster")
    ]

    try:
        # format and return results
        for id in resource_ids:
            if id.startswith("bkt"):
                results['artifacts_bucket'] = id
            else:
                cluster_info = id.split('/')
                results['project'] = cluster_info[1]
                results['region'] = cluster_info[3]
                results['cluster'] = cluster_info[5]
        return results
    except IndexError as ie:
        print("Error:{}".format(ie))


def test_submit_dummy_job(dataproc_cluster_client, remote_state):
    # set relevant variables
    file_name = 'dummy_job.py'
    bucket_name = remote_state['artifacts_bucket']

    # connnect to artifact bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    # upload dummy_job for testing purposes
    blob = bucket.blob(file_name)
    blob.upload_from_filename('./artifacts/{}'.format(file_name))

    # create the job config
    job = {
        "placement": {"cluster_name": remote_state['cluster']},
        "pyspark_job": {
            "main_python_file_uri": "gs://{}/{}".format(bucket_name, file_name),
        },
    }

    # initialize request argument
    request = dataproc.SubmitJobRequest(
        project_id=remote_state["project"],
        region=remote_state["region"],
        job=job,
    )

    # make request and check response
    try:
        response = dataproc_cluster_client.submit_job_as_operation(
            request=request).result()

        # dataproc job output gets saved to the GCS bucket allocated to the job.
        # Use a regex to obtain the bucket and blob info.
        matches = re.match("gs://(.*?)/(.*)",
                           response.driver_output_resource_uri)

        output = (
            storage.Client()
            .get_bucket(matches.group(1))
            .blob(f"{matches.group(2)}.000000000")
            .download_as_bytes()
            .decode("utf-8")
        )
    except Exception as e:
        print(e)

    # perform cleanup
    blob.delete()

    assert output, "Expected output. Job failed"
