from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

spark = SparkSession.builder.appName('dummy_spark_job').getOrCreate()

schema = StructType([
    StructField('k', StringType(), True), StructField(
        'v', IntegerType(), False)
])

df = spark.createDataFrame([], schema)

df.show()
