from google.cloud import storage
from google.cloud import metastore_v1
import json
import pytest
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)


@pytest.fixture(scope="module")
def metastore_client():
    # create a client
    return metastore_v1.DataprocMetastoreClient()


@pytest.fixture(scope="module")
def get_metastore_resource(pytestconfig):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')

    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    # filter and return only metastore resource
    metastore_service_resource = [
        resource for resource in resources
        if resource["type"] == "google_dataproc_metastore_service"]

    try:
        return metastore_service_resource[0]
    except IndexError:
        raise ("Metastore service does not exist in state file!")


def test_metastore_service_exists(metastore_client, get_metastore_resource):
    # get service information from metastore_resource
    project = get_metastore_resource["instances"][0]["attributes"]["project"]
    location = get_metastore_resource["instances"][0]["attributes"]["location"]
    service_id = get_metastore_resource["instances"][0]["attributes"]["service_id"]

    # build service location_id
    service = f"projects/{project}/locations/{location}/services/{service_id}"

    # initialize request argument
    request = metastore_v1.GetServiceRequest(
        name=service,
    )

    # make request and check response
    response = metastore_client.get_service(request=request)
    assert response.state == 2, f"Expected service status is RUNNING(2), actual status is {response.state}"  # noqa: E501
