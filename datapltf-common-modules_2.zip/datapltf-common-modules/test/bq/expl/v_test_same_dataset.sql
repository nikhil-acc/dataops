SELECT * from `${project}.${dataset}.table_with_no_partition` LIMIT 10;
