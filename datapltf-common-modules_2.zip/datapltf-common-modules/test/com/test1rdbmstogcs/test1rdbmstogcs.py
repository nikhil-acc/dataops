import os
from datetime import datetime, timedelta
from pprint import pp
from time import time

import airflow
import yaml
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.google.cloud.operators.dataproc import (
    DataprocCreateBatchOperator,
)
from google.cloud.dataproc_v1.types import Batch

dir_path = os.path.dirname(os.path.abspath(__file__))
config_file_path = os.path.join(dir_path, "config.yaml")
with open(config_file_path) as yaml_file:
    configuration = yaml.safe_load(yaml_file)
    pp(configuration)

metadata = configuration["metadata"]

default_args = {
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}


with DAG(
    f"rdbmstogcs_{metadata['use_case']}",
    default_args=default_args,
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
) as dag:
    ts = str(int(time()))
    mysparkjob_job = DataprocCreateBatchOperator(
        task_id="rdbmstogcs_create_dataproc_task",
        project_id=metadata["dataeng_project"],
        region=metadata["region"],
        batch=configuration["dataprocs"]["rdbmstogcs"],
        batch_id=f"rdbmstogcs-{metadata['use_case']}-{ts}",
        dag=dag,
        gcp_conn_id=metadata["dataeng_project"],
    )
    mysparkjob_job
