import os


def env_vars(request):
    return os.environ.get('FOO', 'Specified environment variable is not set.')
