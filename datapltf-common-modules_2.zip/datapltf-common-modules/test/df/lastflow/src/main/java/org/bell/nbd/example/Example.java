package org.bell.nbd.example;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.SimpleFunction;

public class Example {

  public interface MyOptions extends PipelineOptions {
    @Description("Output bucket name")
    @Default.String("bkt-datapltf-npe-nane1-alert-dataflow")
    String getOutputBucket();
    void setOutputBucket(String outputBucket);
  }

  public static void main(String[] args) {
    PipelineOptionsFactory.register(MyOptions.class);
    MyOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(MyOptions.class);
    Pipeline p = Pipeline.create(options);

    p.apply(Create.of("Hello", "World"))
     .apply(MapElements.via(new SimpleFunction<String, String>() {
        @Override
        public String apply(String input) {
          return input.toUpperCase();
        }
      }))
     .apply(TextIO.write().to("gs://" + options.getOutputBucket() + "/output.txt"));
    System.out.println("Output file: gs://" + options.getOutputBucket() + "/output.txt");
    // Loop and wait to simulate long running dataflow job
    for (int i = 0; i < 10; i++) {
      System.out.println("Processing... " + i);
      try {
        Thread.sleep(5000);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }

    p.run();
  }
}
