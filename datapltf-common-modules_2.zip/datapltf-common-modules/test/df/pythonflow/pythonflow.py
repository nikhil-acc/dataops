import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions


class MyOptions(PipelineOptions):
    @classmethod
    def _add_argparse_args(cls, parser):
        parser.add_argument(
            '--outputBucket',
            dest='outputBucket',
            # Set your default bucket name here
            default='bkt-datapltf-npe-nane1-alert-dataflow',
            help='Output bucket name'
        )


def run():
    options = MyOptions()
    pipeline = beam.Pipeline(options=options)

    outputBucket = options.outputBucket  # Retrieve the bucket name from options

    (pipeline
     | 'CreateInput' >> beam.Create(['Hello', 'World'])
     | 'Uppercase' >> beam.Map(lambda x: x.upper())
     | 'WriteToGCS' >> beam.io.WriteToText('gs://{}/outputPython.txt'.format(outputBucket))
     )

    result = pipeline.run()
    result.wait_until_finish()


if __name__ == '__main__':
    run()
