#!/usr/bin/env python3
"""
An example validation script which will be run on terraform plan and will be given the flex template and 
job parameters for a specific job. It will run various validations in order to detect any problems
with the job or template at plan time. This avoids outages at apply time when TF plans that have no
chance of succeeding are run and destroy an existing job just to fail on the creation of the replacement
job.

Some of this can be reused such as the parse_script_input() and output_errors() functions. See validation_test.py
for an example of tests for this script. Also see REPO_ROOT/scripts/flextemplate-build.sh for example
release code which will release the validation script to artifactory if it exists.
"""
import json
import os
import random
import sys
from typing import cast, Dict, Iterable, TextIO, Tuple, TypedDict

JsonEncodedString = str


class ScriptInput(TypedDict):
    """The input that will be fed on STDIN to the validation script we received on our STDIN."""

    job_parameters: JsonEncodedString
    flex_template: JsonEncodedString


FlexTemplate = Dict
JobParameters = Dict


def parse_script_input(fp: TextIO) -> Tuple[JobParameters, FlexTemplate]:
    """
    Not used in this script. This is for validation scripts to parse their STDIN
    and return the elements passed in.
    """
    script_input = cast(ScriptInput, json.load(fp))
    if "flex_template" not in script_input:
        raise RuntimeError("Flex")
    if "job_parameters" not in script_input:
        raise RuntimeError("Job")
    return json.loads(script_input["job_parameters"]), json.loads(
        script_input["flex_template"]
    )


def output_errors(errors: Iterable[str], fp: TextIO = sys.stdout):
    json.dump(list(errors), fp)


def job_has_output_bucket(job_parameters: JobParameters) -> Iterable[str]:
    if "outputBucket" not in job_parameters:
        yield "Job is missing a value for the required 'outputBucket' parameter."
    elif not job_parameters["outputBucket"].startswith("bkt-"):
        yield "The outputBucket for the job does not follow naming conventions."


def template_has_description(flex_template: FlexTemplate) -> Iterable[str]:
    if "metadata" not in flex_template:
        yield "The flex template is missing a 'metadata' section."
    elif "description" not in flex_template["metadata"]:
        yield "The flex template is missing a 'metadata.description' section."
    elif flex_template["metadata"]["description"].strip() == "":
        yield "The flex template 'metadata.description' cannot be empty."


def validate(
    job_parameters: JobParameters, flex_template: FlexTemplate
) -> Iterable[str]:
    # Allow forcing validation failure for testing purposes
    if os.environ.get("FAIL_VALIDATION", "f").lower() in ["t", "true", "1"]:
        errors = [
            "Job is missing a value for the required 'outputBucket' parameter.",
            "The outputBucket for the job does not follow naming conventions.",
            "The flex template is missing a 'metadata' section.",
            "The flex template is missing a 'metadata.description' section.",
            "The flex template 'metadata.description' cannot be empty."
        ]
        yield from random.sample(errors, k=random.randint(1, len(errors)))
    else:
        yield from job_has_output_bucket(job_parameters)
        yield from template_has_description(flex_template)


def main() -> int:
    job_parameters, flex_template = parse_script_input(sys.stdin)
    errors = validate(job_parameters, flex_template)
    output_errors(errors)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        import traceback

        print(
            f"An unexpected error occured.\n{traceback.format_exc()}", file=sys.stderr
        )
        sys.exit(1)
