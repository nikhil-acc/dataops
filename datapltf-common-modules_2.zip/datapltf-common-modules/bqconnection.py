#!/usr/bin/env python3
"""
python 3.9+
"""

import json
import subprocess
import traceback
from argparse import ArgumentParser, Namespace
from typing import Dict, List, TextIO


class ComputeBqPermissionsError(Exception):
    """Normal errors that may occur during the execution of this script."""


def bq(*args: str) -> subprocess.CompletedProcess:
    """Run a bq command, returning the result as a completed process."""
    return subprocess.run(["bq", *args], text=True, check=False, capture_output=True)


def bq_json(*args: str) -> Dict:
    """Run a bq command and return the JSON output."""
    cmd = ["--format=json", *args]
    response = bq(*cmd)
    if response.returncode != 0:
        raise ComputeBqPermissionsError(
            f"bq {' '.join(args)} failed with {response.returncode}:"
            f" {response.stdout} {response.stderr}"
        )
    try:
        return json.loads(response.stdout)
    except json.JSONDecodeError as e:
        raise ComputeBqPermissionsError(
            f"Failed to decode JSON from bq command {' '.join(cmd)}:\n{response.stdout}"
        ) from e


def lookup_service_account_by_connection(connection_id: str) -> str:
    """Higher level function to lookup the service account for a given connection_id."""
    connection_spec = bq_json(
        "show",
        "--connection",
        connection_id,
    )
    if "cloudResource" not in connection_spec:
        raise ComputeBqPermissionsError(
            f"Result of bq show command for {connection_id} unexpectedly does not have a 'cloudResource'"
            f" attribute:\n{connection_spec}"
        )
    if "serviceAccountId" not in connection_spec["cloudResource"]:
        raise ComputeBqPermissionsError(
            f"Result of bq show command for {connection_id} unexpectedly does not have a "
            f"'cloudResource.serviceAccountId' attribute:\n{connection_spec}"
        )
    return connection_spec["cloudResource"]["serviceAccountId"]


class BqConnectionArgs(Namespace):
    """The arguments that will be passed to this script."""

    connection_id: str


def parse_argv(argv: List[str]):
    parser = ArgumentParser()
    parser.add_argument(
        "--connection-id",
        required=True,
        help="The connection id to lookup in the form of `GCP_PROJECT.REGION.CONNECTION_NAME`.",
    )
    return parser.parse_args(argv[1:], namespace=BqConnectionArgs())


def main(argv: List[str], inp: TextIO, out: TextIO, err: TextIO) -> int:
    try:
        args = parse_argv(argv)
        service_account = lookup_service_account_by_connection(args.connection_id)
        json.dump({"service_account": service_account}, out)
    except ComputeBqPermissionsError as e:
        err.write(f"Error: {e}\n")
        return 1
    except Exception as e:
        traceback.print_exc(file=err)
        err.write(f"Unexpected Error: {e}\n")
        return 2
    return 0


if __name__ == "__main__":
    import sys

    status_code = main(sys.argv, sys.stdin, sys.stdout, sys.stderr)
    sys.stdout.flush()
    sys.stderr.flush()
    sys.exit(status_code)
