import pytest


# Fixes localhost could not be resolved error in gitlab runner
@pytest.fixture(scope="session")
def httpserver_listen_address():
    return ("127.0.0.1", 8000)
