import json
import os
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import List

from hypothesis import given

from tests.strategies import validation_error_lists

from validation_runner import output_errors, parse_args


def assert_paths(p1: str, p2: str):
    assert Path(p1).absolute() == Path(p2).absolute()


def test_parse_args_tmp_dir_defaults_to_cwd():
    ns = parse_args([])
    assert_paths(ns.tmp_dir, os.getcwd())


def test_parse_args():
    with TemporaryDirectory() as tmp_dir:
        ns = parse_args([f"--tmp-dir={tmp_dir}"])
        assert_paths(ns.tmp_dir, tmp_dir)


def test_parse_args_no_cleanup_defaults_to_false():
    ns = parse_args([])
    assert not ns.no_cleanup


@given(validation_errors=validation_error_lists)
def test_output_errors(validation_errors: List[str]):
    buffer = StringIO()
    output_errors(validation_errors, buffer)
    buffer.seek(0)
    actual = json.loads(json.loads(buffer.read())["errors"])
    assert validation_errors == actual
