import pytest

from tests import tmp_dir_path


@pytest.fixture
def tmp_dir():
    with tmp_dir_path() as tmp_dir:
        yield tmp_dir
