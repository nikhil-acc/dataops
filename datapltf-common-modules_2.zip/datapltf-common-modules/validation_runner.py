#!/usr/bin/env python3
"""
This script is for use with the Terraform external datasource
https://registry.terraform.io/providers/hashicorp/external/latest/docs/data-sources/external
It implements the External Program Protocol described on that page in order
to provide dataflow job validation at terraform plan and apply stages.

Given a validation script, flex template and job parameters,
run the validation script on the flex template and job parameters
reporting the results back to the data source as a JSON encoded array of
strings where each string is a nice human readable validation error that
will be presented to the terraform operator as part of the terraform error
message.

External Program Protocol Summary:
- the TF query object is passed through STDIN
- the only allowed values for the query object are strings (ie
  it has to be a flat Dict[str, str]) so more complicated values like
  objects will need to be JSON encoded
- on success, the validation_runner must output a valid JSON object
  to STDOUT and exit with exit code 0
- that object, similar to query, can only be a flat Dict[str, str] so more
  complicated values like arrays/objects will need to be JSON encoded
- on failure, the validation_runner must return non-zero and output a
  human readable message on STDERR which will be presented as is to the
  terraform operator.
- it is possible to pass in values to validation_runner from data.external
  through ARGV
"""
import json
import os
import subprocess
import sys
from argparse import ArgumentParser, Namespace
from pathlib import Path
from subprocess import PIPE
from typing import cast, List, Sequence, TextIO, TypedDict
from uuid import uuid4


def to_bool(x: str) -> bool:
    """Convert the string to a bool."""
    return x.strip().lower() in ["1", "t", "true"]


TMP_DIR_VAR_NAME = "VALIDATION_RUNNER_TMP_DIR"
TMP_DIR = os.environ.get(TMP_DIR_VAR_NAME, os.getcwd())
NO_CLEANUP_VAR_NAME = "VALIDATION_RUNNER_NO_CLEANUP"
NO_CLEANUP = to_bool(os.environ.get(NO_CLEANUP_VAR_NAME, "false"))
UNEXPECTED_FAILURE_CODE = 7
SCRIPT_FAILURE_CODE = 2


class ValidationRunnerError(Exception):
    """Normal errors that may occur during the execution of this script."""


JsonEncodedString = str


class ValidationQuery(TypedDict):
    """
    Input coming in from the terraform external datasource.
    Should match the query object in terraform.
    """

    script: str
    flex_template: JsonEncodedString
    job_parameters: JsonEncodedString


def read_query(fp: TextIO) -> ValidationQuery:
    """Given an IO object like sys.stdin, return the query request."""
    query = json.load(fp)
    if "script" not in query:
        raise ValidationRunnerError(
            "The query was missing a script, set the 'script' query attribute."
        )
    if "flex_template" not in query:
        raise ValidationRunnerError(
            "The query was missing a flex template, set the 'flex_template' query attribute."
        )
    if "job_parameters" not in query:
        raise ValidationRunnerError(
            "The query was missing job parameters, set the 'job_parameters' query attribute."
        )

    return cast(ValidationQuery, query)


Errors = List[str]
JsonEncodedErrors = str


class ValidationResult(TypedDict):
    """
    The result of running this script is a list of error messages for each validation
    issue found. This is what is returned to terraform external datasource and available
    on the data.external.result attribute. It will need to be jsondecoded() in terraform
    due to limitations in the external program protocol which requires string values.
    """

    errors: JsonEncodedErrors


def output_errors(errors: Errors, fp: TextIO = sys.stdout):
    """Write the validation result to STDOUT for terraform to pickup."""
    json.dump({"errors": json.dumps(errors)}, fp)
    fp.flush()


def save_script(text: str, tmp_dir: Path | None = None) -> Path:
    """Given the text for a script, save it to disk and make it executable."""
    if tmp_dir is None:
        tmp_dir = Path.cwd()

    uid = uuid4().hex
    script_path = tmp_dir / f"script-{uid}"
    with script_path.open("w") as fp:
        fp.write(text)

    script_path.chmod(0o500)
    return script_path


class ScriptInput(TypedDict):
    """The input that will be fed on STDIN to the validation script we received on our STDIN."""

    job_parameters: JsonEncodedString
    flex_template: JsonEncodedString


def run_script(
    script_path: Path, template: JsonEncodedString, job_parameters: JsonEncodedString
) -> Errors:
    """
    Run the given script passing in the template and job parameters for validation.
    Pass the template and job parameters to the script through STDIN similar to the way
    this script received it's input.
    """
    script_input: ScriptInput = {
        "flex_template": template,
        "job_parameters": job_parameters,
    }
    cp = subprocess.run(
        [str(script_path.absolute())],
        input=json.dumps(script_input).encode("utf-8"),
        stdout=PIPE,
        stderr=PIPE,
    )
    if cp.returncode != 0:
        raise ValidationRunnerError(
            f"The validation script exited with non-zero exit code [{cp.returncode}].\n"
            f"STDOUT:\n{cp.stdout.decode()}\n"
            f"STDERR:\n{cp.stderr.decode()}"
        )
    errors: Errors = json.loads(cp.stdout.decode("utf-8"))
    if not isinstance(errors, list):
        raise ValidationRunnerError(
            "The script ran successfully and outputted JSON but it did not return the correct JSON which should "
            f"be an array of strings representing validation error messages. It outputted:\n{errors}"
        )
    for error in errors:
        if not isinstance(error, str):
            raise ValidationRunnerError(
                "The script ran successfully and outputted a JSON array but not all elements of the array are strings. "
                f" {repr(error)} is not a string."
            )
    return errors


def parse_args(args: Sequence[str]):
    """CLI parser."""
    parser = ArgumentParser()
    parser.add_argument(
        "--tmp-dir",
        default=TMP_DIR,
        dest="tmp_dir",
        type=Path,
        help=(
            "Temporary directory to use for intermediary files. "
            f"This setting can also be set through the {TMP_DIR_VAR_NAME} environment variable "
            "which can be useful when retrying CI jobs. "
            "It defaults to the current working directory and the "
            "directory is assumed to already exist."
        ),
    )
    parser.add_argument(
        "--no-cleanup",
        action="store_true",
        default=NO_CLEANUP,
        help=f"Skip cleanup of intermediary files. This can also be set through {NO_CLEANUP_VAR_NAME} environment variable.",
    )

    class ValidationRunnerArgs(Namespace):
        """Provides typing for the above parsed arguments."""

        tmp_dir: Path
        no_cleanup: bool

    return parser.parse_args(args, namespace=ValidationRunnerArgs())


def main(argv: Sequence[str]) -> int:
    args = parse_args(argv[1:])
    query = read_query(sys.stdin)
    script_path = save_script(query["script"], args.tmp_dir)
    try:
        errors = run_script(
            script_path, query["flex_template"], query["job_parameters"]
        )
        output_errors(errors)
    finally:
        if not args.no_cleanup:
            script_path.unlink()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except ValidationRunnerError as err:
        print(err, file=sys.stderr)
        sys.exit(SCRIPT_FAILURE_CODE)
    except Exception:
        import traceback

        print(
            f"An unexpected error occured.\n{traceback.format_exc()}", file=sys.stderr
        )
        sys.exit(UNEXPECTED_FAILURE_CODE)
