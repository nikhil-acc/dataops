# Dataproc Serverless

The repository provides scripts and configurations for submitting batch jobs to a Dataproc cluster using a Terraform module. The Composer DAG module ensures the creation of Dataproc serverless clusters and jobs by managing dependencies and handlingfault tolerance.Together, these components streamline the process of running and managing batch data workflows in a robust manner.

<br />

## Table of Contents

* [Prerequisites](#prerequisites)
* [Project structure](#projectstructure)
* [Getting Started](#getting-started)
  * [Terraform Configuration Setup](#terraform-config-setup)
  * [Spark Scala Code](#spark-scala-code)
  * [Composer Dag](#composer-dag)

<br />

---

<a name="prerequisites"/>

## Prerequisites

* Terraform 1.2.0 +

<a name="projectstructure"/>

## Project structure

```
.

│── dataproc-serverless-module 
|   └── composer_dag.tf
|   └── dp_jar.tf
|   └── ...
├── test
    └── com
│       └── dpserverlessworkflow
│           └── config.yaml     
│           └── dpserverlessworkflow.py
│   └── sa
|      └── sa.tf
|      └── terragrunt.hcl
|      └── ...
│   └── dp
|       └── src
|       |   └── AppTest.scala
|       └── pom.xml
|       └── ...
|   └── terraform
|       └── terragrunt.hcl
```

`dataproc-serverless-module` folder contains terraform files. composer_dag.tf sets up the composer environment, creates bucket object which will hold DAG and config files. dp_jar.tf file contains code to download Jar from Artifact registry to GCS Bucket. 

`test` folder contains multiple subfolders. `com` folder contains a subfolders `dpserverlessworkflow` which has one python DAG file and one configuration file for the DAG. The sa subfolder contains scripts for creation of sa and grants roles/dataproc.editor and, roles/dataproc.worker role to the dataproc SA. The `dp\src` subfolder contains the example of Scala code which prints hello world. `terraform` subfolder contains terragrunt.hcl file which generates backend.tf,terraform.tf, It also has values of deployment variables specific to the terraform module.

<a name="getting-started"/>

## Getting Started 

<a name="terraform-config-setup"/>

### Terraform Configuration Setup :

To use this template, configure the parameters in the `test\terraform\terragrunt.hcl` file.

`Dependency Configuration:`

Defines a dependency on the Terraform module for GCS bucket located at "test\bucket". It also sets a output for the bucket name.

`Local Variables:`

Sets up local variables from environment variables for use in Terraform configurations, including credentials, module versions, project names, and file paths. It also specifies the name and path of the JAR file used for the batch job.

`Backend Configuration:`

Generates a backend.tf file that specifies using Google Cloud Storage (GCS) as the backend for storing Terraform state files. The bucket and prefix for the state file are derived from local variables.

`Terraform Source:`

Defines the source for the Terraform module as a ZIP file hosted on Artifactory, with authentication credentials provided through local variables.

`Inputs`

Provides various input parameters required by the Terraform module, such as:

| Input Variables | Description |
| ----------------- | ------------------------------------------------------ |
| `jar_bucket` | The bucket name for storing the JAR file |
| `artifactory_password and access_token` | credentials for Artifactory. |
| `serverless_jobs` | Specifies the serverless jobs and also contains the source_url, jar_file_path, jar_main_class and jar_file_name. |
| `dataeng_project` | Poroject ID for the Dataproc serveless and job. |
| `cluster_name` | Name of the Dataproc cluster to be used. |
| `dataproc_sa` | SA of the Dataproc cluster to be used. |
| `network_project` | Network project ID for subnet to be use in dataproc serverless. |
| `subnet` | Name of the subnetwork to be use in Dataproc serverless. |
| `composer_environment_name` | Composer environment name. |
| `airflow_project` | Porject ID for the Composer airflow environment. |

<a name="spark-serverless-code"/>

### Spark Scala Code :

This Spark Scala application sets up a batch job using a Spark session builder. It creates a Spark session and prints "Hello, world", to the console. It stops the Spark session after completing the print statement.

Make sure if you change the scala code Please change the main class and Jar related configurations in the terragrunt file.

<a name="composer-dag"/>

### Composer Dag 

The Directed Acyclic Graph (DAG) is designed to create and manage the Dataproc serverless cluster and job.
The config for DAG file is provided through the `config.yaml` file. 

The config file is been referred in the `dataproc-serverless-modules\composer_dag.tf` file where the bucket object is created and also the config.yaml.


#### Dag Details :

| **Component**                  | **Description** |
| ------------------------------ | ------------------------------------------------------ |
| **Default Arguments (`default_args`)** | Default parameters used for the DAG, including owner, retry policies, start date, and email notifications for job status. |
| **Spark Job Configuration (`SPARK_JOB`)** | Specifies the configuration for the Dataproc serverless and job, including the JAR file URI, main class to run, and job labels. |
| **Region**                     | Region for the Dataproc job |
| **Tasks**                     | - **`start_pipeline:`** A dummy operator to mark the start of the pipeline. **`create_batch:`** Uses `DataprocCreateBatchOperator` to create the dataproc cluster and submit the Spark job. **`list_batches:`** A `DataprocListBatchesOperator` that provides a list of the jobs that have been submitted.  **`get_batch:`** A `DataprocGetBatchOperator` that retrieves job details. **`delete_batch:`** A `DataprocDeleteBatchOperator` that deletes the Dataproc serverless cluster and job that were created and submitted. **`end_pipeline:`** A dummy operator to mark the end of the pipeline. |
| **Task Dependencies**         | `start_pipeline` initiates the workflow.  `create_batch` create the cluster and job. `list_batches` list all the submitted jobs. 'get_batch' retrieve the details of the job and 'delete_batch'delete the submitted jobs and ends the pipeline.

