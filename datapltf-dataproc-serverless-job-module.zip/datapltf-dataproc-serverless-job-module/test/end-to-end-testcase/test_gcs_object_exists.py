from google.cloud import storage
import pytest
import json
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


@pytest.fixture(scope="module")
def remote_state(pytestconfig):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')

    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    gcs_objects = []

    # filter and return only GCS bucket object resources
    for resource in state.get("resources", []):
        if resource.get("type") == "google_storage_bucket_object":
            gcs_objects.extend(resource.get("instances", []))

    return gcs_objects

def test_storage_object_exists(remote_state):
    
    client = storage.Client()  # Initialize the storage client once

    for instance in remote_state:
        bucket_name = instance.get("attributes", {}).get("bucket")
        object_name = instance.get("attributes", {}).get("name")

        if not bucket_name or not object_name:
            print(f"Bucket or object name missing for instance: {instance}")
            continue

        # Check if the GCS bucket exists
        bucket = client.bucket(bucket_name)

        if bucket.exists():
            print(f"GCS bucket {bucket_name} exists in GCP!!")
            # Check if the GCS bucket object exists
            bucket_object = storage.Client().bucket(bucket_name).blob(object_name)
            assert bucket_object.exists(
            ), f"GCS bucket object {object_name} not found in GCP!!"
            print(f"GCS bucket object {object_name} found in GCP!!")
        else:
            print(f"GCS bucket {bucket_name} does not exist in GCP!!")