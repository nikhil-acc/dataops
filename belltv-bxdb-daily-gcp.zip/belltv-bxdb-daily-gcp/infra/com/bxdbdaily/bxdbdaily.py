import os
from datetime import datetime, timedelta
from pprint import pp
from time import time

import airflow
import yaml
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.google.cloud.operators.dataproc import (
    DataprocCreateBatchOperator,
)
from google.cloud.dataproc_v1.types import Batch

dir_path = os.path.dirname(os.path.abspath(__file__))
config_file_path = os.path.join(dir_path, "config.yaml")
with open(config_file_path) as yaml_file:
    configuration = yaml.safe_load(yaml_file)
    pp(configuration)

metadata = configuration["metadata"]

default_args = {
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

with DAG(
    f"workflow_{metadata['use_case']}",
    default_args=default_args,
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
) as dag:
    ts = str(int(time()))
    test_job = BashOperator(
        task_id="test_task",
        bash_command="echo test",
        dag=dag,
    )

    config_bxdb_account_hist = configuration["dataprocs"]["bxdb_account_hist"]
    config_bxdb_account_hist["environment_config"]["execution_config"]["network_tags"] = ["sectag-dataproc-rsz"]
    
    bxdb_account_hist = DataprocCreateBatchOperator(
        task_id="bxdb_account_hist_task",
        project_id=metadata["dataeng_project"],
        region=metadata["region"],
        batch=config_bxdb_account_hist,
        batch_id=f"bxdb-account-hist-{metadata['use_case']}-{ts}",
        dag=dag,
        gcp_conn_id=metadata["dataeng_project"],
        impersonation_chain=metadata["dataproc_service_account"],
    )

    config_cataloguereport = configuration["dataprocs"]["bxdb_cataloguereport"]
    config_cataloguereport["environment_config"]["execution_config"]["network_tags"] = ["sectag-dataproc-rsz"]

    bxdb_cataloguereport = DataprocCreateBatchOperator(
        task_id="bxdb_cataloguereport_task",
        project_id=metadata["dataeng_project"],
        region=metadata["region"],
        batch=config_cataloguereport,
        batch_id=f"bxdb-cataloguereport-{metadata['use_case']}-{ts}",
        dag=dag,
        gcp_conn_id=metadata["dataeng_project"],
        impersonation_chain=metadata["dataproc_service_account"],
    )
    # test_job
    # mysparkjob_job
    # myjob
    test_job >> bxdb_account_hist >> bxdb_cataloguereport  
