# belltv-bxdb-daily-gcp

## Overview

Ingesting data from BellExtendedDB Database Accoun & Catalogue Tables to expl tables using RDBMStoGCS Dataproc Template.

This Data Ingestion pipeline reads from a SQLSERVER source and writes to a Google Cloud Storage (GCS) bucket. It supports reading data from relational data sources using JDBC connections via JAR files. The Dataproc job template is a Parameterized template that runs in a Dataproc serverless environment and is triggered by passing parameters to the Dataproc job template. Biglake external tables created point to this GCS location to query from the data extracted from SQLSERVER source

## Building Workflow
This workflow is built by calling reusable RDBMStoGCS dataproc template from Artifact registry. This template is a Parameterized Template, meaning that the pipeline code will be containerized and executed on Dataproc in Serverless environment under Batches option in Dataproc Service running on GCP. 

It can be triggered via a Composer DAG provided with arguments. We have used DataprocCreateBatchOperator in Cloud composer to trigger execution of job where parameters are configured from Terraform code.

## Dataproc Template Parameters 

### Required parameters

- **app-name:** User provided Spark application name as per the convenience(Example: `BXDB-DAILY`).
- **jdbc-url:** JDBC connection string to connect to the JDBC source (Example: MySQL: `jdbc:mysql://some-host:3306/sampledb`).
- **jdbc-user:** Username for the JDBC connection.
- **project_id:** GCP project ID.
- **jdbc-password-secret-id:** JDBC password Secret ID for retrieving the password for RDBMS.
- **jdbc-password-secret-version:** JDBC password Secret ID for retrieving the password for RDBMS.
- **py-files:** Comma-separated paths of GCS containing Python support files (Example: `gs://your-bucket/module1.py,gs://your-bucket/module2.py`).
- **output:** Output path on GCS where the exported file will be stored.
- **mode:** Mode to control the behavior if data already exists at the destination (Example: `append`, `overwrite`, `ignore`, etc.). Default is `append` mode.

### Optional parameters

- **table:** Table name to read data from the RDBMS database.
- **query:** SQL query to execute, useful for incremental load.
- **partition-column:** The partition column on which the partition is based. The column type must be of timestamp/date format.
- **iceberg-flag:** Reserved for future use.

## Deployment Sequence

![resources-deployment-diagram](./docs/resources-deployment-diagram.png "Resource Deployment Diagram")

## What artifacts are released in this project?

This project uploads to Unified Artifactory:
* a jar file with a Spark application.
* a Terraform module that can be used to deploy a Serverless Dataproc job in a CD project.

## What resources are deployed in this project?

This project deploys a serverless Dataproc job in an ephemeral environment (npe or dev). More specifically:

* A DAG workflow in Composer. More details in [main.tf](./infra/main.tf).
* When the DAG is triggered it creates a serverless Dataproc job.
* Supporting resources for the job. Refer to the [datapltf-common-modules](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules) for details.

The ephemeral resources are destroyed when the branch is deleted.

## Release and Deployment Decision Tree

The pipeline builds and releases new artifacts or deploy resources in an ephemeral environment depending on certain conditions. Here is the general idea:

* Merge Request pipelines:
    * deploy the ephemeral environment when the infrastructure code changes (Terraform mostly)
    * release a jar and a Terraform module to an Artifatory snapshot repository AND deploy the ephemeral environment when the job's business logic code changes (Scala mostly).

    ```mermaid
    flowchart LR

    MRP?{MR<br>Pipeline?} --Yes--> JC?{Job<br>Changes?} --Yes--> Jar[Build and Upload<br>Jar to UA] --> Eph[Deploy<br>Ephemeral Environment]

    MRP? --Yes--> IC?{Infra<br>Changes?} --Yes--> Eph[Deploy<br>Ephemeral Environment]
    ```

    * destroy the ephemeral environment when the branch is deleted (on merge request or not) .

    ```mermaid
    flowchart LR

    MRP?{MR<br>Pipeline?} --Yes--> Deleted?{Branch<br>Deleted?} --Yes--> Eph[Destroy<br>Ephemeral Environment]
    ```


* Main branch pipelines:
    * release a jar and a Terraform module to an Artifatory release repository when a version tag is created.

    ```mermaid
    flowchart LR

    MainP?{main<br>Pipeline?} --Yes--> Tag?{Tag v.X.X.X ?} --Yes--> Jar[Build and Upload<br>Jar to UA] --> TFMod[Build and Upload<br>TF mod to UA]
    ```

## Requirements

Ensure the following requirements are met prior to executing the pipeline:

### Runner Dependencies

The following dependencies must be present in the runner Docker image:

* Terraform >= 1.5.0
* Java >= 17
* Maven >= 3.8

### GCP Roles

Your runner must have the following roles in your GCP project:

* Composer User in the Airflow project

## Considerations

## Contributions

It is important to agree on a set of contribution guidelines with your team to ensure this project evolves gracefully :slightly_smiling_face: .

### Execution steps:
To Execute the Template via CI .

1.  CI Pipeline to be executed without any issues
2.  Config.yaml & Composer DAG created in GCP Airflow project environment after execution of CI Pipeline
3.  Go to GCP Console and select the airflow project, composer service
4.  Execute the rdbmstogcs_${USE_CASE} DAG and verify the logs

This template has been tested using Development Ephemeral scripts via CI pipeline

Following are the stages of CI Pipeline,

1.  Test
2.  Compliance
3.  terraform lint
4.  terraform plan
5.  terraform apply
6.  terraform integration test 
7.  terraform destroy

Post the stage of 5(i.e. Terraform apply), Composer DAG and Config.yaml files are created and placed in Airflow DAG GCS home path. Below is the config file structure
```yaml
"config": {}
  "dataprocs":
    "environment_config":
      "execution_config":
        "network_tags": "sectag-dataproc-rsz"
        - "dataproc"
        "service_account": "sa-<domain>-<env>-<use_case>-01@gcp-wline-<env>-tvmedia-de-01.iam.gserviceaccount.com"
        "subnetwork_uri": "https://www.googleapis.com/compute/v1/projects/gcp-wline-dev-tvmedia-de-01/regions/northamerica-northeast1/subnetworks/snet-wline-dev-tvmedia-de-main-01"
    "pyspark_batch":
      "args":
      - "--app-name=sqlserver"
      - "--jdbc-url=jdbc:sqlserver://10.0.109.122:1433;databaseName=BellExtendedDB;encrypt=true;trustServerCertificate=true"
      - "--jdbc-user=NBIG.Prod"
      - "--project-id=gcp-wline-<env>-tvmedia-de-01"
      - "--jdbc-password-secret-id=scrt-tv-<env>-<use_case>-belltv-bxdb-xuv-pw"
      - "--jdbc-password-secret-version=latest"
      - "--query=select ID,branch, CustomerGroup, StartAuditDate, EndAuditDate, ChannelMapRevisionId, CustomerTypeId, UpgradeGroup, ServiceGroup, BandwidthProfileId, ChannelMap, ChannelMapUpdateDate,CAST(CONVERT(VARCHAR(10), GETDATE(), 23) AS DATE) AS dt_skey FROM Account"
      - "--partition-column=dt_skey"
      - "--output=gs://bkt-${var.domain}-${var.env}-nane1-${var.use_case}-expl/bxdb_account_hist/"
      - "--mode=append"
      "main_python_file_uri": "file:///home/spark/rdbmstogcs/main.py"
    "runtime_config":
      "container_image": "northamerica-northeast1-docker.pkg.dev/prj-netw-prod-npda-common-01/art-datapltf-prod-nane1-docker-release-01/cimg-datapltf-datengtpl-dataproc-rdbmstogcs:7c71f88c"
```  
Triggering of this DAG in GCP Console, runs the Dataproc job and thus creates RDBMStoGCS pipeline written in pyspark to, 
1.  Read the configuration parameters in config.yaml
2.  Establish the connection to RDBMS via JDBC READ(Pyspark) in dataframe
3.  Writing the dataframe into GCS in a PARQUET format