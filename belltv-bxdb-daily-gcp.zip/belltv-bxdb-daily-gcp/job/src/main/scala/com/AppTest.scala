package com

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql._
import java.util.HashMap
import org.apache.spark.sql.types._
import org.apache.spark.sql.types.DataType

object AppTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.appName("HelloWorld").getOrCreate()
    println("Hello, World from Spark application!")
    spark.stop()
  }
}



