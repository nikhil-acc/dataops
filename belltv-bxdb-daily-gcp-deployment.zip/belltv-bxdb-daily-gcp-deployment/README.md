# belltv-bxdb-daily-gcp-deployment

[TOC]

## Project Description

This project was created by a DevHub scaffolder. It deploys serverless Dataproc jobs in GCP. The data engineer is expected to make adjustments to the project.

## Architecture Diagram

![resources-deployment-diagram](./docs/resources-deployment-diagram.png "Resource Deployment Diagram")

## What artifacts are released in the published project?

This project releases no artifacts. It leverages an existing Terraform module built by a separate project to deploy resources in GCP.

## What resources are deployed in the published project?

This project deploys a Dataproc job in a low environment (npe or dev). More specifically:

* A DAG workflow in Composer. More details in [main.tf](./infra/main.tf) and in [values.tfvars](./environments/low/values.tfvars).
* When the DAG is triggered it creates a serverless Dataproc job.
* Supporting resources for the job. Refer to the [datapltf-common-modules](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules) for details.

Mock-up stages simulate a deployment in Staging and Production. Search for `MANUAL STEP` in the code to identify code the data engineer has to substitute.

## Release and Deployment Decision Tree

The pipeline deploys resources in different environment depending on certain conditions. Here is the general idea:

* Merge Request pipelines:
    * deploy the code in the low environment (npe or dev).

    ```mermaid
    flowchart LR

    MRP?{MR<br>Pipeline?} --Yes--> Low[Deploy<br>Low Environment]
    ```

    * Deleting the branch (on merge request or not) destroys the low environment.

    ```mermaid
    flowchart LR

    MRP?{MR<br>Pipeline?} --Yes--> Deleted?{Branch<br>Deleted?} --Yes--> Low[Destroy<br>Low Environment]
    ```

* Main branch pipelines:
    * Deploy to Staging and Production. Once production is deployed the Staging and Low environments are destroyed

    ```mermaid
    flowchart LR

    MainP?{main<br>Pipeline?} --Yes--> Stg[Deploy<br>Staging Environment] --> Prod[Deploy<br>Production Environment] --> DestroyLow[Destroy<br>Low Environment]

    Prod --> DestroyStg[Destroy<br>Staging Environment]
    ```

## Requirements

Ensure the following requirements are met prior to executing the pipeline:

### Runner Dependencies

The following dependencies must be present in the runner Docker image:

* Terraform >= 1.5.0

### GCP Roles

Your runner must have the following roles in your GCP project:

* Composer User in the Airflow project

## Considerations

## Contributions

It is important to agree on a set of contribution guidelines with your team to ensure this project evolves gracefully :slightly_smiling_face: .