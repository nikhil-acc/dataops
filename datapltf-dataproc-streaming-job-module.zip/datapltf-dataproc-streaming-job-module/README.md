# Dataproc Streaming on VM Module

The repository provides scripts and configurations for submitting streaming jobs to a Dataproc cluster using a Terraform module. The Composer DAG module ensures job resiliency by handling dependencies and fault tolerance.Together, these components streamline the process of running and managing streaming data workflows in a robust manner.

<br />

## Table of Contents

* [Prerequisites](#prerequisites)
* [Project structure](#projectstructure)
* [Getting Started](#getting-started)
  * [Terraform Configuration Setup](#terraform-config-setup)
  * [Spark Streaming Code](#spark-streaming-code)
  * [Composer Dag](#composer-dag)

<br />

---

<a name="prerequisites"/>

## Prerequisites

* Terraform 1.2.0 +
* Dataproc Cluster should be pre-provisioned by [datapltf-common-environment-setup](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-common-environment-setup) project.

<a name="projectstructure"/>

## Project structure

```
.

│── dataproc-streaming-module 
|   └── composer_dag.tf
│   └── dataproc_job.tf
|   └── dp_jar.tf
    └──com
│      └── dpstreamingworkflow
│         └── config.yaml     
│         └── dpstreamingworkflow.py
|   └── ...
├── test
│   └── dp
|       └── src
|       |   └── DataprocStreaming.scala
|       └── pom.xml
|       └── ...
|   └── terraform
|       └── terragrunt.hcl
```

`dataproc-streaming-module` folder contains terraform files. composer_dag.tf sets up the composer environment, creates bucket object which will hold DAG and config files. dataproc_job.tf contains resource block to submit the Job to the dataproc cluster. dp_jar.tf file contains code to push Jar from Artifact registry to GCS Bucket. 

`com` folder contains a subfolders `dpstreamingworkflow` which has one python DAG file and one configuration file for the DAG. 

`test` folder contains multiple subfolders. The `dp\src` subfolder contains the Streaming Scala code which levearges 'rate' source as Input. The config is set such that the Streaming Job will run for 24 hrs if not stopped manually. `terraform` subfolder contains terragrunt.hcl file which generates backend.tf,terraform.tf, It also has values of deployment variables specific to the terraform module.

<a name="getting-started"/>

## Getting Started 

<a name="terraform-config-setup"/>

### Terraform Configuration Setup :

To use this template, configure the parameters in the `test\terraform\terragrunt.hcl` file.

`Local Variables:`

Sets up local variables from environment variables for use in Terraform configurations, including credentials, module versions, project names, and file paths. It also specifies the name and path of the JAR file used for the streaming job.

`Backend Configuration:`

Generates a backend.tf file that specifies using Google Cloud Storage (GCS) as the backend for storing Terraform state files. The bucket and prefix for the state file are derived from local variables.

`Terraform Source:`

Defines the source for the Terraform module as a ZIP file hosted on Artifactory, with authentication credentials provided through local variables

`Inputs`

Provides various input parameters required by the Terraform module, such as:

| Input Variables | Description |
| ----------------- | ------------------------------------------------------ |
| `jar_bucket` | The bucket name for storing the JAR file |
| `jar_file_path` and `jar_file_name` | Path and Name of the JAR file |
| `artifactory_password and access_token` | credentials for Artifactory. |
| `streaming_jobs` | Specifies the Composer workflows for dataproc on VMs. |
| `dp_job_name_label` | Label for the Dataproc job. |
| `cluster_name` | Name of the Dataproc cluster to be used. |
| `jar_main_class` | Main class in the JAR file. |
| `args_drivers` | Arguments for the job. |
| `sparklogconf` | Configuration for Spark logging. |
| `log_info` | Logging level. |

<a name="spark-streaming-code"/>

### Spark Streaming Code :

This Spark Scala application sets up a streaming job using a local Spark master and configures it to stop gracefully on shutdown. It creates a SparkSession, reads streaming data from a `rate source` that generates rows at a specified rate, and performs a simple transformation by adding 1 to each value. The transformed data is then written to the console in append mode, with microbatch processing triggered every 5 seconds. The job will run continuously for up to 24 hours before timing out.

`rate source`  - Generates data at the specified number of rows per second, each output row contains a timestamp and value. Where timestamp is a Timestamp type containing the time of message dispatch, and value is of Long type containing the message count, starting from 0 as the first row. 

Make sure if you change the streaming code Please change the main class and Jar related configurations in the terragrunt file.

<a name="composer-dag"/>

### Composer Dag 

The Directed Acyclic Graph (DAG) is designed to Manage and monitor the Dataproc streaming job submitted from the terraform Configuration.
The config for DAG file is passed through the `config.yaml` file. 

The config file is been referred in the `dataproc-streaming-modules\composer_dag.tf` file where the bucket object is created on fly and also the config.yaml.

#### Job monitoring follows this logic:

If the job submitted to the Dataproc cluster through the Terraform module is in a `RUNNING` or `PENDING` state, the DataprocSubmitJobOperator will not be triggered.
If the job is in a `DONE`, `ERROR`, `CANCELLED`, or any state other than `RUNNING` or `PENDING`, the DataprocSubmitJobOperator will be triggered to resubmit the job. This ensures that the streaming job remains active and continuously running.

`Note`: The Job is filtered based on the job-name label which is passed in the dp job submit configuration.

#### Dag Details :

| **Component**                  | **Description** |
| ------------------------------ | ------------------------------------------------------ |
| **Default Arguments (`default_args`)** | Default parameters used for the DAG, including owner, retry policies, start date, and email notifications for job status. |
| **Spark Job Configuration (`SPARK_JOB`)** | Specifies the configuration for the Dataproc job, including the JAR file URI, main class to run, and job labels. |
| **Region**                     | Region for the Dataproc job |
| **Functions**                 |  **`decide_branch(**kwargs):`** Determines the next task based on the job state retrieved for latest Job. If the job state is `ERROR`, it returns `resubmit_dp_job`; otherwise, it ends the pipeline. **`list_jobs(**kwargs):`** Queries Dataproc to list jobs with the label defined in `job-name` variable and status `ACTIVE`. |
| **Tasks**                     |          `start_pipeline:` dummy operator marking the start of the pipeline.`extract_job_details:` Retrieves job details and pushes the job state to XCom. `evaluate_job_status:` A BranchPythonOperator that branches based on the job state. `resubmit_dp_job:` A DataprocSubmitJobOperator that resubmits the Spark job if necessary. `end_pipeline:` A dummy operator marking the end of the pipeline. |
| **Task Dependencies**         | `start_pipeline` → `extract_job_details` → `evaluate_job_status` → (either `resubmit_dp_job` or `end_pipeline`)

