from google.cloud import storage
from google.cloud import dataproc_v1 as dataproc
from google.protobuf.json_format import MessageToDict
import pytest
import json
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


@pytest.fixture(scope="module")
def dataproc_job_client(remote_state):
    # create a client
    region = remote_state["instances"][0]["attributes"]["region"]
    return dataproc.JobControllerClient(
        client_options={
            "api_endpoint": f"{region}-dataproc.googleapis.com:443"}
    )


@pytest.fixture(scope="module")
def remote_state(pytestconfig):
    # set terrafrom artifacts
    bucket_name = pytestconfig.getoption('--tfstate_bucket')
    blob_name = pytestconfig.getoption('--tfstate_prefix')

    # connnect to terrafrom state bucket on gcp
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    # retrieve state file, convert to JSON document and get all state resources
    state_file = blob.download_as_bytes()
    state = json.loads(state_file)
    resources = state["resources"]

    # filter and return only dataproc resource
    for resource in resources:
        if resource["type"] == "google_dataproc_job":
            return resource
    return


def test_job_exists(dataproc_job_client, remote_state):
    # get service information from metastore_resource
    project = remote_state["instances"][0]["attributes"]["project"]
    region = remote_state["instances"][0]["attributes"]["region"]
    job_id = remote_state["instances"][0]["attributes"]["reference"][0]["job_id"]
    dp_job_name_label = remote_state["instances"][0]["attributes"]["effective_labels"]["job_name"]

    # Initialize request argument(s)
    request = dataproc.ListJobsRequest(
        project_id= project,
        region= region,
        filter=f"labels.job_name={dp_job_name_label} AND status.state = ACTIVE"
    )

    # Make the request
    page_result = dataproc_job_client.list_jobs(request=request)
    resp_det = MessageToDict(page_result.__dict__['_response']._pb)

    if resp_det == {} :
        job_id_status = 'ERROR'
    else :
        job_id_status = 'RUNNING/PENDING'

    if job_id_status == 'ERROR' :
        print(f"Test Case Failed: Job {job_id} encountered an error with state {job_id_status} in project {project}, region {region}.")
    else :
        print(f"Test Case Passed: Job {job_id} has completed successfully with state {job_id_status}.")