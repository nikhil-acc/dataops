package org.com

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.SparkConf
import org.apache.spark.sql.streaming.Trigger;

object DataprocStreaming {

  def main(args: Array[String]): Unit = {

    //spark conf object
    val sparkConf = new SparkConf()
    sparkConf.set("spark.app.name","Dataproc Streaming VM")
    sparkConf.set("spark.master","local[*]")

    // For stopping the Streaming Job Gracefully
    sparkConf.set("spark.sql.streaming.stopGracefullyOnShutdown","true")

    //Creating a Spark Session Object
    val spark = SparkSession.builder.config(sparkConf).getOrCreate()
    //spark.sparkContext.setLogLevel("ERROR")

    //Generates a Streaming dataframe ; The SparkSession Object
    //SparkSession returns a  DataStreamReader Interface returned by SparkSession.ReadStream()
    //There are few inbuilt sources : One of them is rate source
    // It generates rows per second in format (timestamp , value)

    val df = spark.readStream.format("rate").option("rowsPerSecond",3).load()

    println("Streaming Dataframe: "+ df.isStreaming)

    //Basic Transformation
    val resultDf = df.withColumn("result",col("value") + lit(1))

    // a processing time interval as a string, e.g. ‘5 seconds’, ‘1 minute’.
    // Set a trigger that runs a microbatch query periodically based on the processing time.
    // Only one trigger can be set.

    val finalRes = resultDf.writeStream.
                    outputMode("append").
                    option("truncate",false).
                    format("console").
                    trigger(Trigger.ProcessingTime("5 seconds")).
                    start()

    finalRes.awaitTermination(600000)  // Timeout after 10 minutes
  }
}

