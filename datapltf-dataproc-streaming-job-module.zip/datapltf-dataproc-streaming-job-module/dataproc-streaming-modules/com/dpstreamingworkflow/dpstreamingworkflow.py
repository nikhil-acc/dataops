"""
Description : DAG to create the dataproc streaming for scala job
Author: Saurav
Date : 15/07/2024
Modified Date : 
Usage: DAG file and config.yaml will be placed in the dags folder"""

import os
from datetime import datetime, timedelta
import logging

# ****************************************************
# STEP 1 - Importing necessary libraries
# *****************************************************

import airflow
import yaml
from airflow import DAG, models
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.google.cloud.operators.dataproc import (
    DataprocSubmitJobOperator
)
from airflow.providers.google.cloud.hooks.dataproc import DataprocHook
from airflow.operators.python_operator import PythonOperator , BranchPythonOperator
from google.protobuf.json_format import MessageToJson,MessageToDict
from google.cloud import dataproc_v1

# ****************************************************
# STEP 2 - Default Parameters
# ****************************************************
default_args = {
    "owner": "test-prj-gcp-edp-npe",
    "depends_on_past": False,
    "start_date": airflow.utils.dates.days_ago(1),
    "email": ["Your email address"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

# ****************************************************
# STEP 3 - Define DAG properties: ID, defaults and schedule
# *****************************************************
dir_path = os.path.dirname(os.path.abspath(__file__))
config_file_path = os.path.join(dir_path, "config.yaml")
with open(config_file_path) as yaml_file:
    configuration = yaml.safe_load(yaml_file)

    print(configuration["config"]["cluster_project_id"])
    print(configuration["config"]["region"])
    print(configuration["config"]["jar_file_path"])
    print(configuration["config"]["jar_main_class"])
    print(configuration["config"]["jar_file_name"])

cluster_project_id = configuration["config"]["cluster_project_id"]
region = configuration["config"]["region"]
jar_file_path = configuration["config"]["jar_file_path"]
jar_main_class = configuration["config"]["jar_main_class"]
cluster_name = configuration["config"]["cluster_name"]
jar_bucket   = configuration["config"]["jar_bucket"]
jar_file_name = configuration["config"]["jar_file_name"]
dp_job_name_label = configuration["config"]["dp_job_name_label"]
schdl_interval = configuration["config"]["schdl_interval"]
dag_name = configuration["config"]["dag_name"]

jar_file_uris = [f"gs://{jar_bucket}/{jar_file_path}/{jar_file_name}"]

SPARK_JOB = {
    "reference": {"project_id": cluster_project_id},
    "placement": {"cluster_name": cluster_name},
    "spark_job": {
        "jar_file_uris": jar_file_uris,
        "main_class": jar_main_class,
    },
    "labels": {
        "job_name" : dp_job_name_label
    },
}

def decide_branch(**kwargs):
    ti = kwargs['ti']
    job_state = ti.xcom_pull(key ='job_id_dp_tf', task_ids='extract_job_details')
    if job_state == 'ERROR' :
        return 'resubmit_dp_job'
    else :
        return 'end_pipeline'

def list_jobs(**kwargs):
    ti = kwargs['ti']
    # Create a client
    logging.info(f'{region}-dataproc.googleapis.com:443')
    client = dataproc_v1.JobControllerClient(client_options = {'api_endpoint' : f'{region}-dataproc.googleapis.com:443'})
    # Initialize request argument(s)
    request = dataproc_v1.ListJobsRequest(
        project_id=cluster_project_id,
        region=region,
        filter= f"labels.job_name={dp_job_name_label} AND status.state = ACTIVE"
    )
    # Make the request
    page_result = client.list_jobs(request=request)
    logging.info(page_result)
    resp_det = MessageToDict(page_result.__dict__['_response']._pb)
    logging.info(resp_det)
    
    if resp_det == {} :
        job_id_retrieved = 'ERROR'
    else :
        job_id_retrieved = 'RUNNING/PENDING'
    
    if job_id_retrieved != '' or job_id_retrieved is not None:
        ti.xcom_push(key = "job_id_dp_tf", value = job_id_retrieved)

with DAG(
    dag_name,                         
    schedule_interval = schdl_interval ,
    template_searchpath=["/home/airflow/gcs/data/"],
    max_active_runs=1,
    catchup=True,
    default_args=default_args,
) as dag:
    start_pipeline =   DummyOperator(task_id="start_pipeline", dag=dag)

    extract_job_details = PythonOperator(
        task_id='extract_job_details',
        python_callable=list_jobs,
        provide_context = True
    )    

    evaluate_job_status = BranchPythonOperator(
        task_id = 'evaluate_job_status',
        provide_context = True,
        python_callable = decide_branch
    )
    
    resubmit_dp_job = DataprocSubmitJobOperator(
        task_id="resubmit_dp_job",
        gcp_conn_id = cluster_project_id,
        job=SPARK_JOB,
        region= region,
        project_id= cluster_project_id
    )

    end_pipeline   =   DummyOperator(task_id = "end_pipeline",dag = dag)

    # Task dependencies
    start_pipeline >> extract_job_details >> evaluate_job_status
    evaluate_job_status >> resubmit_dp_job >> end_pipeline
    evaluate_job_status >> end_pipeline