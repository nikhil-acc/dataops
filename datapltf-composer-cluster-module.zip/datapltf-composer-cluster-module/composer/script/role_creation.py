import sys
import requests


def generate_request_data(role_name, gcp_token, airflow_uri):
    # Define the permissions for the role (modify as needed) - Last line must NOT have a (`,`)
    # You can find them here:
    # https://airflow.apache.org/docs/apache-airflow/2.1.1/security/access-control.html#permissions
    # or here:
    # https://github.com/apache/airflow/blob/main/airflow/security/permissions.py
    permissions_json = [
        {"action": {"name": "can_read"}, "resource": {"name": "Audit Logs"}},
        {"action": {"name": "can_read"}, "resource": {"name": "DAGs"}},
        {"action": {"name": "can_read"}, "resource": {"name": "DAG Dependencies"}},
        {"action": {"name": "can_read"}, "resource": {"name": "DAG Code"}},
        {"action": {"name": "can_read"}, "resource": {"name": "DAG Runs"}},
        {"action": {"name": "can_read"}, "resource": {"name": "Datasets"}},
        {"action": {"name": "can_read"}, "resource": {"name": "ImportError"}},
        {"action": {"name": "can_read"}, "resource": {"name": "DAG Warnings"}},
        {"action": {"name": "can_read"}, "resource": {"name": "Jobs"}},
        {"action": {"name": "can_read"}, "resource": {"name": "My Password"}},
        {"action": {"name": "can_edit"}, "resource": {"name": "My Password"}},
        {"action": {"name": "can_read"}, "resource": {"name": "My Profile"}},
        {"action": {"name": "can_edit"}, "resource": {"name": "My Profile"}},
        {"action": {"name": "can_read"}, "resource": {"name": "Plugins"}},
        {"action": {"name": "can_read"}, "resource": {"name": "SLA Misses"}},
        {"action": {"name": "can_read"}, "resource": {"name": "Task Instances"}},
        {"action": {"name": "can_read"}, "resource": {"name": "Task Logs"}},
        {"action": {"name": "can_read"}, "resource": {"name": "XComs"}},
        {"action": {"name": "can_read"}, "resource": {"name": "Website"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Browse"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "DAGs"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "DAG Dependencies"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "DAG Runs"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Datasets"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Documentation"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Docs"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Jobs"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Audit Logs"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Plugins"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "SLA Misses"}},
        {"action": {"name": "menu_access"}, "resource": {"name": "Task Instances"}},
        # {"action": {"name": "menu_access"}, "resource": {"name": "Composer Menu"}},
        # {"action": {"name": "menu_access"}, "resource": {"name": "DAGs in Cloud Console"}},
        # {"action": {"name": "menu_access"}, "resource": {"name": "DAGs in Cloud Storage"}},
        # {"action": {"name": "menu_access"}, "resource": {"name": "Environment Monitoring"}},
        # {"action": {"name": "menu_access"}, "resource": {"name": "Environment Logs"}},
        # {"action": {"name": "menu_access"}, "resource": {"name": "Composer Documentation"}},
        {"action": {"name": "can_create"}, "resource": {"name": "DAG Runs"}},
        {"action": {"name": "can_edit"}, "resource": {"name": "DAG Runs"}},
        {"action": {"name": "can_edit"}, "resource": {"name": "DAGs"}},
    ]

    data = {
        "actions": permissions_json,
        "name": role_name,
    }

    return data


def make_api_request(role_name, gcp_token, airflow_uri):
    url = f'{airflow_uri}/api/v1/roles'
    headers = {
        'Authorization': f'Bearer {gcp_token}',
        'accept': 'application/json',
        'Content-Type': 'application/json',
    }

    data = generate_request_data(role_name, gcp_token, airflow_uri)

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        return response.text
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 409:
            print(f"409 Conflict: Role '{role_name}' already exists. Updating instead.")
            # Perform a PATCH request to update the existing resource
            update_url = f'{airflow_uri}/api/v1/roles/{role_name}'
            try:
                response = requests.patch(update_url, headers=headers, json=data)
                response.raise_for_status()
                return response.text
            except requests.exceptions.RequestException as patch_error:
                print(f"Error making the PATCH request: {patch_error}")
                sys.exit(1)
        else:
            print(f"Error making the API request: {e}")
            sys.exit(1)


def main():
    if len(sys.argv) < 4:
        print("Usage: role_creation.py <role_name> <gcp_token> <airflow_uri>")
        sys.exit(1)

    role_name = sys.argv[1]
    gcp_token = sys.argv[2]
    airflow_uri = sys.argv[3]

    # This is helpful for troubleshooting, do not delete
    # print(f"The role name passed to the script is: {role_name}")
    # print(f"The GCP TOKEN: {gcp_token}")
    # print(f"The AIRFLOW URI: {airflow_uri}")

    # Generate the API request
    response_text = make_api_request(role_name, gcp_token, airflow_uri)
    print(f"API Response: {response_text}")


if __name__ == "__main__":
    main()
