# Composer

Dedicated module for creating Cloud Composer and airflow connections.

<a name="projectstructure"/>

## Project structure

```
.
├── composer
│   └── airflow_connection
│   └── templates
│   └── *.tf
├── test
│   └── terragrunt.hcl

```

There are 2 folders defined in this module's composer directory:

1. airflow_connection: Contains terraform configuration files to add/delete connections.
2. templates: Contains the dashboard template file which is used if the deploy_dashboard variable is set to true.

<a name="composer2"/>

### Composer2

<a name="com-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `composer2_suffix` | String, defines composer's name suffix region. | No | `cluster-02` |
| `composer2_size` | String, define the size of composer environment | No | `ENVIRONMENT_SIZE_LARGE` |
| `host_project` | String, name of the host project having shared vpc  | No | `hyc-shrd-svc-prod-01` |
| `shared_vpc` | String, name of shared vpc  | No | `vpc-hyc-prod-nane1-trust-prd` |
| `composer2_masternodes_cidr` | Map of strings, key is env | No | `npe: 6.254.6.144/28, dev: 6.254.6.128/28, stg: 6.254.6.0/28, prod: 6.254.0.128/28` |
| `composer2_nodes_subnet` | Map of string, ley is env  | No | `npe: snet-npda-nane1-dev-01, dev: snet-npda-nane1-dev-01, stg: snet-npda-nane1-stg-01, prod: snet-npda-nane1-prd-01` |
| `composer2_pods_rangename` | Map of string, key is env| No | `npe: snet-npda-nane1-dev-secondary-05, dev: snet-npda-nane1-dev-secondary-03, stg: snet-npda-nane1-stg-secondary-03, prod: snet-npda-nane1-prd-secondary-03` |
| `composer2_svcs_rangename` | Map of string, key is env | No | `npe: snet-npda-nane1-dev-secondary-06, dev: snet-npda-nane1-dev-secondary-04, stg: snet-npda-nane1-stg-secondary-04, prod: snet-npda-nane1-prd-secondary-04` |
| `composer2_maintenance_start_time` | String, Start time for maintenance window of composer | No | `2022-05-06T06:00:00Z` |
| `composer2_maintenance_end_time` | String, End time for maintenance window of composer  | No | `2022-05-06T10:00:00Z` |
| `composer2_maintenance_recurrence` | String, Recurrence for maintenance window of composer  | No | `FREQ=WEEKLY;BYDAY=MO,TU,WE,TH` |
| `users` |list(map(string)), Add users and roles to control the airflow ui permissions | No | |
| `default_role` | Default role attributed to all tenants | Yes | `Viewer` |
| `roles` |list(map(string)), Add roles to control the airflow ui roles and permissions | No | |
| `lineage_integration` | Data lineage integration in composer - it's a boolean | Yes | `false` |
| `worker_concurrency` | String, Defines the number of tasks a single worker can pick up from the task queue. | No | `6` |
| `workload_scheduler_config` | Map of number , Configuration for resources used by Airflow schedulers. Key values : cpu, memory_gb, storage_gb and count. | Yes | If not provided, default values for the environment size will take effect. |
| `workload_web_server_config` | Map of number , Configuration for resources used by Airflow triggerer. Key values : cpu, memory_gb and storage_gb. | Yes | If not provided, default values for the environment size will take effect. |
| `workload_worker_config` | Map of number , Configuration for resources used by Airflow workers. Key values : cpu, memory_gb, storage_gb, min_count and max_count. | Yes | If not provided, default values for the environment size will take effect. |

If values for `workload_scheduler_config`, `workload_web_server_config` and `workload_worker_config` are updated, the dashboard resource will be recreated.

#### Notes

In `role_creation.py` script, as of now, we can NOT remove a permissions with the script. It has to be done through the GUI. This is not because of the script, but because of the REST API that is not working as it should. <br>
You can keep track of it here:<br>
https://github.com/apache/airflow/pull/29132

# Bell Corporate Security Requirements

Cloud Composer Security Scorecard:
https://confluence.bell.corp.bce.ca/display/NBD/EDP+Cloud+Composer+Security+Requirements

The following settings/configurations must be left up to Google to manage on behalf of Bell
* None of Google's default security settings can be disabled (DR10)
* Encryption at rest within GCP must not be disabled (ER1)
* Default security confguration must not be altered during initial configuration of the GCP services (H3)

DR8 - Configuration/settings files are found at the following location (ephemeral deployment for testing):
https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-composer-cluster-module/-/blob/main/test/terragrunt.hcl

DR9 - Application dependencies and versioning is found at the following location (composer version):
https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-composer-cluster-module/-/blob/main/test/terragrunt.hcl#L34

