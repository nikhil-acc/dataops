# Dataproc Serverless
This project uses the [common-modules](https://gitlab.int.bell.ca/nbd/dataplatform/gcp/datapltf-modules/datapltf-common-modules) project. Version 1.6.0 of common modules changed the way dataflow jobs are created/deployed by using released flex-template.jsons see [df/README.md](./df/README.md#flex-templatejson). 

# Getting Started

After cloning the repo you should install the [pre-commit git hook](#pre-commit) by running `pre-commit install`

## pre-commit
The project uses the [pre-commit tool](https://pre-commit.com/) which provides a framework for ensuring code quality by orchestrating the execution various other code tools. It is meant to be run as a [git hook](https://git-scm.com/docs/githooks). Use `pre-commit install` to install a script in your .git/hooks/ which will execute pre-commit automatically on `git commit ...` commands.

Any code commited that doesn't conform to the pre-commit configuration will fail within the gitlab pipeline executions since pre-commit is also run there.

To manually run pre-commit simply run `pre-commit`. 

To run a specific pre-commit hook defined in the [.pre-commit-config.yaml](./.pre-commit-config.yaml) run `pre-commit run HOOK_ID`.

To install the pre-commit tool see [installation](https://pre-commit.com/#installation).
Other possible install options:
- Most Linux package managers have a pre-commit package
- Brew has a pre-commit package
- winget has a pre-commit package

### Troubleshooting
#### Can't find go executable
When trying to run pre-commit there is the following error about a go executable:
```sh
$ pre-commit run -a
[INFO] Initializing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Initializing environment for https://github.com/gitleaks/gitleaks.
[INFO] Installing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Once installed this environment will be reused.
[INFO] This may take a few minutes...
[INFO] Installing environment for https://github.com/gitleaks/gitleaks.
[INFO] Once installed this environment will be reused.
[INFO] This may take a few minutes...
An unexpected error has occurred: CalledProcessError: command: ('go', 'get', './...')
return code: 1
expected return code: 0
stdout:
    Executable `go` not found
stderr: (none)
Check the log at /home/user/.cache/pre-commit/pre-commit.log
```

pre-commit version 3 and up support tools built with go as first class citizens. pre-commit will install a golang toolchain if one is not present. pre-commit version less than 3 required the system to already have golang toolchain installed if the user wanted to use tools built with golang. We use gitleaks in our pre-commit configuration and gitleaks is built with golang.

What version pre-commit am I running: `pre-commit -V`

Solution 1: Upgrade pre-commit
```sh
# Is pre-commit installed as an os package
sudo dpkg -S `which pre-commit`
# If it is uninstall it
sudo apt purge pre-commit
# else it must be installed with pip
# upgrade or install pre-commit with pip
pip3 install pre-commit
# this will be a "user" install so you will need to have $HOME/.local/bin/ in your path
```

Solution 2: Install golang toolchain `sudo apt install golang-1.19`

#### Virtualenv conflict
When trying to run pre-commit there is the following error about virtualenv

```sh
$ pre-commit run -a
[INFO] Initializing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Initializing environment for https://github.com/gitleaks/gitleaks.
[INFO] Installing environment for https://github.com/pre-commit/pre-commit-hooks.
[INFO] Once installed this environment will be reused.
[INFO] This may take a few minutes...
An unexpected error has occurred: CalledProcessError: command: ('/usr/bin/python3', '-mvirtualenv', '/home/user/.cache/pre-commit/repomjb9rr25/py_env-python3')
return code: 1
stdout:
    AttributeError: module 'virtualenv.create.via_global_ref.builtin.cpython.mac_os' has no attribute 'CPython2macOsFramework'
stderr: (none)
Check the log at /home/user/.cache/pre-commit/pre-commit.log
```

This seems to be due to pre-commit finding the virtualenv library installed.


Solution: Use python3's venv and uninstall virtualenv.

Ensure python3 venv is installed
```sh
sudo apt install python3-venv
```

Ensure virtualenv is uninstalled
```sh
pip3 uninstall virtualenv
```

# DataFlow
See [dataflow](./df/README.md) README.md.


# Environments
There are two types of environments:
1. static long lived environments
2. ephemeral environments

## Static Environments
Environments used for infrastructure that is long lived (ex: development, staging, production). These static environments are defined in the single-rater-deployment repository.

## Ephemeral Environments
Ephemeral environments are short lived and used for testing of features being developed. They are spun up and torn down in merge request pipelines. They generate unique names for resources using an identifier based on the git branch name.

# Pipelines
There are two types of pipelines in use:
1. merge request pipelines
2. release pipeline

All pipelines utilize targeted building in order to only run CI jobs that need to be run based on code that has actually changed. So if there is a change to the terraform, only the terraform will be built and released.

## Merge Request Pipeline

The Merge Request pipeline is triggered on commits pushed to a branch with a merge request targeting master. It is used for building:
- development ephemeral environments (one per MR)
- snapshots of container images and flex templates (used by the development ephemeral environments)

### How does the targeted building work with ephemeral environments?
The ephemeral environments have optional `*_flex_template_url` variables for each deployable thing, for example `kafkatocloudstorage_flex_template_url`. These default to `latest` versions that are released in the release pipeline.

What is a `latest` version?

The release pipeline releases `latest` versions for everything. These `latest` versions point to the last version released and stored in the release part of artifactory.

When code changes trigger something to be rebuilt, the merge request pipeline builds snapshots of just those changes storing them in snapshots part of artifactory and will set the corresponding `_flex_template_url` variable to point to the URL to the correct version for that snapshot. It does this using Gitlab's dotenv facility. By outputting a dotenv file with values like `TF_VAR_kafkatocloudstorage_flex_template_url=...` the terraform apply step will pick up these values and override latest.

## Release Pipeline
The Release pipeline is triggered after a merge to master. It will build the versioned releases of flex templates, container images and the terraform module used in deployments in the single-rater-deployment repo.

### How does the deployment MR creation work?

A CI release job is a job in a release pipeline which creates a versioned artifact that can be later deployed to an environment. Each CI release job (on successful release) will pass along to the deployment stage what it built and released so that the deployment stage can update the deployment repo with the new versions of only what was released. It does this using the gitlab dotenv mechanism similar to the MR pipelines above. Each CI release job (on successful release) will output a dotenv artifact with a "release environment variable" with the following format:

RELEASE_VERSION_{UPDATE_TYPE}_{COMPONENT_ID}={RELEASEVERSION}

For example:
```
RELEASE_VERSION_TFM_single_rater=cb48f02
RELEASE_VERSION_TFV_kafkatocloudstorage=cb48f02
```

In the deployment stage all these dotenv artifacts are automatically merged together by gitlab and the deployment script finds the updates by filtering all environment variables with the prefix RELEASE_VERSION_. It will then update each component in all environments in the deployment repo with the new version.

For flex templates it generates a tfvars file for that specific component, ex: `kafkatocloudstorage_version.auto.tfvars.json`. Each environment has a terraform variable `kafkatocloudstorage_version` defined which picks up the value of the tfvars files created. This also allows specifying a different flex template version in the case where a flex template is used more than once for different dataflow jobs and for some reason the version to be used for one of them must be frozen at a specific version.

For terraform module versions it does a text replacement directly in the module source attribute of the terraform file.

# Secrets

Secrets are passed in to each environment through terraform variables. The secret values are set on the Gitlab project as environment variables.

For the keytab secret, a keytab file is generated before terraform plan using ktutil and passed to terraform plan as a base64 encoded variable value. Generating keytabs with ktutil is not idempotent. Given the same inputs it generates a unique file each time causing terraform to always update the secret. This is due to an execution timestamp that ktutil adds to the keytab file. In order to overcome this issue, instead of running ktutil directly, a python script runs the ktutil command and then overwrites the timestamp to a static value of 2024-01-01 making the generation of the keytab file idempotent.

# Bell Corporate Security Requirements

Single Rater Security Scorecard:
https://confluence.bell.corp.bce.ca/display/NBD/Single+Rater+Security+Requirements

The following settings/configurations must be left up to Google to manage on behalf of Bell
* None of Google's default security settings can be disabled (DR10)
* Encryption at rest within GCP must not be disabled (ER1)
* Default security confguration must not be altered during initial configuration of the GCP services (H3)

DR8 - Configuration/settings files are found at the following location:   
https://gitlab.int.bell.ca/nbd/smartcore/charging/single-rater/-/blob/master/terraform/main.tf  

DR9 - Application dependencies and versioning is found at the following location:  
https://gitlab.int.bell.ca/nbd/smartcore/charging/single-rater/-/blob/master/df/pom.xml  




