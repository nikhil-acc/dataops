-- Initial clean up of temp tables
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.bell_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_error_records_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_guided_ccr_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_bell_usage_ingest_error_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_rated_ccrs_deduplicated_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_skipped_records_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_reject_records_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_late_usage_records_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_partial_daily_summary_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_daily_summary_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_au_aggr_record_type_1_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rated_usages_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_daily_summary_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_intake_reject_records_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rerate_triggers_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_au_aggr_record_type_1_temp;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_free_filter_temp;

-- Create temp tables
-- bell
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.bell_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT dt_skey,
    bytesIn,
    bytesOut,
    roamingIndicator,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId, imsi
      ORDER BY ingested_on_lnd DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.bell`
    -- partition
    WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto"))
  WHERE record_row_number = 1
);

-- wnc_cgf_que_unrated_mapping
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT dt_skey,
    bytesIn,
    bytesOut,
    roamingIndicator,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId, imsi
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_cgf_que_unrated_mapping`
    -- partition
    WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto"))
  WHERE record_row_number = 1
);

-- wnc_cgf_que_unrated_mapping_error_records
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_error_records_temp 
PARTITION BY
  dt_skey
AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT dt_skey,
    bytesIn,
    bytesOut,
    roamingIndicator,
    xCorrelationId,
    imsi,
    -- rank
    ROW_NUMBER() 
        OVER (PARTITION BY xCorrelationId, imsi
        ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_cgf_que_unrated_mapping_error_records`
    -- partition
    WHERE dt_skey BETWEEN DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH) AND CURRENT_DATE("America/Toronto"))
  WHERE record_row_number = 1
);

-- wnc_arc_guided_ccr
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_guided_ccr_temp 
PARTITION BY
  dt_skey
AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      bytesIn,
      bytesOut,
      roamingIndicator,
      IMSI,
      xCorrelationId,
      dt_skey,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId, imsi
      ORDER BY ingested_on_lnd DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_arc_guided_ccr`
    -- partition
    WHERE dt_skey BETWEEN DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH) AND CURRENT_DATE("America/Toronto")
      AND sessionId NOT LIKE "%0100-provisioning%")
  WHERE record_row_number = 1
);

-- wnc_arc_bell_usage_ingest_error
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_bell_usage_ingest_error_temp
PARTITION BY
  dt_skey 
AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      dt_skey,
      bytesIn,
      bytesOut,
      imsi,
      roamingIndicator,
      xCorrelationId,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId, imsi
      ORDER BY ingested_on_lnd DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_arc_bell_usage_ingest_error`
    -- partition
    WHERE dt_skey BETWEEN DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH) AND CURRENT_DATE("America/Toronto"))
  WHERE record_row_number = 1
);

-- wnc_odf_que_rated_ccrs_deduplicated
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_rated_ccrs_deduplicated_temp
PARTITION BY
  DATE_TRUNC(month_skey, MONTH)
AS (
  SELECT * except(record_row_number, month_skey_est, reporting_date_est),
  -- rename month_skey and reporting_date 
    month_skey_est AS month_skey,
    reporting_date_est AS reporting_date
  FROM (
    SELECT 
      at_call_dur_round_min,
      getSubscriberBalancesResponse.account.accountType, 
      getSubscriberBalancesResponse.account.accountSubType,
      source,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      usageDetails.subscriberId,
      rerateVersion,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) as month_skey_est,
    EXTRACT(DATE FROM TIMESTAMP_MILLIS(usageDetails.startTime) AT TIME ZONE "America/Toronto") AS reporting_date_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_rated_ccrs_deduplicated`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
      DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
      DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
  AND month_skey_est
    IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
        DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
        DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 3 EST month partition
);

-- wnc_odf_que_intake_skipped_records
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_skipped_records_temp
PARTITION BY
  DATE_TRUNC(month_skey, MONTH)
AS (
  SELECT * except(record_row_number, month_skey_est, reporting_date_est),
  -- rename month_skey and reporting_date
  month_skey_est AS month_skey,
  reporting_date_est AS reporting_date
  FROM (
    SELECT 
      usageDetails.bytesIn,
      usageDetails.bytesOut,
      getSubscriberBalancesResponse.account.accountType,
      getSubscriberBalancesResponse.account.accountSubType,
      source,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      usageDetails.subscriberId,
      rerateVersion,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) AS month_skey_est,
    EXTRACT(DATE FROM TIMESTAMP_MILLIS(usageDetails.startTime) AT TIME ZONE "America/Toronto") AS reporting_date_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_intake_skipped_records`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
      DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
      DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
    AND month_skey_est 
    IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
        DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
        DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 3 EST month partition
);

-- wnc_odf_que_intake_reject_records
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_reject_records_temp
PARTITION BY
  DATE_TRUNC(month_skey, MONTH)
AS (
  SELECT * except(record_row_number, month_skey_est, reporting_date_est),
  -- rename month_skey and reporting_date to EST timezone
  month_skey_est AS month_skey,
  reporting_date_est AS reporting_date
  FROM (
    SELECT 
      usageDetails.bytesIn,
      usageDetails.bytesOut,
      getSubscriberBalancesResponse.account.accountType,
      getSubscriberBalancesResponse.account.accountSubType,
      source,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      usageDetails.subscriberId,
      rerateVersion,
      ban,
      ratingStatus,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) AS month_skey_est,
    EXTRACT(DATE FROM TIMESTAMP_MILLIS(usageDetails.startTime) AT TIME ZONE "America/Toronto") AS reporting_date_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_intake_reject_records`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
      DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
      DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    AND usageDetails.sessionId NOT LIKE "%artificialCCR%")
  WHERE record_row_number = 1
  AND month_skey_est
    IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
        DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
        DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 3 EST month partition
);

-- wnc_odf_que_intake_late_usage_records
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_late_usage_records_temp
PARTITION BY
  DATE_TRUNC(month_skey, MONTH)
AS (
  SELECT * except(record_row_number, month_skey_est, reporting_date_est),
  -- rename month_skey and reporting_date to EST timezone
  month_skey_est AS month_skey,
  reporting_date_est AS reporting_date
  FROM (
    SELECT 
      usageDetails.bytesIn,
      usageDetails.bytesOut,
      getSubscriberBalancesResponse.account.accountType,
      getSubscriberBalancesResponse.account.accountSubType,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      usageDetails.subscriberId,
      rerateVersion,
      source,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) AS month_skey_est,
    EXTRACT(DATE FROM TIMESTAMP_MILLIS(usageDetails.startTime) AT TIME ZONE "America/Toronto") AS reporting_date_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_intake_late_usage_records`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
      DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
      DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
  AND month_skey_est
    IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH),
        DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
        DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 3 EST month partition
);

-- wnc_odf_que_partial_daily_summary
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_partial_daily_summary_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      month_skey,
      at_call_dur_round_min,
      ban,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY ban, subscriber_no, business_id, channel_seizure_dt, message_switch_id
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_partial_daily_summary`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_odf_que_daily_summary
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_daily_summary_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      ban,
      subscriber_no,
      at_call_dur_round_min,
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      month_skey,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY cycle_code,cycle_run_year,cycle_run_month,ban, subscriber_no, business_id, channel_seizure_dt, message_switch_id
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_daily_summary`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_odf_que_au_aggr_record_type_1
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_au_aggr_record_type_1_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      chrg_amt,
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      subscriber_no,
      ban,
      rating_start_time,
      month_skey,
      soc,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY cycle_code,cycle_run_year,cycle_run_month,ban,subscriber_no,SOC,airtime_feature_cd,service_ftr_seq_no,extended_hm_area_ind
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_au_aggr_record_type_1`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_odf_que_unique_reject_summary
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      month_skey,
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      ban,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY cycle_code,cycle_run_year,cycle_run_month,ban
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_unique_reject_summary`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_arc_que_billed_rated_usages
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rated_usages_temp AS (
  SELECT * except(record_row_number, month_skey_est),
  -- rename month_skey
  month_skey_est AS month_skey
  FROM (
    SELECT 
      usageDetails.ban,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      xCorrelationId,
      ratingStartTime,
      getSubscriberBalancesResponse.account.accountType,
      getSubscriberBalancesResponse.account.accountSubType,
      rerateVersion,
      usageDetails.bytesIn,
      usageDetails.bytesOut,
      source,
      ratingStatus,
      ocrtOutput.usageNotApplied,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) AS month_skey_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_arc_que_billed_rated_usages`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
  AND month_skey_est
    IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 2 EST month partition
);

-- wnc_odf_que_billed_daily_summary
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_daily_summary_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      at_call_dur_round_min,
      month_skey,
      ban,
      rerate_version,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY cycle_code,cycle_run_year,cycle_run_month,ban, subscriber_no, business_id, channel_seizure_dt, message_switch_id
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_billed_daily_summary`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_odf_que_billed_unique_reject_summary
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      month_skey,
      ban,
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      rerate_version,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY cycle_code,cycle_run_year,cycle_run_month,ban
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_billed_unique_reject_summary`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_odf_que_billed_intake_reject_records
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_intake_reject_records_temp AS (
  SELECT * except(record_row_number, month_skey_est),
  -- rename month_skey and reporting_date to EST timezone
  month_skey_est AS month_skey
  FROM (
    SELECT 
      ban,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      rerate_version,
      usageDetails.bytesIn,
      usageDetails.bytesOut,
      getSubscriberBalancesResponse.account.accountType,
      getSubscriberBalancesResponse.account.accountSubType,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) AS month_skey_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_billed_intake_reject_records`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
  AND month_skey_est
    IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 2 EST month partition
);

-- wnc_arc_que_billed_rerate_triggers
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rerate_triggers_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      month_skey,
      ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.ban,
      ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleCode,
      ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleMonth,
      ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.cycleYear,
      ImplBilledRerateReqRestOutput.baseOutput.arcNm1RequestDetail.errMsgList,
      ImplBilledRerateReqRestOutput.baseOutput.arcNm1RequestDetail.batchRunId,
      ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.accType,
      ImplBilledRerateReqRestOutput.baseOutput.arcCustDetail.accSubType,
      ImplBilledRerateReqRestOutput.baseOutput.arcNm1RequestDetail.billedRerateCounter,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY ImplBilledRerateReqRestOutput.baseOutput.arcNm1RequestDetail.ban, ImplBilledRerateReqRestOutput.baseOutput.arcNm1RequestDetail.batchRunId, 
      ImplBilledRerateReqRestOutput.baseOutput.arcNm1RequestDetail.billedRerateCounter
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_arc_que_billed_rerate_triggers`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_odf_que_billed_au_aggr_record_type_1
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_au_aggr_record_type_1_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      ban,
      LTRIM(cycle_code, '0') AS cycle_code,
      LTRIM(cycle_run_month, '0') AS cycle_run_month,
      LTRIM(cycle_run_year, '0') AS cycle_run_year,
      rerate_version,
      chrg_amt,
      month_skey,
      subscriber_no,
      rating_start_time,
      soc,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY cycle_code,cycle_run_year,cycle_run_month,ban,subscriber_no,SOC,airtime_feature_cd,service_ftr_seq_no,extended_hm_area_ind
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_odf_que_billed_au_aggr_record_type_1`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
);

-- wnc_cgf_que_unrated_mapping_free_filter
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_free_filter_temp AS (
  SELECT * except(record_row_number)
  FROM (
    SELECT 
      ratingGroup,
      APN,
      bytesIn,
      bytesOut,
      IMSI,
      xCorrelationId,
      dt_skey,
      roamingIndicator,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId, imsi
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_cgf_que_unrated_mapping_free_filter`
    -- partition
    WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto"))
  WHERE record_row_number = 1
);