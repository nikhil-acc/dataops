DELETE `{{ project_id }}.{{ sr_esd_dataset }}.daily_reconciliation_without_atst`
WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto");

INSERT `{{ project_id }}.{{ sr_esd_dataset }}.daily_reconciliation_without_atst` (
  dt_skey,
  ecs_successful_sent_record_count,
  ecs_successful_sent_byte_count,
  cgf_successful_sent_record_count,
  cgf_successful_sent_byte_count,
  cgf_failed_sent_record_count,
  cgf_failed_sent_byte_count
)


-- KPI 1: ECS Successful Sent
WITH ecs_successful_sent AS (
    SELECT dt_skey,
      COUNT(*) as ecs_successful_sent_record_count,
      SUM(bytesIn + bytesOut)/1048576 as ecs_successful_sent_byte_count
    FROM {{ project_id }}.{{ sr_esd_dataset }}.bell_temp
    WHERE roamingIndicator IN ("H", "C")
    GROUP BY dt_skey 
  ),

  -- KPI 2: CGF Successful Sent
  cgf_successful_sent AS (
    SELECT dt_skey,
      COUNT(*) as cgf_successful_sent_record_count,
      SUM(bytesIn + bytesOut)/1048576 as cgf_successful_sent_byte_count
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_temp
    WHERE roamingIndicator IN ("H", "C")
    GROUP BY dt_skey 
  ),

  -- KPI 3: CGF Failed Sent
  cgf_failed_sent AS (
    SELECT dt_skey,
    COUNT(*) as cgf_failed_sent_record_count,
    SUM(bytesIn + bytesOut)/1048576 as cgf_failed_sent_byte_count,
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_error_records_temp
    WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")
    AND roamingIndicator IN ("H", "C")
    GROUP BY dt_skey 
  )

  
SELECT 
  dt_skey,
  COALESCE(ecs_successful_sent_record_count, 0) AS ecs_successful_sent_record_count,
  COALESCE(ecs_successful_sent_byte_count, 0) AS ecs_successful_sent_byte_count,
  COALESCE(cgf_successful_sent_record_count, 0) AS cgf_successful_sent_record_count,
  COALESCE(cgf_successful_sent_byte_count, 0) AS cgf_successful_sent_byte_count,
  COALESCE(cgf_failed_sent_record_count, 0) AS cgf_failed_sent_record_count,
  COALESCE(cgf_failed_sent_byte_count, 0) AS cgf_failed_sent_byte_count
FROM ecs_successful_sent              -- KPI 1
FULL OUTER JOIN cgf_successful_sent   -- KPI 2
USING (dt_skey)      
FULL OUTER JOIN cgf_failed_sent       -- KPI 3
USING (dt_skey)

