 DELETE `{{ project_id }}.{{ sr_esd_dataset }}.billed_rerate_insight` 
 WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH));

 INSERT INTO `{{ project_id }}.{{ sr_esd_dataset }}.billed_rerate_insight` 

-- max rerate version billed rerate triggers with one reason per record
WITH rerate_triggers_max_rerate_ver_with_reason AS (
  SELECT * FROM(
  SELECT 
    month_skey,
    ban, 
    cycleCode AS bcc,
    cycleMonth AS mm,
    cycleYear AS yy,
    RIGHT(er.errMsgText, STRPOS(REVERSE(er.errMsgText), "|") - 1) AS reason,
    batchRunId AS rerateVersion,
    COALESCE(CONCAT(accType, accSubType), "unknown ATST") AS ATST,
    RANK() 
      OVER (PARTITION BY cycleYear, cycleMonth, cycleCode, ban, billedRerateCounter ORDER BY batchRunId DESC) AS batchrunId_rank,
    billedRerateCounter
  FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rerate_triggers_temp,
  UNNEST(errMsgList) er
  )
  WHERE batchrunId_rank = 1
),

-- Latest billed_rated_usages ATST broken down by ban, bcc_mm_yy and rerate_counter
latest_billed_atst_ban_bccmmyy_rerate_counter AS (
  SELECT
    month_skey,
    ban,
    bcc,
    mm,
    yy,
    rerate_counter,
    ratingStartTime,
    COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') AS ATST,
    rerateVersion,
    bytesIn,
    bytesOut,
    unapplied_bytes,
    source,
    ratingStatus,
  FROM (
    SELECT
      ban,
      bcc,
      EXTRACT(MONTH FROM month_skey) AS mm,
      EXTRACT(YEAR FROM month_skey) AS yy,
      SPLIT(xCorrelationId, '|')[offset(1)] AS rerate_counter,
      ROW_NUMBER() OVER 
        (PARTITION BY EXTRACT(YEAR FROM month_skey), EXTRACT(MONTH FROM month_skey), bcc, ban, SPLIT(xCorrelationId, '|')[offset(1)] 
         ORDER BY ratingStartTime DESC) AS ratingStartTime_rank,
      ratingStartTime,
      accountType AS accountType,
      accountSubType AS accountSubType,
      month_skey,
      rerateVersion,
      bytesIn,
      bytesOut,
      source,
      ratingStatus,
      (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) AS una) AS unapplied_bytes
    FROM
      {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rated_usages_temp
    )
  WHERE
    ratingStartTime_rank = 1
  ),

-- KPI 11, 22
attempt_requests AS (
  SELECT 
    COUNT(first_attempt_ban) AS number_of_first_attempt_requests, -- KPI 11
    COUNT(second_attempt_ban) AS number_of_second_attempt_requests, -- KPI 22
    bcc,
    mm,
    yy, 
    ATST,
    month_skey
  FROM (
    SELECT
      CASE WHEN billedRerateCounter = 0 THEN ban ELSE NULL END AS first_attempt_ban,
      CASE WHEN billedRerateCounter = 1 THEN ban ELSE NULL END AS second_attempt_ban,
      bcc,
      mm,
      yy,
      ATST,
      month_skey
    FROM rerate_triggers_max_rerate_ver_with_reason
  GROUP BY ALL)
  GROUP BY month_skey, yy, mm, bcc, ATST),

-- KPI 12 - 14, 23 - 25
request_reasons AS (
  SELECT 
  COUNT(first_attempt_request_reason_counts) AS first_attempt_request_reason_counts,
  COUNT(second_attempt_request_reason_counts) AS second_attempt_request_reason_counts,
  bcc,
  mm,
  yy, 
  reason, 
  ATST,
  month_skey
FROM (
SELECT
  CASE WHEN billedRerateCounter = 0 THEN ban ELSE NULL END AS first_attempt_request_reason_counts,
  CASE WHEN billedRerateCounter = 1 THEN ban ELSE NULL END AS second_attempt_request_reason_counts,
  bcc,
  mm,
  yy, 
  reason, 
  ATST,
  month_skey
FROM rerate_triggers_max_rerate_ver_with_reason
GROUP BY ALL
)
GROUP BY month_skey, yy, mm, bcc, ATST, reason
),



rerate_success AS (
  SELECT 
  CASE WHEN billedRerateCounter = 0 THEN rerate_triggers_max_rerate_ver_with_reason.ban ELSE NULL END AS first_attempt_ban,
  CASE WHEN billedRerateCounter = 0 THEN rerate_triggers_max_rerate_ver_with_reason.bcc ELSE NULL END AS first_attempt_bcc,
  CASE WHEN billedRerateCounter = 0 THEN rerate_triggers_max_rerate_ver_with_reason.mm ELSE NULL END AS first_attempt_mm,
  CASE WHEN billedRerateCounter = 0 THEN rerate_triggers_max_rerate_ver_with_reason.yy ELSE NULL END AS first_attempt_yy,
  CASE WHEN billedRerateCounter = 0 THEN rerate_triggers_max_rerate_ver_with_reason.rerateVersion ELSE NULL END AS first_attempt_rerateVersion,
  CASE WHEN billedRerateCounter = 0 THEN rerate_triggers_max_rerate_ver_with_reason.month_skey ELSE NULL END AS first_attempt_month_skey,
  CASE WHEN billedRerateCounter = 1 THEN rerate_triggers_max_rerate_ver_with_reason.ban ELSE NULL END AS second_attempt_ban,
  CASE WHEN billedRerateCounter = 1 THEN rerate_triggers_max_rerate_ver_with_reason.bcc ELSE NULL END AS second_attempt_bcc,
  CASE WHEN billedRerateCounter = 1 THEN rerate_triggers_max_rerate_ver_with_reason.mm ELSE NULL END AS second_attempt_mm,
  CASE WHEN billedRerateCounter = 1 THEN rerate_triggers_max_rerate_ver_with_reason.yy ELSE NULL END AS second_attempt_yy,
  CASE WHEN billedRerateCounter = 1 THEN rerate_triggers_max_rerate_ver_with_reason.rerateVersion ELSE NULL END AS second_attempt_rerateVersion,
  CASE WHEN billedRerateCounter = 1 THEN rerate_triggers_max_rerate_ver_with_reason.month_skey ELSE NULL END AS second_attempt_month_skey,
  billedRerateCounter
 FROM rerate_triggers_max_rerate_ver_with_reason
 LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp reject
  ON
    rerate_triggers_max_rerate_ver_with_reason.ban = reject.ban 
    AND rerate_triggers_max_rerate_ver_with_reason.bcc = CAST(reject.cycle_code AS INT)
    AND rerate_triggers_max_rerate_ver_with_reason.mm = CAST(reject.cycle_run_month AS INT)
    AND rerate_triggers_max_rerate_ver_with_reason.yy = CAST(reject.cycle_run_year AS INT)
    AND CAST(rerate_triggers_max_rerate_ver_with_reason.rerateVersion AS INT) = reject.rerate_version
  WHERE 
    reject.rerate_version IS NULL AND reject.cycle_code IS NULL 
      AND reject.cycle_run_month IS NULL AND reject.cycle_run_year IS NULL AND reject.ban IS NULL
      AND (billedRerateCounter = 0 OR billedRerateCounter = 1)
  GROUP BY rerate_triggers_max_rerate_ver_with_reason.ban, rerate_triggers_max_rerate_ver_with_reason.bcc, rerate_triggers_max_rerate_ver_with_reason.mm,
    rerate_triggers_max_rerate_ver_with_reason.yy, rerate_triggers_max_rerate_ver_with_reason.rerateVersion, rerate_triggers_max_rerate_ver_with_reason.month_skey,
    billedRerateCounter
),

-- KPI 15, 16, 26, 27
successful_daily_kpis AS (
  SELECT 
    COUNTIF(billedRerateCounter = 0) AS total_count_of_successful_first_attempt_daily_records,
    COUNTIF(billedRerateCounter = 1) AS total_count_of_successful_second_attempt_daily_records, 
    CAST(billed_ds.cycle_code AS INT) AS bcc, 
    CAST(billed_ds.cycle_run_month AS INT) AS mm,
    CAST(billed_ds.cycle_run_year AS INT) AS yy,
    COALESCE(ATST, 'unknown ATST') AS ATST,
    SUM(CASE WHEN billedRerateCounter = 0 THEN billed_ds.at_call_dur_round_min ELSE 0 END)/1048576 AS total_volume_of_successful_first_attempt_daily_records,
    SUM(CASE WHEN billedRerateCounter = 1 THEN billed_ds.at_call_dur_round_min ELSE 0 END)/1048576 AS total_volume_of_successful_second_attempt_daily_records,
    billed_ds.month_skey
  FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_daily_summary_temp billed_ds
  INNER JOIN rerate_success 
    ON
      COALESCE(first_attempt_ban, second_attempt_ban) = billed_ds.ban 
      AND COALESCE(first_attempt_bcc, second_attempt_bcc) = CAST(billed_ds.cycle_code AS INT)
      AND COALESCE(first_attempt_mm, second_attempt_mm) = CAST(billed_ds.cycle_run_month AS INT)
      AND COALESCE(first_attempt_yy, second_attempt_yy) = CAST(billed_ds.cycle_run_year AS INT)
      AND CAST(COALESCE(first_attempt_rerateVersion, second_attempt_rerateVersion) AS INT) = billed_ds.rerate_version
  LEFT JOIN latest_billed_atst_ban_bccmmyy_rerate_counter 
    ON billed_ds.ban = latest_billed_atst_ban_bccmmyy_rerate_counter.ban 
      AND billed_ds.cycle_code = latest_billed_atst_ban_bccmmyy_rerate_counter.bcc
      AND CAST(billed_ds.cycle_run_month AS INT) = latest_billed_atst_ban_bccmmyy_rerate_counter.mm
      AND CAST(billed_ds.cycle_run_year AS INT) = latest_billed_atst_ban_bccmmyy_rerate_counter.yy
  WHERE latest_billed_atst_ban_bccmmyy_rerate_counter.rerate_counter IN ("0", "1")
  GROUP BY billed_ds.month_skey, billed_ds.cycle_run_year, billed_ds.cycle_run_month, billed_ds.cycle_code, ATST
),

-- all subscriber numbers that have / had SOC = "PURGESOC" and the max rating start time of the purge record
-- broken down by bcc_mm_yy, ban, rerate_version
latest_purged_subscribers AS (
  SELECT *
  FROM (
  SELECT
    subscriber_no,
    ROW_NUMBER() OVER (partition by cycle_run_year, cycle_run_month, cycle_code, ban, rerate_version ORDER BY rating_start_time DESC) AS rating_start_time_rank,
    rating_start_time,
    ban,
    cycle_code AS bcc,
    cycle_run_month AS mm,
    cycle_run_year AS yy,
    rerate_version,
    month_skey
  FROM
    {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_au_aggr_record_type_1_temp
  WHERE
    soc = "PURGESOC"
  )
  WHERE rating_start_time_rank = 1
),

-- Create CTE for non-purged subscriber
non_purged_subscriber AS (
  SELECT billed_au_type_1.ban,
  billed_au_type_1.cycle_code AS bcc,
  billed_au_type_1.cycle_run_month AS mm,
  billed_au_type_1.cycle_run_year AS yy,
  billed_au_type_1.rerate_version,
  chrg_amt,
  billed_au_type_1.month_skey
  FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_au_aggr_record_type_1_temp billed_au_type_1
  LEFT JOIN latest_purged_subscribers
  ON billed_au_type_1.subscriber_no = latest_purged_subscribers.subscriber_no
    AND billed_au_type_1.ban = latest_purged_subscribers.ban
    AND billed_au_type_1.cycle_code = latest_purged_subscribers.bcc
    AND billed_au_type_1.cycle_run_month = latest_purged_subscribers.mm
    AND billed_au_type_1.cycle_run_year = latest_purged_subscribers.yy
    AND billed_au_type_1.rerate_version = latest_purged_subscribers.rerate_version 
    WHERE 
     -- include results where 1.subscriber has nopurge OR 2.the subscriber's newer record is not "PURGESOC"
    latest_purged_subscribers.subscriber_no IS NULL
    OR
    (latest_purged_subscribers.subscriber_no IS NOT NULL 
      AND billed_au_type_1.rating_start_time > latest_purged_subscribers.rating_start_time)
),

charged_successful AS (
  SELECT 
  sum(CASE WHEN rerate_counter = "0" THEN chrg_amt ELSE 0 END) as total_overage_successful_first_attempt_charge,
  sum(CASE WHEN rerate_counter = "1" THEN chrg_amt ELSE 0 END) as total_overage_successful_second_attempt_charge,
    CAST(non_purged_subscriber.bcc AS INT) AS bcc, 
    CAST(non_purged_subscriber.mm AS INT) AS mm, 
    CAST(non_purged_subscriber.yy AS INT) AS yy, 
    COALESCE(ATST, 'unknown ATST') AS ATST,
    non_purged_subscriber.month_skey
  FROM non_purged_subscriber
  LEFT JOIN rerate_success
    ON COALESCE(first_attempt_ban, second_attempt_ban) = ban
    AND COALESCE(first_attempt_bcc, second_attempt_bcc) = CAST(bcc AS INT)
    AND COALESCE(first_attempt_mm, second_attempt_mm) = CAST(mm AS INT)
    AND COALESCE(first_attempt_yy, second_attempt_yy) = CAST(yy AS INT)
    AND CAST(COALESCE(first_attempt_rerateVersion, second_attempt_rerateVersion) AS INT) = rerate_version
  LEFT JOIN latest_billed_atst_ban_bccmmyy_rerate_counter 
     ON non_purged_subscriber.ban = latest_billed_atst_ban_bccmmyy_rerate_counter.ban 
       AND non_purged_subscriber.bcc = latest_billed_atst_ban_bccmmyy_rerate_counter.bcc
       AND CAST(non_purged_subscriber.mm AS INT) = latest_billed_atst_ban_bccmmyy_rerate_counter.mm
       AND CAST(non_purged_subscriber.yy AS INT) = latest_billed_atst_ban_bccmmyy_rerate_counter.yy
 WHERE latest_billed_atst_ban_bccmmyy_rerate_counter.rerate_counter IN ("0", "1")
    AND COALESCE(first_attempt_ban, second_attempt_ban) IS NOT NULL AND COALESCE(first_attempt_bcc, second_attempt_bcc) IS NOT NULL AND COALESCE(first_attempt_mm, second_attempt_mm) IS NOT NULL AND 
    COALESCE(first_attempt_yy, second_attempt_yy) IS NOT NULL AND COALESCE(first_attempt_rerateVersion, second_attempt_rerateVersion) IS NOT NULL
GROUP BY non_purged_subscriber.month_skey, non_purged_subscriber.yy, non_purged_subscriber.mm, non_purged_subscriber.bcc, ATST
),

failed_attempt_ccrs AS (
  -- KPI 18, 19, 29, 30
SELECT
  SUM(total_count_of_failed_first_attempt_ccrs) AS total_count_of_failed_first_attempt_ccrs,
  SUM(total_count_of_failed_second_attempt_ccrs) AS total_count_of_failed_second_attempt_ccrs,
  SUM(total_volume_of_failed_first_attempt_ccrs)/1048576 AS total_volume_of_failed_first_attempt_ccrs,
  SUM(total_volume_of_failed_second_attempt_ccrs)/1048576 AS total_volume_of_failed_second_attempt_ccrs,
  bcc,
  mm,
  yy,
  ATST,
  month_skey
FROM (
SELECT 
  CASE WHEN billedRerateCounter = 0 THEN 1 ELSE 0 END AS total_count_of_failed_first_attempt_ccrs, 
  CASE WHEN billedRerateCounter = 1 THEN 1 ELSE 0 END AS total_count_of_failed_second_attempt_ccrs, 
    COALESCE(first_attempt_bcc, second_attempt_bcc) AS bcc,
    COALESCE(first_attempt_mm, second_attempt_mm) AS mm,
    COALESCE(first_attempt_yy, second_attempt_yy) AS yy,
    COALESCE(ATST, 'unknown ATST') AS ATST,
    CASE WHEN billedRerateCounter = 0 THEN bytesin + bytesout - unapplied_bytes ELSE 0 END AS total_volume_of_failed_first_attempt_ccrs,
    CASE WHEN billedRerateCounter = 1 THEN bytesin + bytesout - unapplied_bytes ELSE 0 END AS total_volume_of_failed_second_attempt_ccrs,
    COALESCE(first_attempt_month_skey, second_attempt_month_skey) AS month_skey
from rerate_success
LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp rejected
    ON COALESCE(first_attempt_ban, second_attempt_ban) = rejected.ban
      AND COALESCE(first_attempt_bcc, second_attempt_bcc) = CAST(rejected.cycle_code AS INT)
      AND COALESCE(first_attempt_mm, second_attempt_mm) = CAST(rejected.cycle_run_month AS INT)
      AND COALESCE(first_attempt_yy, second_attempt_yy) = CAST(rejected.cycle_run_year AS INT)
      AND CAST(COALESCE(first_attempt_rerateVersion, second_attempt_rerateVersion) AS INT) = rejected.rerate_version
LEFT JOIN latest_billed_atst_ban_bccmmyy_rerate_counter
    ON latest_billed_atst_ban_bccmmyy_rerate_counter.ban = COALESCE(first_attempt_ban, second_attempt_ban)
      AND CAST(latest_billed_atst_ban_bccmmyy_rerate_counter.bcc AS INT) = COALESCE(first_attempt_bcc, second_attempt_bcc)
      AND latest_billed_atst_ban_bccmmyy_rerate_counter.mm = COALESCE(first_attempt_mm, second_attempt_mm)
      AND latest_billed_atst_ban_bccmmyy_rerate_counter.yy = COALESCE(first_attempt_yy, second_attempt_yy)
      AND latest_billed_atst_ban_bccmmyy_rerate_counter.rerateVersion = CAST(COALESCE(first_attempt_rerateVersion, second_attempt_rerateVersion) AS INT)
WHERE latest_billed_atst_ban_bccmmyy_rerate_counter.rerate_counter IN ("0", "1")
  AND source IN ("BILLED_RERATE") AND ratingStatus IN ("SUCCESS", "PARTIALLY_RATED", "FAILURE")
  AND rejected.ban IS NOT NULL AND rejected.cycle_code IS NOT NULL AND rejected.cycle_run_month IS NOT NULL 
  AND rejected.cycle_run_year IS NOT NULL AND rejected.rerate_version IS NOT NULL)
GROUP BY ALL 
),

-- KPI 20, 31
billed_rerate_success AS (
  SELECT
  SUM(first_attempt_billed_rerate_success) AS first_attempt_billed_rerate_success,
  SUM(second_attempt_billed_rerate_success) AS second_attempt_billed_rerate_success,
  month_skey,
  ATST,
  bcc,
  mm,
  yy
FROM (
SELECT 
  CASE WHEN billedRerateCounter = 0 THEN 1 ELSE 0 END AS first_attempt_billed_rerate_success,
  CASE WHEN billedRerateCounter = 1 THEN 1 ELSE 0 END AS second_attempt_billed_rerate_success,
  COALESCE(first_attempt_month_skey, second_attempt_month_skey) AS month_skey,
  COALESCE(ATST, 'unknown ATST') AS ATST,
  COALESCE(first_attempt_bcc, second_attempt_bcc) AS bcc,
  COALESCE(first_attempt_mm, second_attempt_mm) AS mm,
  COALESCE(first_attempt_yy, second_attempt_yy) AS yy
FROM rerate_success
LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp reject
  ON COALESCE(first_attempt_bcc, second_attempt_bcc) = CAST(reject.cycle_code AS INT)
      AND COALESCE(first_attempt_mm, second_attempt_mm) = CAST(reject.cycle_run_month AS INT)
      AND COALESCE(first_attempt_yy, second_attempt_yy) = CAST(reject.cycle_run_year AS INT)
  LEFT JOIN latest_billed_atst_ban_bccmmyy_rerate_counter 
    ON COALESCE(first_attempt_ban, second_attempt_ban) = latest_billed_atst_ban_bccmmyy_rerate_counter.ban 
      AND COALESCE(first_attempt_bcc, second_attempt_bcc) = CAST(latest_billed_atst_ban_bccmmyy_rerate_counter.bcc AS INT)
      AND COALESCE(first_attempt_mm, second_attempt_mm) = CAST(latest_billed_atst_ban_bccmmyy_rerate_counter.mm AS INT)
      AND COALESCE(first_attempt_yy, second_attempt_yy) = CAST(latest_billed_atst_ban_bccmmyy_rerate_counter.yy AS INT)
  WHERE latest_billed_atst_ban_bccmmyy_rerate_counter.rerate_counter IN ("0", "1")
    AND reject.rerate_version IS NULL AND reject.cycle_code IS NULL 
    AND reject.cycle_run_month IS NULL AND reject.cycle_run_year IS NULL AND reject.ban IS NULL)
GROUP BY ALL),

-- KPI 21, 32
failed_billed_rate AS (
  SELECT
  SUM(first_attempt_billed_rerate_failure) AS first_attempt_billed_rerate_failure,
  SUM(second_attempt_billed_rerate_failure) AS second_attempt_billed_rerate_failure,
  month_skey,
  ATST,
  bcc,
  mm,
  yy
FROM (
  SELECT 
    CASE WHEN billedRerateCounter = 0 THEN 1 ELSE 0 END AS first_attempt_billed_rerate_failure,
    CASE WHEN billedRerateCounter = 1 THEN 1 ELSE 0 END AS second_attempt_billed_rerate_failure,
  COALESCE(first_attempt_month_skey, second_attempt_month_skey) AS month_skey,
  COALESCE(ATST, 'unknown ATST') AS ATST,
  COALESCE(first_attempt_bcc, second_attempt_bcc) AS bcc,
  COALESCE(first_attempt_mm, second_attempt_mm) AS mm,
  COALESCE(first_attempt_yy, second_attempt_yy) AS yy
  FROM rerate_success
  LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp rejected
    ON COALESCE(first_attempt_ban, second_attempt_ban) = rejected.ban
      AND COALESCE(first_attempt_bcc, second_attempt_bcc) = CAST(rejected.cycle_code AS INT)
      AND COALESCE(first_attempt_mm, second_attempt_mm) = CAST(rejected.cycle_run_month AS INT)
      AND COALESCE(first_attempt_yy, second_attempt_yy) = CAST(rejected.cycle_run_year AS INT)
      AND CAST(COALESCE(first_attempt_rerateVersion, second_attempt_rerateVersion) AS INT) = rejected.rerate_version
  LEFT JOIN latest_billed_atst_ban_bccmmyy_rerate_counter 
    ON COALESCE(first_attempt_ban, second_attempt_ban) = latest_billed_atst_ban_bccmmyy_rerate_counter.ban 
      AND COALESCE(first_attempt_bcc, second_attempt_bcc)= CAST(latest_billed_atst_ban_bccmmyy_rerate_counter.bcc AS INT)
      AND COALESCE(first_attempt_mm, second_attempt_mm) = latest_billed_atst_ban_bccmmyy_rerate_counter.mm
      AND COALESCE(first_attempt_yy, second_attempt_yy) = latest_billed_atst_ban_bccmmyy_rerate_counter.yy
  WHERE latest_billed_atst_ban_bccmmyy_rerate_counter.rerate_counter IN ("0", "1") AND rejected.ban IS NOT NULL 
    AND rejected.cycle_code IS NOT NULL AND rejected.cycle_run_month IS NOT NULL AND rejected.cycle_run_year IS NOT NULL 
    AND rejected.rerate_version IS NOT NULL)
  GROUP BY ALL 
),

-- Combined KPIs broken down by ATST, bcc_mm_yy and compute KPI 33
KPIs_broken_down_by_atst_bccmmyy AS (
  SELECT
    number_of_first_attempt_requests, -- KPI 11
    total_count_of_successful_first_attempt_daily_records, -- KPI 15
    total_volume_of_successful_first_attempt_daily_records, --KPI 16
    total_overage_successful_first_attempt_charge, --KPI 17
    total_count_of_failed_first_attempt_ccrs, -- KPI 18
    total_volume_of_failed_first_attempt_ccrs, -- KPI 19
    first_attempt_billed_rerate_success, -- KPI 20
    first_attempt_billed_rerate_failure, -- KPI 21
    number_of_second_attempt_requests, -- KPI 22
    total_count_of_successful_second_attempt_daily_records, -- KPI 26
    total_volume_of_successful_second_attempt_daily_records, --KPI 27
    total_overage_successful_second_attempt_charge, --KPI 28
    total_count_of_failed_second_attempt_ccrs, -- KPI 29
    total_volume_of_failed_second_attempt_ccrs, -- KPI 30
    second_attempt_billed_rerate_success, -- KPI 31
    second_attempt_billed_rerate_failure, -- KPI 32
    -- Adding CASE WHEN because if number_of_first_attempt_requests = 0 then x / 0 will give error.
    (number_of_first_attempt_requests - number_of_second_attempt_requests) / (CASE WHEN number_of_first_attempt_requests = 0 THEN 1 ELSE number_of_first_attempt_requests END) AS round_one_success_rate, -- KPI 33
    bcc,
    mm,
    yy,
    ATST,
    month_skey
  FROM
    attempt_requests
  FULL OUTER JOIN
    successful_daily_kpis
  USING
    (month_skey, yy, mm, bcc, ATST)
  FULL OUTER JOIN
    charged_successful
  USING
    (month_skey, yy, mm, bcc, ATST)
  FULL OUTER JOIN
    failed_attempt_ccrs
  USING
    (month_skey, yy, mm, bcc, ATST)
  FULL OUTER JOIN
    billed_rerate_success
  USING
    (month_skey, yy, mm, bcc, ATST)
  FULL OUTER JOIN
    failed_billed_rate
  USING
    (month_skey, yy, mm, bcc, ATST)
  ),

-- Combined KPIs broken down by ATST, bcc_mm_yy, reason
KPIs_broken_down_by_atst_bccmmyy_reason AS (
  SELECT 
    first_attempt_request_reason_counts, -- KPI 12 - 14
    second_attempt_request_reason_counts, -- KPI 23 - 25
    reason,
    ATST,
    bcc,
    mm,
    yy,
    month_skey
  FROM request_reasons
)

-- Final table joining KPIs on the ATST BCCMMYY level with their corresponding reasons
  SELECT    
    KPIs_broken_down_by_atst_bccmmyy.month_skey,
    CAST(KPIs_broken_down_by_atst_bccmmyy.bcc AS STRING) AS bcc,
    CAST(KPIs_broken_down_by_atst_bccmmyy.mm AS STRING) AS mm,
    CAST(KPIs_broken_down_by_atst_bccmmyy.yy AS STRING) AS yy,
    KPIs_broken_down_by_atst_bccmmyy.ATST, 
    COALESCE(round_one_success_rate, 0) AS round_one_success_rate, -- KPI 33
    STRUCT(
      COALESCE(number_of_first_attempt_requests, 0) AS number_of_requests, -- KPI 11
      COALESCE(total_count_of_successful_first_attempt_daily_records, 0) AS total_count_of_successful_daily_records, -- KPI 15
      COALESCE(total_volume_of_successful_first_attempt_daily_records, 0) AS total_volume_of_successful_daily_records, --KPI 16
      COALESCE(total_overage_successful_first_attempt_charge, 0) AS total_overage_successful_charge, --KPI 17
      COALESCE(total_count_of_failed_first_attempt_ccrs, 0) AS total_count_of_failed_ccrs, -- KPI 18
      COALESCE(total_volume_of_failed_first_attempt_ccrs, 0) AS total_volume_of_failed_ccrs, -- KPI 19
      COALESCE(first_attempt_billed_rerate_success, 0) AS billed_rerate_success, -- KPI 20
      COALESCE(first_attempt_billed_rerate_failure, 0) AS billed_rerate_failure, -- KPI 21
      ARRAY_AGG(STRUCT(
          reason, 
          first_attempt_request_reason_counts AS request_reason_counts -- KPI 12 - 14
        )
      ) AS reasons
    ) AS first_attempt,
    STRUCT(
      COALESCE(number_of_second_attempt_requests, 0) AS number_of_requests, -- KPI 22
      COALESCE(total_count_of_successful_second_attempt_daily_records, 0) AS total_count_of_successful_daily_records, -- KPI 26
      COALESCE(total_volume_of_successful_second_attempt_daily_records, 0) AS total_volume_of_successful_daily_records, --KPI 27
      COALESCE(total_overage_successful_second_attempt_charge, 0) AS total_overage_successful_charge, --KPI 28
      COALESCE(total_count_of_failed_second_attempt_ccrs, 0) AS total_count_of_failed_ccrs, -- KPI 29
      COALESCE(total_volume_of_failed_second_attempt_ccrs, 0) AS total_volume_of_failed_ccrs, -- KPI 30
      COALESCE(second_attempt_billed_rerate_success, 0) AS billed_rerate_success, -- KPI 31
      COALESCE(second_attempt_billed_rerate_failure, 0) AS billed_rerate_failure, -- KPI 32
      ARRAY_AGG(STRUCT(
          reason,
          second_attempt_request_reason_counts AS request_reason_counts -- KPI 23 - 25
        )
      ) AS reasons
    ) AS second_attempt
    from KPIs_broken_down_by_atst_bccmmyy
    LEFT JOIN KPIs_broken_down_by_atst_bccmmyy_reason
    ON KPIs_broken_down_by_atst_bccmmyy.bcc = KPIs_broken_down_by_atst_bccmmyy_reason.bcc
    AND KPIs_broken_down_by_atst_bccmmyy.mm = KPIs_broken_down_by_atst_bccmmyy_reason.mm
    AND KPIs_broken_down_by_atst_bccmmyy.yy = KPIs_broken_down_by_atst_bccmmyy_reason.yy
    AND KPIs_broken_down_by_atst_bccmmyy.ATST = KPIs_broken_down_by_atst_bccmmyy_reason.ATST
    AND KPIs_broken_down_by_atst_bccmmyy.month_skey = KPIs_broken_down_by_atst_bccmmyy_reason.month_skey
    GROUP BY     
      KPIs_broken_down_by_atst_bccmmyy.month_skey,
      KPIs_broken_down_by_atst_bccmmyy.bcc,
      KPIs_broken_down_by_atst_bccmmyy.mm,
      KPIs_broken_down_by_atst_bccmmyy.yy,
      KPIs_broken_down_by_atst_bccmmyy.ATST,
      round_one_success_rate,
      number_of_first_attempt_requests,
      total_count_of_successful_first_attempt_daily_records,
      total_volume_of_successful_first_attempt_daily_records,
      total_overage_successful_first_attempt_charge,
      total_count_of_failed_first_attempt_ccrs,
      total_volume_of_failed_first_attempt_ccrs,
      number_of_second_attempt_requests, 
      total_count_of_successful_second_attempt_daily_records, 
      total_volume_of_successful_second_attempt_daily_records,
      total_overage_successful_second_attempt_charge,
      total_count_of_failed_second_attempt_ccrs,
      total_volume_of_failed_second_attempt_ccrs,
      first_attempt_billed_rerate_success, 
      second_attempt_billed_rerate_success,
      first_attempt_billed_rerate_failure,
      second_attempt_billed_rerate_failure
