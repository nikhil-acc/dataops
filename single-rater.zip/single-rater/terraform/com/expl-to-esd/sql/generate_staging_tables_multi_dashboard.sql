-- Initial clean up of temp tables
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi_xcorrelationId;
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi;

-- Create temp tables
-- latest_ATST_by_using_ban_bccmmyy
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy AS (
    SELECT * EXCEPT(ordered_ratingStartTime_row_num)
    FROM (
        SELECT
        bcc,
        EXTRACT(MONTH FROM month_skey) AS mm,
        EXTRACT(YEAR FROM month_skey) AS yy,
        ratingStartTime,
        COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST,
        ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM month_skey),
            EXTRACT(MONTH FROM month_skey),
            bcc, ban 
            ORDER BY ratingStartTime DESC) as ordered_ratingStartTime_row_num,
        ban,
        month_skey,
        source,
        ratingStatus
        FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
        WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    )
    WHERE ordered_ratingStartTime_row_num = 1
);

-- latest_ATST_by_using_imsi_xcorrelationId
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi_xcorrelationId
PARTITION BY
  DATE_TRUNC(month_skey, MONTH)
AS (
    SELECT * FROM (
        SELECT
        bcc,
        EXTRACT(MONTH FROM month_skey) AS mm,
        EXTRACT(YEAR FROM month_skey) AS yy,
        COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST,
        month_skey,
        imsi, 
        xCorrelationId,
        ROW_NUMBER() OVER (PARTITION BY imsi, xCorrelationId ORDER BY ratingStartTime DESC) AS ordered_ratingStartTime_row_num,
        ratingStartTime,
        reporting_date
        FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
    )
    WHERE ordered_ratingStartTime_row_num = 1
);

-- latest_ATST_by_using_imsi
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi
AS (
    SELECT imsi,
      ATST
    FROM (
      SELECT imsi,
        COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST,
        ROW_NUMBER() OVER(PARTITION BY imsi ORDER BY ratingStartTime DESC) as ordered_ratingStartTime_row_num
      FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
      WHERE reporting_date BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")
    ) ordered_ratingStartTime
    WHERE ordered_ratingStartTime.ordered_ratingStartTime_row_num = 1
);
