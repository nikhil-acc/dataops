-- Initial clean up of temp tables
DROP TABLE IF EXISTS {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp;

-- Create temp tables
-- wnc_arc_que_ratedusages
CREATE TABLE {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
PARTITION BY
  DATE_TRUNC(month_skey, MONTH)
AS (
  SELECT * 
  except(record_row_number, month_skey_est, reporting_date_est), 
  -- rename month_skey and reporting_date
  month_skey_est AS month_skey,
  reporting_date_est AS reporting_date
  FROM (
    SELECT 
      usageDetails.imsi,
      ratingStartTime,
      getSubscriberBalancesResponse.account.accountType,
      getSubscriberBalancesResponse.account.accountSubType,
      RatingStatus,
      usageDetails.bytesIn,
      usageDetails.bytesOut,
      ocrtOutput.usageBalanceImpacts,
      ocrtOutput.usageNotApplied,
      source,
      usageDetails.subscriberId,
      xCorrelationId,
      LTRIM(getSubscriberBalancesResponse.account.bcc, '0') AS bcc,
      getSubscriberBalancesResponse.account.nextBillCycleDate,
      rerateVersion,
      usageDetails.ban,
      EXTRACT(DATE FROM TIMESTAMP_MILLIS(usageDetails.startTime) AT TIME ZONE "America/Toronto") AS reporting_date_est,
      DATE(
        EXTRACT(YEAR FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"),
        EXTRACT(MONTH FROM TIMESTAMP_SUB(TIMESTAMP_MILLIS(getSubscriberBalancesResponse.account.nextBillCycleDate), INTERVAL 1 DAY) AT TIME ZONE "America/Toronto"), 
        1
      ) AS month_skey_est,
    -- rank
    ROW_NUMBER() 
      OVER (PARTITION BY xCorrelationId,  usageDetails.imsi, source, rerateVersion
      ORDER BY ingested_on DESC) AS record_row_number,
    FROM `{{ project_id }}.{{ sr_expl_dataset }}.wnc_arc_que_ratedusages`
    -- partition
    WHERE month_skey IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH), 
      DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
      DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)))
  WHERE record_row_number = 1
  AND month_skey_est
    IN (DATE_TRUNC(DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH), 
    DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), 
    DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH)) -- 3 EST month partition
);