DELETE `{{ project_id }}.{{ sr_esd_dataset }}.freezone` 
WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto");

INSERT `{{ project_id }}.{{ sr_esd_dataset }}.freezone`  (
  dt_skey,
  ATST,
  rating_group,
  APN,
  cgf_freezone_ccr_count,
  cgf_freezone_byte_count
)

SELECT 
  free_filter.dt_skey,
  COALESCE(max_ratingStartTime.ATST, "unknown ATST") AS ATST, 
  free_filter.ratingGroup,
  free_filter.APN,
  COUNT(*) as cgf_freezone_ccr_count,
  SUM(free_filter.bytesIn + free_filter.bytesOut)/1048576 as cgf_freezone_byte_count
FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_free_filter_temp as free_filter
LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi max_ratingStartTime
ON free_filter.IMSI = max_ratingStartTime.imsi
WHERE free_filter.roamingIndicator IN ("H", "C")
GROUP BY dt_skey, ATST, free_filter.ratingGroup, APN