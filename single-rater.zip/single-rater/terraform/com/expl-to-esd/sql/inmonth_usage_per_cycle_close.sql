DELETE `{{ project_id }}.{{ sr_esd_dataset }}.inmonth_usage_per_cycle_close` 
WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH));

INSERT `{{ project_id }}.{{ sr_esd_dataset }}.inmonth_usage_per_cycle_close`  (
  month_skey,
  bcc,
  mm,
  yy,
  ATST,
  usage_ingest_success_record_count,
  usage_ingest_success_byte_count,
  usage_ingest_failed_record_count,
  usage_ingest_failed_byte_count,
  uro_success_record_count,
  uro_success_byte_count,
  uro_partially_applied_record_count,
  uro_partially_applied_byte_count,
  uro_unapplied_record_count,
  uro_unapplied_byte_count,
  uro_failed_record_count,
  uro_failed_byte_count,
  uro_not_rated_record_count,
  uro_not_rated_byte_count,
  rerate_success_record_count,
  rerate_success_byte_count,
  rerate_partially_applied_record_count,
  rerate_partially_applied_byte_count,
  rerate_unapplied_record_count,
  rerate_unapplied_byte_count,
  rerate_failed_record_count,
  rerate_failed_byte_count,
  rerate_not_rated_record_count,
  rerate_not_rated_byte_count,
  odf_rated_ccr_received_record_count,
  odf_rated_ccr_received_byte_count,
  odf_rated_ccr_skipped_record_count,
  odf_rated_ccr_skipped_byte_count,
  odf_rated_ccr_failed_record_count,
  odf_rated_ccr_failed_byte_count,
  odf_rated_ccr_late_record_count,
  odf_rated_ccr_late_byte_count,
  odf_daily_aggregated_record_count,
  odf_daily_aggregated_byte_count
)

-- Used to find the highest rerateVersion for each subscriberId in each bcc_mm_yy
WITH max_rerate_version AS (

    -- return only the records that have the highest rerateVersions for each subscriberId in each bcc_mm_yy
    SELECT subscriberId,
    bcc,
    mm,
    yy,
    rerateVersion
    FROM (    
      SELECT 
        subscriberId,
        bcc,
        EXTRACT(MONTH FROM month_skey) AS mm,
        EXTRACT(YEAR FROM month_skey) AS yy,
        rerateVersion,
        ROW_NUMBER() OVER (PARTITION BY subscriberId, EXTRACT(YEAR FROM month_skey), EXTRACT(MONTH FROM month_skey), bcc ORDER BY rerateVersion DESC) as ordered_rerate_row_num
      FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
      WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
        AND source IN ('RATE', 'RERATE')
    ) ordered_rerate 
    WHERE ordered_rerate.ordered_rerate_row_num = 1

  ),

-- Dashboard 2 KPI 1: Usage Ingest Success
  usage_ingest_success AS (

    SELECT 
      COALESCE(usage_ingest_max_ratingStartTime.month_skey, DATE(CONCAT(extract(YEAR FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto"), 
        "-", extract(MONTH FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto"), "-01"))) AS month_skey, -- set as current month & year if month_skey does not exist
      COALESCE(ATST, "unknown ATST") AS ATST,
      COALESCE(usage_ingest_max_ratingStartTime.bcc, "unknown BCC") AS bcc,
      COALESCE(CAST(usage_ingest_max_ratingStartTime.mm AS STRING), CAST(extract(MONTH FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto") AS STRING)) AS mm,
      COALESCE(CAST(usage_ingest_max_ratingStartTime.yy AS STRING), CAST(extract(YEAR FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto") AS STRING)) AS yy,
      COUNT(*) as usage_ingest_success_record_count,
      SUM(ccr.bytesIn + ccr.bytesOut)/1048576 as usage_ingest_success_byte_count
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_guided_ccr_temp as ccr
    LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi_xcorrelationId usage_ingest_max_ratingStartTime
    ON ccr.IMSI = usage_ingest_max_ratingStartTime.imsi AND ccr.xCorrelationId=usage_ingest_max_ratingStartTime.xCorrelationId
    WHERE ccr.roamingIndicator IN ("H", "C")
    GROUP BY month_skey, yy, mm, bcc, ATST
    HAVING month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))

  ),

-- Dashboard 2 KPI 2: Usage Ingest Failure
  usage_ingest_failure AS (

    SELECT 
      COALESCE(usage_ingest_max_ratingStartTime.month_skey, DATE(CONCAT(extract(YEAR FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto"), 
        "-", extract(MONTH FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto"), "-01"))) AS month_skey, -- set as current month & year if month_skey does not exist
      COALESCE(ATST, "unknown ATST") AS ATST,
      COALESCE(usage_ingest_max_ratingStartTime.bcc, "unknown BCC") AS bcc,
      COALESCE(CAST(usage_ingest_max_ratingStartTime.mm AS STRING), CAST(extract(MONTH FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto") AS STRING)) AS mm,
      COALESCE(CAST(usage_ingest_max_ratingStartTime.yy AS STRING), CAST(extract(YEAR FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto") AS STRING)) AS yy,
      COUNT(*) as usage_ingest_failed_record_count,
      SUM(usageIngestError.bytesIn + usageIngestError.bytesOut)/1048576 as usage_ingest_failed_byte_count
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_bell_usage_ingest_error_temp as usageIngestError
    LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi_xcorrelationId usage_ingest_max_ratingStartTime
    ON usageIngestError.imsi = usage_ingest_max_ratingStartTime.imsi AND usageIngestError.xCorrelationId=usage_ingest_max_ratingStartTime.xCorrelationId
    WHERE usageIngestError.roamingIndicator IN ("H", "C") AND usage_ingest_max_ratingStartTime.imsi IS NULL 
      AND usage_ingest_max_ratingStartTime.xCorrelationId IS NULL
    GROUP BY month_skey, yy, mm, bcc, ATST
    HAVING month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))

  ),
 -- KPI 3, 4, 5, 6, 7
    uro_kpis AS (
    SELECT 
      SUM(uro_success_record_count) AS uro_success_record_count, -- KPI 3
      SUM(uro_success_byte_count)/1048576 AS uro_success_byte_count, -- KPI 3
      SUM(uro_partially_applied_record_count) AS uro_partially_applied_record_count, -- KPI 4
      SUM(uro_partially_applied_byte_count)/1048576 AS uro_partially_applied_byte_count, -- KPI 4
      SUM(uro_unapplied_record_count) AS uro_unapplied_record_count, -- KPI 5
      SUM(uro_unapplied_byte_count)/1048576 AS uro_unapplied_byte_count, -- KPI 5
      SUM(uro_failed_record_count) AS uro_failed_record_count, -- KPI 6
      SUM(uro_failed_byte_count)/1048576 AS uro_failed_byte_count, -- KPI 6
      SUM(uro_not_rated_record_count) AS uro_not_rated_record_count, -- KPI 7
      SUM(uro_not_rated_byte_count)/1048576 AS uro_not_rated_byte_count, -- KPI 7
      month_skey, 
      CAST(yy AS STRING) AS yy, 
      CAST(mm AS STRING) AS mm, 
      CAST(bcc AS STRING) AS bcc,  
      ATST
      FROM
      (
        SELECT 
        CASE WHEN RatingStatus = 'SUCCESS' THEN 1 ELSE 0 END as uro_success_record_count,-- KPI 3
        CASE WHEN RatingStatus = 'SUCCESS' THEN bytesIn + bytesOut ELSE 0 END AS uro_success_byte_count, --KPI 3
        CASE WHEN ARRAY_LENGTH(usageBalanceImpacts) > 0 AND RatingStatus = 'PARTIALLY_RATED' THEN 1 ELSE 0 END AS uro_partially_applied_record_count, -- KPI 4
        CASE WHEN ARRAY_LENGTH(usageBalanceImpacts) > 0 AND RatingStatus = 'PARTIALLY_RATED' 
          THEN bytesIn + bytesOut - (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) as una) 
          ELSE 0 END AS uro_partially_applied_byte_count, -- KPI 4
        CASE WHEN (ARRAY_LENGTH(usageBalanceImpacts) = 0 OR usageBalanceImpacts IS NULL) AND RatingStatus = 'PARTIALLY_RATED' 
          THEN 1 ELSE 0 END AS uro_unapplied_record_count, -- KPI 5
        CASE WHEN (ARRAY_LENGTH(usageBalanceImpacts) = 0 OR usageBalanceImpacts IS NULL) AND RatingStatus = 'PARTIALLY_RATED' 
          THEN (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) as una) ELSE 0 END AS uro_unapplied_byte_count, -- KPI 5
        CASE WHEN RatingStatus = 'FAILURE' THEN 1 ELSE 0 END AS uro_failed_record_count, --KPI 6
        CASE WHEN RatingStatus = 'FAILURE' THEN bytesIn + bytesOut ELSE 0 END AS uro_failed_byte_count, --KPI 6
        CASE WHEN RatingStatus = 'NOT_RATED' THEN 1 ELSE 0 END AS uro_not_rated_record_count, -- KPI 7
        CASE WHEN RatingStatus = 'NOT_RATED' THEN bytesIn + bytesOut ELSE 0 END AS uro_not_rated_byte_count, -- KPI 7
        bcc,
        EXTRACT(MONTH FROM month_skey) AS mm,
        EXTRACT(YEAR FROM month_skey) AS yy,
        COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST,
        month_skey,
        source
      FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
      WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
        AND source = "RATE"
      )
      GROUP BY month_skey, yy, mm, bcc, ATST
  ),
-- KPI 8, 9, 10, 11, 12
  rerate_kpis AS (
    SELECT
    SUM(rerate_success_record_count) AS rerate_success_record_count, -- KPI 8
      SUM(rerate_success_byte_count)/1048576 AS rerate_success_byte_count, -- KPI 8
      SUM(rerate_partially_applied_record_count) AS rerate_partially_applied_record_count, -- KPI 9
      SUM(rerate_partially_applied_byte_count)/1048576 AS rerate_partially_applied_byte_count, -- KPI 9
      SUM(rerate_unapplied_record_count) AS rerate_unapplied_record_count, -- KPI 10
      SUM(rerate_unapplied_byte_count)/1048576 AS rerate_unapplied_byte_count, -- KPI 10
      SUM(rerate_failed_record_count) AS rerate_failed_record_count, -- KPI 11
      SUM(rerate_failed_byte_count)/1048576 AS rerate_failed_byte_count, -- KPI 11
      SUM(rerate_not_rated_record_count) AS rerate_not_rated_record_count, -- KPI 12
      SUM(rerate_not_rated_byte_count)/1048576 AS rerate_not_rated_byte_count, -- KPI 12
      month_skey, 
      CAST(yy AS STRING) AS yy, 
      CAST(mm AS STRING) AS mm, 
      CAST(bcc AS STRING) AS bcc,  
      ATST
      FROM (
        SELECT
        CASE WHEN RatingStatus = 'SUCCESS' THEN 1 ELSE 0 END AS rerate_success_record_count, -- KPI 8
        CASE WHEN RatingStatus = 'SUCCESS' THEN bytesIn + bytesOut 
          ELSE 0 END rerate_success_byte_count,-- KPI 8
        CASE WHEN ARRAY_LENGTH(usageBalanceImpacts) > 0 AND RatingStatus = 'PARTIALLY_RATED' THEN 1 ELSE 0 END AS rerate_partially_applied_record_count, -- KPI 9
        CASE WHEN ARRAY_LENGTH(usageBalanceImpacts) > 0 AND RatingStatus = 'PARTIALLY_RATED'
          THEN bytesIn + bytesOut - (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) as una) 
          ELSE 0 END AS rerate_partially_applied_byte_count, -- KPI 9
        CASE WHEN (ARRAY_LENGTH(usageBalanceImpacts) = 0 OR usageBalanceImpacts IS NULL) AND RatingStatus = 'PARTIALLY_RATED'
          THEN 1 ELSE 0 END AS rerate_unapplied_record_count, -- KPI 10
        CASE WHEN (ARRAY_LENGTH(usageBalanceImpacts) = 0 OR usageBalanceImpacts IS NULL) AND RatingStatus = 'PARTIALLY_RATED'
          THEN (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) as una) ELSE 0 END AS rerate_unapplied_byte_count,--KPI 10
        CASE WHEN RatingStatus = 'FAILURE' THEN 1 ELSE 0 END AS rerate_failed_record_count, --KPI 11
        CASE WHEN RatingStatus = 'FAILURE' THEN bytesIn + bytesOut ELSE 0 END AS rerate_failed_byte_count, --KPI 11
        CASE WHEN RatingStatus = 'NOT_RATED' THEN 1 ELSE 0 END AS rerate_not_rated_record_count, --KPI 12
        CASE WHEN RatingStatus = 'NOT_RATED' THEN bytesIn + bytesOut ELSE 0 END AS rerate_not_rated_byte_count, --KPI 12
        wnc_arc_que_ratedusages_temp.bcc,
        EXTRACT(MONTH FROM month_skey) AS mm,
        EXTRACT(YEAR FROM month_skey) AS yy,
        COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST,
        month_skey,
        source
      FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp AS wnc_arc_que_ratedusages_temp
      INNER JOIN max_rerate_version
      ON wnc_arc_que_ratedusages_temp.bcc = max_rerate_version.bcc 
        AND EXTRACT(MONTH FROM month_skey) = max_rerate_version.mm 
        AND EXTRACT(YEAR FROM month_skey) = max_rerate_version.yy 
        AND wnc_arc_que_ratedusages_temp.subscriberId = max_rerate_version.subscriberId 
        AND wnc_arc_que_ratedusages_temp.rerateVersion = max_rerate_version.rerateVersion
      WHERE wnc_arc_que_ratedusages_temp.month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
        AND wnc_arc_que_ratedusages_temp.source = 'RERATE'
      )
      GROUP BY month_skey, yy, mm, bcc, ATST
  ),

-- Dashboard 2 KPI 13: ODF Rated CCR Received (per last CCR version)
  odf_rated_ccr_received AS (

    SELECT 
      ccrs_deduplicated.bcc,
      CAST(EXTRACT(MONTH FROM ccrs_deduplicated.month_skey) AS STRING) AS mm,
      CAST(EXTRACT(YEAR FROM ccrs_deduplicated.month_skey) AS STRING) AS yy,
      ccrs_deduplicated.month_skey,
      COUNT(*) as odf_rated_ccr_received_record_count,
      SUM(CAST(ccrs_deduplicated.at_call_dur_round_min AS INT64))/1048576 as odf_rated_ccr_received_byte_count,
      COALESCE(CONCAT(ccrs_deduplicated.accountType, ccrs_deduplicated.accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_rated_ccrs_deduplicated_temp as ccrs_deduplicated
    INNER JOIN max_rerate_version
    ON ccrs_deduplicated.bcc = max_rerate_version.bcc
      AND EXTRACT(MONTH FROM ccrs_deduplicated.month_skey) = max_rerate_version.mm
      AND EXTRACT(YEAR FROM ccrs_deduplicated.month_skey) = max_rerate_version.yy 
      AND ccrs_deduplicated.subscriberId = max_rerate_version.subscriberId 
      AND ccrs_deduplicated.rerateVersion = max_rerate_version.rerateVersion
    WHERE ccrs_deduplicated.month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    GROUP BY month_skey, yy, mm, bcc, ATST

  ),

-- Dashboard 2 KPI 14: ODF Rated CCR Skipped (per last CCR Version)
  odf_rated_ccr_skipped AS (

    SELECT 
      skipped_records.bcc,
      CAST(EXTRACT(MONTH FROM skipped_records.month_skey) AS STRING) AS mm,
      CAST(EXTRACT(YEAR FROM skipped_records.month_skey) AS STRING) AS yy,
      skipped_records.month_skey,
      COUNT(*) as odf_rated_ccr_skipped_record_count,
      SUM(skipped_records.bytesIn + skipped_records.bytesOut)/1048576 as odf_rated_ccr_skipped_byte_count,
      COALESCE(CONCAT(skipped_records.accountType, skipped_records.accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_skipped_records_temp as skipped_records
    INNER JOIN max_rerate_version
    ON skipped_records.bcc = max_rerate_version.bcc 
      AND EXTRACT(MONTH FROM skipped_records.month_skey) = max_rerate_version.mm
      AND EXTRACT(YEAR FROM skipped_records.month_skey) = max_rerate_version.yy
      AND skipped_records.subscriberId = max_rerate_version.subscriberId AND skipped_records.rerateVersion = max_rerate_version.rerateVersion  
    WHERE skipped_records.month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    GROUP BY month_skey, yy, mm, bcc, ATST

  ),

-- Dashboard 2 KPI 15: ODF Rated CCR Failed (per last CCR version)
  odf_rated_ccr_failed AS (

    SELECT 
      reject_records.bcc,
      CAST(EXTRACT(MONTH FROM reject_records.month_skey) AS STRING) AS mm,
      CAST(EXTRACT(YEAR FROM reject_records.month_skey) AS STRING) AS yy,
      reject_records.month_skey,
      COUNT(*) as odf_rated_ccr_failed_record_count,
      SUM(reject_records.bytesIn + reject_records.bytesOut)/1048576 as odf_rated_ccr_failed_byte_count,
      COALESCE(CONCAT(reject_records.accountType, reject_records.accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_reject_records_temp as reject_records
    INNER JOIN max_rerate_version
    ON reject_records.bcc = max_rerate_version.bcc
      AND EXTRACT(MONTH FROM reject_records.month_skey) = max_rerate_version.mm
      AND EXTRACT(YEAR FROM reject_records.month_skey) = max_rerate_version.yy 
      AND reject_records.subscriberId = max_rerate_version.subscriberId  
      AND reject_records.rerateVersion = max_rerate_version.rerateVersion
    WHERE reject_records.month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    GROUP BY month_skey, yy, mm, bcc, ATST

  ),

-- Dashboard 2 KPI 16: ODF Rated CCR Late (per last CCR Version)
  odf_rated_ccr_late AS (

    SELECT 
      late_usage_records.bcc,
      CAST(EXTRACT(MONTH FROM late_usage_records.month_skey) AS STRING) AS mm,
      CAST(EXTRACT(YEAR FROM late_usage_records.month_skey) AS STRING) AS yy,
      late_usage_records.month_skey,
      COUNT(*) as odf_rated_ccr_late_record_count,
      SUM(late_usage_records.bytesIn + late_usage_records.bytesOut)/1048576 as odf_rated_ccr_late_byte_count,
      COALESCE(CONCAT(late_usage_records.accountType, late_usage_records.accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_late_usage_records_temp as late_usage_records
    INNER JOIN max_rerate_version
    ON late_usage_records.bcc = max_rerate_version.bcc
      AND EXTRACT(MONTH FROM late_usage_records.month_skey) = max_rerate_version.mm 
      AND EXTRACT(YEAR FROM late_usage_records.month_skey) = max_rerate_version.yy 
      AND late_usage_records.subscriberId = max_rerate_version.subscriberId AND late_usage_records.rerateVersion = max_rerate_version.rerateVersion
    WHERE late_usage_records.month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    GROUP BY month_skey, yy, mm, bcc, ATST

  ),

-- Dashboard 2 KPI 17: ODF Daily Aggregated Record
  odf_daily_aggregated AS (

    SELECT 
      partial_daily_summary.cycle_code AS bcc, 
      partial_daily_summary.cycle_run_month AS mm, 
      partial_daily_summary.cycle_run_year AS yy,
      partial_daily_summary.month_skey,
      COUNT(*) as odf_daily_aggregated_record_count,
      SUM(partial_daily_summary.at_call_dur_round_min) as odf_daily_aggregated_byte_count,
      COALESCE(odf_max_ratingStartTime.ATST, 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_partial_daily_summary_temp as partial_daily_summary
    LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy odf_max_ratingStartTime
    ON partial_daily_summary.cycle_code = odf_max_ratingStartTime.bcc 
      AND CAST(partial_daily_summary.cycle_run_month as int) = odf_max_ratingStartTime.mm 
      AND cast(partial_daily_summary.cycle_run_year as int) = odf_max_ratingStartTime.yy 
      AND partial_daily_summary.ban = odf_max_ratingStartTime.ban
    GROUP BY month_skey, yy, mm, bcc, ATST

  )


SELECT 
  month_skey,
  bcc,
  mm,
  yy,
  ATST,
  COALESCE(usage_ingest_success_record_count, 0) AS usage_ingest_success_record_count,
  COALESCE(usage_ingest_success_byte_count, 0) AS usage_ingest_success_byte_count,
  COALESCE(usage_ingest_failed_record_count, 0) AS usage_ingest_failed_record_count,
  COALESCE(usage_ingest_failed_byte_count, 0) AS usage_ingest_failed_byte_count,
  COALESCE(uro_success_record_count, 0) AS uro_success_record_count,
  COALESCE(uro_success_byte_count, 0) AS uro_success_byte_count,
  COALESCE(uro_partially_applied_record_count, 0) AS uro_partially_applied_record_count,
  COALESCE(uro_partially_applied_byte_count, 0) AS uro_partially_applied_byte_count,
  COALESCE(uro_unapplied_record_count, 0) AS uro_unapplied_record_count,
  COALESCE(uro_unapplied_byte_count, 0) AS uro_unapplied_byte_count,
  COALESCE(uro_failed_record_count, 0) AS uro_failed_record_count,
  COALESCE(uro_failed_byte_count, 0) AS uro_failed_byte_count,
  COALESCE(uro_not_rated_record_count, 0) AS uro_not_rated_record_count,
  COALESCE(uro_not_rated_byte_count, 0) AS uro_not_rated_byte_count,
  COALESCE(rerate_success_record_count, 0) AS rerate_success_record_count,
  COALESCE(rerate_success_byte_count, 0) AS rerate_success_byte_count,
  COALESCE(rerate_partially_applied_record_count, 0) AS rerate_partially_applied_record_count,
  COALESCE(rerate_partially_applied_byte_count, 0) AS rerate_partially_applied_byte_count,
  COALESCE(rerate_unapplied_record_count, 0) AS rerate_unapplied_record_count,
  COALESCE(rerate_unapplied_byte_count, 0) AS rerate_unapplied_byte_count,
  COALESCE(rerate_failed_record_count, 0) AS rerate_failed_record_count,
  COALESCE(rerate_failed_byte_count, 0) AS rerate_failed_byte_count,
  COALESCE(rerate_not_rated_record_count, 0) AS rerate_not_rated_record_count,
  COALESCE(rerate_not_rated_byte_count, 0) AS rerate_not_rated_byte_count,
  COALESCE(odf_rated_ccr_received_record_count, 0) AS odf_rated_ccr_received_record_count,
  COALESCE(odf_rated_ccr_received_byte_count, 0) AS odf_rated_ccr_received_byte_count,
  COALESCE(odf_rated_ccr_skipped_record_count, 0) AS odf_rated_ccr_skipped_record_count,
  COALESCE(odf_rated_ccr_skipped_byte_count, 0) AS odf_rated_ccr_skipped_byte_count,
  COALESCE(odf_rated_ccr_failed_record_count, 0) AS odf_rated_ccr_failed_record_count,
  COALESCE(odf_rated_ccr_failed_byte_count, 0) AS odf_rated_ccr_failed_byte_count,
  COALESCE(odf_rated_ccr_late_record_count, 0) AS odf_rated_ccr_late_record_count,
  COALESCE(odf_rated_ccr_late_byte_count, 0) AS odf_rated_ccr_late_byte_count,
  COALESCE(odf_daily_aggregated_record_count, 0) AS odf_daily_aggregated_record_count,
  COALESCE(odf_daily_aggregated_byte_count, 0) AS odf_daily_aggregated_byte_count
FROM usage_ingest_success                           -- KPI 1
FULL OUTER JOIN usage_ingest_failure                -- KPI 2
USING (month_skey, yy, mm, bcc, ATST)                       
FULL OUTER JOIN uro_kpis                            -- KPI 3 - 7
USING (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN rerate_kpis                         -- KPI 8 - 12
USING (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN odf_rated_ccr_received              -- KPI 13
USING (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN odf_rated_ccr_skipped               -- KPI 14
USING (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN odf_rated_ccr_failed                -- KPI 15
USING (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN odf_rated_ccr_late                  -- KPI 16
USING (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN odf_daily_aggregated                -- KPI 17
USING (month_skey, yy, mm, bcc, ATST)