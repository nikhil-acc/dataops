DELETE `{{ project_id }}.{{ sr_esd_dataset }}.daily_reconciliation_with_atst`
WHERE dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto");

INSERT `{{ project_id }}.{{ sr_esd_dataset }}.daily_reconciliation_with_atst` (
  dt_skey,
  ATST,
  usage_ingest_success_record_count,
  usage_ingest_success_byte_count,
  usage_ingest_failed_record_count,
  usage_ingest_failed_byte_count,
  uro_success_record_count,
  uro_success_byte_count,
  uro_partially_applied_record_count,
  uro_partially_applied_byte_count,
  uro_unapplied_record_count,
  uro_unapplied_byte_count,
  uro_failed_record_count,
  uro_failed_byte_count,
  uro_not_rated_record_count,
  uro_not_rated_byte_count,
  odf_rated_ccr_processed_record_count,
  odf_rated_ccr_processed_byte_count,
  odf_rated_ccr_skipped_record_count,
  odf_rated_ccr_skipped_byte_count,
  odf_rated_ccr_failed_record_count,
  odf_rated_ccr_failed_byte_count,
  odf_rated_ccr_late_record_count,
  odf_rated_ccr_late_byte_count
)


-- KPI 4: Usage Ingest Success
WITH usage_ingest_success AS (
    SELECT ccr.dt_skey,
      COUNT(ccr) as usage_ingest_success_record_count,
      SUM(ccr.bytesIn + ccr.bytesOut)/1048576 as usage_ingest_success_byte_count,
      COALESCE(ratedusages_latest_ATST.ATST, 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_guided_ccr_temp as ccr
    LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi ratedusages_latest_ATST
    ON ccr.IMSI = ratedusages_latest_ATST.imsi
    WHERE ccr.dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")
    AND ccr.roamingIndicator IN ("H", "C")
    GROUP BY ccr.dt_skey, ATST
  ),

-- KPI 5: Usage Ingest Failed
  usage_ingest_failed AS (
    SELECT usageIngestError.dt_skey,
      COUNT(usageIngestError) as usage_ingest_failed_record_count,
      SUM(usageIngestError.bytesIn + usageIngestError.bytesOut)/1048576 as usage_ingest_failed_byte_count,
      COALESCE(ratedusages_latest_ATST.ATST, 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_bell_usage_ingest_error_temp as usageIngestError
    LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi ratedusages_latest_ATST
    ON usageIngestError.IMSI = ratedusages_latest_ATST.imsi
    WHERE usageIngestError.dt_skey BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")
    AND usageIngestError.roamingIndicator IN ("H", "C") AND ratedusages_latest_ATST.imsi IS NULL
    GROUP BY usageIngestError.dt_skey, ATST
  ),

  -- KPI 6 - 10
  uro_kpis AS (
    SELECT 
      SUM(uro_success_record_count) AS uro_success_record_count, -- KPI 6
      SUM(uro_success_byte_count)/1048576 AS uro_success_byte_count, -- KPI 6
      SUM(uro_partially_applied_record_count) AS uro_partially_applied_record_count, -- KPI 7
      SUM(uro_partially_applied_byte_count)/1048576 AS uro_partially_applied_byte_count, -- KPI 7
      SUM(uro_unapplied_record_count) AS uro_unapplied_record_count, -- KPI 8
      SUM(uro_unapplied_byte_count)/1048576 AS uro_unapplied_byte_count, -- KPI 8
      SUM(uro_failed_record_count) AS uro_failed_record_count, -- KPI 9
      SUM(uro_failed_byte_count)/1048576 AS uro_failed_byte_count, -- KPI 9
      SUM(uro_not_rated_record_count) AS uro_not_rated_record_count, -- KPI 10
      SUM(uro_not_rated_byte_count)/1048576 AS uro_not_rated_byte_count, -- KPI 10
      ATST,
      dt_skey
    FROM (
      SELECT
        reporting_date as dt_skey,
        COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST,
        CASE WHEN RatingStatus = 'SUCCESS' THEN 1 ELSE 0 END AS uro_success_record_count,
        CASE WHEN RatingStatus = 'SUCCESS' THEN bytesIn + bytesOut ELSE 0 END AS uro_success_byte_count,
        CASE WHEN RatingStatus = 'PARTIALLY_RATED' AND ARRAY_LENGTH(usageBalanceImpacts) > 0 THEN 1 ELSE 0 END AS uro_partially_applied_record_count,
        CASE WHEN RatingStatus = 'PARTIALLY_RATED' AND ARRAY_LENGTH(usageBalanceImpacts) > 0 
          THEN bytesIn + bytesOut - (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) una) 
          ELSE 0 END AS uro_partially_applied_byte_count,
        CASE WHEN RatingStatus = 'PARTIALLY_RATED' AND (ARRAY_LENGTH(usageBalanceImpacts) = 0 OR usageBalanceImpacts IS NULL) THEN 1 ELSE 0 END AS uro_unapplied_record_count,
        CASE WHEN RatingStatus = 'PARTIALLY_RATED' AND (ARRAY_LENGTH(usageBalanceImpacts) = 0 OR usageBalanceImpacts IS NULL) 
          THEN (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) una)  ELSE 0 END AS uro_unapplied_byte_count,
        CASE WHEN RatingStatus = 'FAILURE' THEN 1 ELSE 0 END AS uro_failed_record_count,
        CASE WHEN RatingStatus = 'FAILURE' THEN bytesIn + bytesOut ELSE 0 END AS uro_failed_byte_count,
        CASE WHEN RatingStatus = 'NOT_RATED' THEN 1 ELSE 0 END AS uro_not_rated_record_count,
        CASE WHEN RatingStatus = 'NOT_RATED' THEN bytesIn + bytesOut ELSE 0 END AS uro_not_rated_byte_count
      FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
      WHERE reporting_date BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")
        AND source = "RATE"
      )
    GROUP BY dt_skey, ATST
  ),

-- KPI 11: ODF Rated CCR Processed
  odf_rated_ccr_processed AS (
    SELECT reporting_date AS dt_skey,
      COUNT(*) as odf_rated_ccr_processed_record_count,
      SUM(CAST(at_call_dur_round_min AS INT64))/1048576 as odf_rated_ccr_processed_byte_count,
      COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_rated_ccrs_deduplicated_temp
    WHERE (reporting_date BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")) AND source = 'RATE' 
    GROUP BY dt_skey, ATST
  ),

-- KPI 12: ODF Rated CCR Skipped
  odf_rated_ccr_skipped AS (
    SELECT reporting_date AS dt_skey,
      COUNT(*) as odf_rated_ccr_skipped_record_count,
      SUM(bytesIn + bytesOut)/1048576 as odf_rated_ccr_skipped_byte_count,
      COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_skipped_records_temp
    WHERE (reporting_date BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")) AND source = 'RATE' 
    GROUP BY dt_skey, ATST 
  ),

-- KPI 13: ODF Rated CCR Failed
  odf_rated_ccr_failed AS (
    SELECT reporting_date AS dt_skey,
      COUNT(*) as odf_rated_ccr_failed_record_count,
      SUM(bytesIn + bytesOut)/1048576 as odf_rated_ccr_failed_byte_count,
      COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_reject_records_temp
    WHERE (reporting_date BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")) AND source = 'RATE' 
    GROUP BY dt_skey, ATST
  ),

-- KPI 14: ODF Rated CCR Late
  odf_rated_ccr_late AS (
    SELECT reporting_date AS dt_skey,
      COUNT(*) as odf_rated_ccr_late_record_count,
      SUM(bytesIn + bytesOut)/1048576 as odf_rated_ccr_late_byte_count,
      COALESCE(CONCAT(accountType, accountSubType), 'unknown ATST') as ATST
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_late_usage_records_temp
    WHERE (reporting_date BETWEEN DATE_SUB(CURRENT_DATE("America/Toronto"), INTERVAL 1 WEEK) AND CURRENT_DATE("America/Toronto")) AND source = 'RATE' 
    GROUP BY dt_skey, ATST
  )


SELECT 
  dt_skey,
  ATST,
  COALESCE(usage_ingest_success_record_count, 0) AS usage_ingest_success_record_count,
  COALESCE(usage_ingest_success_byte_count, 0) AS usage_ingest_success_byte_count,
  COALESCE(usage_ingest_failed_record_count, 0) AS usage_ingest_failed_record_count,
  COALESCE(usage_ingest_failed_byte_count, 0) AS usage_ingest_failed_byte_count,
  COALESCE(uro_success_record_count, 0) AS uro_success_record_count,
  COALESCE(uro_success_byte_count, 0) AS uro_success_byte_count,
  COALESCE(uro_partially_applied_record_count, 0) AS uro_partially_applied_record_count,
  COALESCE(uro_partially_applied_byte_count, 0) AS uro_partially_applied_byte_count,
  COALESCE(uro_unapplied_record_count, 0) AS uro_unapplied_record_count,
  COALESCE(uro_unapplied_byte_count, 0) AS uro_unapplied_byte_count,
  COALESCE(uro_failed_record_count, 0) AS uro_failed_record_count,
  COALESCE(uro_failed_byte_count, 0) AS uro_failed_byte_count,
  COALESCE(uro_not_rated_record_count, 0) AS uro_not_rated_record_count,
  COALESCE(uro_not_rated_byte_count, 0) AS uro_not_rated_byte_count,
  COALESCE(odf_rated_ccr_processed_record_count, 0) AS odf_rated_ccr_processed_record_count,
  COALESCE(odf_rated_ccr_processed_byte_count, 0) AS odf_rated_ccr_processed_byte_count,
  COALESCE(odf_rated_ccr_skipped_record_count, 0) AS odf_rated_ccr_skipped_record_count,
  COALESCE(odf_rated_ccr_skipped_byte_count, 0) AS odf_rated_ccr_skipped_byte_count,
  COALESCE(odf_rated_ccr_failed_record_count, 0) AS odf_rated_ccr_failed_record_count,
  COALESCE(odf_rated_ccr_failed_byte_count, 0) AS odf_rated_ccr_failed_byte_count,
  COALESCE(odf_rated_ccr_late_record_count, 0) AS odf_rated_ccr_late_record_count,
  COALESCE(odf_rated_ccr_late_byte_count, 0) AS odf_rated_ccr_late_byte_count
FROM usage_ingest_success               -- KPI 4
FULL OUTER JOIN usage_ingest_failed     -- KPI 5
USING (dt_skey, ATST)
FULL OUTER JOIN uro_kpis                -- KPI 6 - 10
USING (dt_skey, ATST)
FULL OUTER JOIN odf_rated_ccr_processed -- KPI 11
USING (dt_skey, ATST)
FULL OUTER JOIN odf_rated_ccr_skipped   -- KPI 12
USING (dt_skey, ATST)
FULL OUTER JOIN odf_rated_ccr_failed    -- KPI 13
USING (dt_skey, ATST)
FULL OUTER JOIN odf_rated_ccr_late      -- KPI 14
USING (dt_skey, ATST)
ORDER BY dt_skey
