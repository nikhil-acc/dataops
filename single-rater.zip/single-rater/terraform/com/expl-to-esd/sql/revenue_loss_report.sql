DELETE `{{ project_id }}.{{ sr_esd_dataset }}.revenue_loss_report`
WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH));

INSERT `{{ project_id }}.{{ sr_esd_dataset }}.revenue_loss_report`
(
  month_skey,
  bcc,
  mm,
  yy,
  ATST,
  chf_failed_ccr_count,
  chf_failed_ccr_volume,
  odf_failed_ccrs_count,
  odf_failed_ccrs_volume,
  odf_failed_ban_ccrs_count,
  odf_ban_failed_ccrs_volume
)

-- chf failed KPIs
WITH chf_failed_KPIs AS
  (SELECT 
    COUNT(*) AS chf_failed_ccr_count, -- KPI 1
    sum(bytesIn + bytesOut)/1048576 AS chf_failed_ccr_volume, -- KPI 2
    COALESCE(month_skey, DATE(CONCAT(extract(YEAR FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto"), 
      "-", extract(MONTH FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto"), "-01"))) AS month_skey, -- set as current month & year if month_skey does not exist
    COALESCE(ATST, "unknown ATST") AS ATST,
    COALESCE(bcc, "unknown BCC") AS bcc,
    COALESCE(CAST(mm AS STRING), CAST(extract(MONTH FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto") AS STRING)) AS mm,
    COALESCE(CAST(yy AS STRING), CAST(extract(YEAR FROM CURRENT_TIMESTAMP() AT TIME ZONE "America/Toronto") AS STRING)) AS yy
  FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_cgf_que_unrated_mapping_error_records_temp errors
  LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_imsi_xcorrelationId latest_ATST_imsi_xCorrelationId
    ON latest_ATST_imsi_xCorrelationId.xCorrelationId = errors.xCorrelationId AND latest_ATST_imsi_xCorrelationId.imsi = errors.imsi
  WHERE latest_ATST_imsi_xCorrelationId.month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    AND roamingIndicator IN ("H", "C")
  GROUP BY month_skey, yy, mm, bcc, ATST),

-- get highest rerate version, ban, and bcc/mm/yy from wnc_odf_que_billed_unique_reject_summary
billed_unique_reject_ban_bccmmyy_max_rerate_ver_list AS (
  SELECT 
    ban,
    cycle_code,
    cycle_run_month,
    cycle_run_year,
    rerate_version,
    month_skey
  FROM (
    SELECT
      ban,
      cycle_code,
      cycle_run_month,
      cycle_run_year,
      ROW_NUMBER() OVER (PARTITION BY cycle_run_year, cycle_run_month, cycle_code, ban ORDER BY rerate_version DESC) AS rerate_version_rank,
      rerate_version,
      month_skey
    FROM
      {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_unique_reject_summary_temp
  )
  WHERE
    rerate_version_rank = 1
),

-- get highest rerate version, ban, and bcc/mm/yy from wnc_odf_que_billed_daily_summary
billed_daily_summary_ban_bccmmyy_max_rerate_ver_list AS ( 
 SELECT 
    ban,
    cycle_code,
    cycle_run_month,
    cycle_run_year,
    rerate_version,
    month_skey
  FROM (
    SELECT
      ban,
      cycle_code,
      cycle_run_month,
      cycle_run_year,
      ROW_NUMBER() OVER (PARTITION BY cycle_run_year, cycle_run_month, cycle_code, ban ORDER BY rerate_version DESC) AS rerate_version_rank,
      rerate_version,
      month_skey
    FROM
      {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_daily_summary_temp
  )
  WHERE
    rerate_version_rank = 1
),

-- "billed failed ban" list
billed_failed_ban AS (
SELECT 
  COALESCE(wnc_odf_que_unique_reject_summary_temp.ban, 
            billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.ban, 
            billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.ban) AS ban,
  COALESCE(wnc_odf_que_unique_reject_summary_temp.cycle_code, 
            billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_code, 
            billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_code) AS bcc,
  COALESCE(wnc_odf_que_unique_reject_summary_temp.cycle_run_month, 
            billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_month, 
            billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_month) AS mm,
  COALESCE(wnc_odf_que_unique_reject_summary_temp.cycle_run_year, 
            billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_year, 
            billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_year) AS yy
FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp wnc_odf_que_unique_reject_summary_temp
FULL OUTER JOIN
  billed_unique_reject_ban_bccmmyy_max_rerate_ver_list
USING (cycle_run_year, cycle_run_month, cycle_code, ban)
FULL OUTER JOIN
  billed_daily_summary_ban_bccmmyy_max_rerate_ver_list
USING (cycle_run_year, cycle_run_month, cycle_code, ban)
WHERE
(
  (-- If ban and bcc_mm_yy only exists in wnc_odf_que_unique_reject_summary
  wnc_odf_que_unique_reject_summary_temp.ban IS NOT NULL
  AND wnc_odf_que_unique_reject_summary_temp.cycle_code IS NOT NULL
  AND wnc_odf_que_unique_reject_summary_temp.cycle_run_month IS NOT NULL
  AND wnc_odf_que_unique_reject_summary_temp.cycle_run_year IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.ban IS NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_code IS NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_month IS NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_year IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.ban IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_code IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_month IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_year IS NULL)
OR
(-- If ban and bcc_mm_yy exists in wnc_odf_que_billed_unique_reject_summary but not exists in wnc_odf_que_billed_daily_summary
  billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.ban IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_code IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_month IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_year IS NOT NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.ban IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_code IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_month IS NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_year IS NULL)
OR
( -- If ban and bcc_mm_yy exist in both wnc_odf_que_billed_unique_reject_summary and wnc_odf_que_billed_daily_summary 
  -- AND (the highest rerateVersion can be found in wnc_odf_que_billed_unique_reject_summary)
  billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.ban IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_code IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_month IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.cycle_run_year IS NOT NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.ban IS NOT NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_code IS NOT NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_month IS NOT NULL
  AND billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.cycle_run_year IS NOT NULL
  AND billed_unique_reject_ban_bccmmyy_max_rerate_ver_list.rerate_version >= billed_daily_summary_ban_bccmmyy_max_rerate_ver_list.rerate_version)
)
GROUP BY yy, mm, bcc, ban),

-- Ban and bcc_mm_yy and max_rerate_version and corresponding subscriber number from wnc_odf_que_intake_reject_records
-- This max rerate version is on the subscriber level
-- This query only includes records where (source in "RATE, RERATE, BILLED_RERATE" and ratingStatus in "SUCCESS, PARTIALLY_RATED, FAILURE")
-- bytes and ATST are for the max rerate version of each sub
-- getting max rerate version for rejected records
ban_bccmmyy_max_rerate_ver_intake_reject_records AS (
  SELECT
    ban,
    bcc,
    mm,
    yy,
    rerateVersion,
    bytes,
    COALESCE(ATST, "unknown ATST") AS ATST,
    month_skey
  FROM 
  (SELECT
    ban,
    bcc,
    cast(EXTRACT(MONTH FROM month_skey) AS string) AS mm,
    cast(EXTRACT(YEAR FROM month_skey) AS string) AS yy,
    RANK() OVER (
      PARTITION BY EXTRACT(YEAR FROM month_skey), EXTRACT(MONTH FROM month_skey), bcc, ban, subscriberId ORDER BY rerateVersion DESC) AS rerate_version_rank,
    rerateVersion,
    (bytesIn + bytesOut)/1048576 as bytes,
    CONCAT(accountType, accountSubType) AS ATST,
    month_skey
  FROM 
    {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_intake_reject_records_temp
  WHERE 
    month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    AND source IN ("RATE", "RERATE", "BILLED_RERATE")
    AND ratingStatus IN ("SUCCESS", "PARTIALLY_RATED", "FAILURE")
  )
  WHERE
    rerate_version_rank = 1
),

-- getting max rerate version for billed rejected records
ban_bccmmyy_max_rerate_ver_billed_intake_reject_records AS (
  SELECT
    ban,
    bcc,
    mm,
    yy,
    rerate_version,
    bytes,
    COALESCE(ATST, "unknown ATST") AS ATST,
    month_skey
  FROM 
  (SELECT
    ban,
    bcc,
    CAST(EXTRACT(MONTH FROM month_skey) AS STRING) AS mm,
    CAST(EXTRACT(YEAR FROM month_skey) AS STRING) AS yy,
    ROW_NUMBER() OVER (
      PARTITION BY EXTRACT(YEAR FROM month_skey), EXTRACT(MONTH FROM month_skey), bcc, ban ORDER BY rerate_version DESC) AS rerate_version_rank,
    rerate_version,
    (bytesIn + bytesOut)/1048576 as bytes,
    CONCAT(accountType, accountSubType) AS ATST,
    month_skey
  FROM 
    {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_billed_intake_reject_records_temp
  )
  WHERE
    rerate_version_rank = 1
),

-- Unique ban and bcc_mm_yy both intake reject records
unique_rejected_ban_bccmmyy AS (
SELECT 
  COALESCE(ban_bccmmyy_max_rerate_ver_intake_reject_records.ban, ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.ban) AS ban,
  COALESCE(ban_bccmmyy_max_rerate_ver_intake_reject_records.bcc, ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.bcc) AS bcc,
  COALESCE(ban_bccmmyy_max_rerate_ver_intake_reject_records.mm, ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.mm) AS mm,
  COALESCE(ban_bccmmyy_max_rerate_ver_intake_reject_records.yy, ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.yy) AS yy,
  COALESCE(ban_bccmmyy_max_rerate_ver_intake_reject_records.month_skey, ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.month_skey) AS month_skey
FROM ban_bccmmyy_max_rerate_ver_intake_reject_records
FULL OUTER JOIN
  ban_bccmmyy_max_rerate_ver_billed_intake_reject_records
USING 
  (month_skey, yy, mm, bcc, ban)
GROUP BY month_skey, yy, mm, bcc, ban),

-- Exclude ban and bcc_mm_yy in billed_failed_ban (get only records that are not in billed_failed_ban)
billed_successful_ban AS (
SELECT 
  unique_rejected_ban_bccmmyy.ban,
  unique_rejected_ban_bccmmyy.bcc,
  unique_rejected_ban_bccmmyy.mm,
  unique_rejected_ban_bccmmyy.yy,
  unique_rejected_ban_bccmmyy.month_skey
FROM unique_rejected_ban_bccmmyy
LEFT JOIN billed_failed_ban
ON
  unique_rejected_ban_bccmmyy.ban = billed_failed_ban.ban
  AND unique_rejected_ban_bccmmyy.bcc = billed_failed_ban.bcc
  AND unique_rejected_ban_bccmmyy.mm = billed_failed_ban.mm
  AND unique_rejected_ban_bccmmyy.yy = billed_failed_ban.yy
WHERE billed_failed_ban.ban IS NULL AND billed_failed_ban.bcc IS NULL AND billed_failed_ban.mm IS NULL AND billed_failed_ban.yy IS NULL),

-- odf_failed_ccr KPIs
failed_ccr_successful_ban AS (
SELECT 
  COUNT(*) AS odf_failed_ccrs_count, -- KPI 5
  SUM(COALESCE(
      CASE WHEN ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.ban IS NULL THEN ban_bccmmyy_max_rerate_ver_intake_reject_records.bytes
            ELSE ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.bytes END, 0)) AS odf_failed_ccrs_volume, -- KPI 6
  -- get billed ATST if exists, else get the non-billed one
  COALESCE(ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.ATST, ban_bccmmyy_max_rerate_ver_intake_reject_records.ATST) AS ATST,
  billed_successful_ban.bcc,
  billed_successful_ban.mm,
  billed_successful_ban.yy,
  billed_successful_ban.month_skey
FROM billed_successful_ban
LEFT JOIN ban_bccmmyy_max_rerate_ver_billed_intake_reject_records
ON billed_successful_ban.ban = ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.ban
  AND billed_successful_ban.bcc = ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.bcc
  AND billed_successful_ban.mm = ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.mm
  AND billed_successful_ban.yy = ban_bccmmyy_max_rerate_ver_billed_intake_reject_records.yy
LEFT JOIN ban_bccmmyy_max_rerate_ver_intake_reject_records
ON ban_bccmmyy_max_rerate_ver_intake_reject_records.ban = billed_successful_ban.ban
  AND ban_bccmmyy_max_rerate_ver_intake_reject_records.bcc = billed_successful_ban.bcc
  AND ban_bccmmyy_max_rerate_ver_intake_reject_records.mm = billed_successful_ban.mm
  AND ban_bccmmyy_max_rerate_ver_intake_reject_records.yy = billed_successful_ban.yy
GROUP BY month_skey, yy, mm, bcc, ATST),

-- get max rerate version and corresponding bytes and unapplied bytes
ban_bccmmyy_max_rerate_ver_ratedusage AS (
  SELECT month_skey,
    ban,
    bcc,
    mm,
    yy,
    rerateVersion,
    COALESCE(CONCAT(accountType, accountSubType), "unknown ATST") AS ATST,
    bytes,
    unapplied_bytes
  FROM (
  SELECT 
    month_skey,
    ban, 
    bcc,
    cast(EXTRACT(MONTH FROM month_skey) AS string) AS mm, 
    cast(EXTRACT(YEAR FROM month_skey) AS string) AS yy,
    rerateVersion,
    RANK() OVER (
      PARTITION BY EXTRACT(YEAR FROM month_skey),EXTRACT(MONTH FROM month_skey),bcc, ban, subscriberId ORDER BY rerateVersion DESC) AS rerate_version_rank,
    accountType,
    accountSubType,
    bytesIn + bytesOut AS bytes,
    (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) AS una) AS unapplied_bytes
  FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
  WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
    AND source IN ("RATE", "RERATE", "BILLED_RERATE") AND ratingStatus IN ("SUCCESS", "PARTIALLY_RATED", "FAILURE"))
  WHERE rerate_version_rank = 1
),

-- Get all needed fields from wnc_arc_que_billed_rated_usages with the max_rerate_version
ban_bccmmyy_max_rerate_version_billed_rated_usages AS (
SELECT 
    month_skey,
    ban,
    bcc,
    mm,
    yy,
    rerateVersion,
    COALESCE(CONCAT(accountType, accountSubType), "unknown ATST") AS ATST,
    bytes,
    unapplied_bytes
  FROM (
  SELECT 
    month_skey,
    ban, 
    bcc,
    cast(EXTRACT(MONTH FROM month_skey) AS string) AS mm,
    cast(EXTRACT(YEAR FROM month_skey) AS string) AS yy,
    rerateVersion,
    ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM month_skey),EXTRACT(MONTH FROM month_skey), bcc, ban ORDER BY rerateVersion DESC) AS rerate_version_rank,
    accountType,
    accountSubType,
    bytesIn + bytesOut AS bytes,
    (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) AS una) AS unapplied_bytes
  FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_billed_rated_usages_temp
  )
  WHERE rerate_version_rank = 1
),

-- odf failed ban ccr KPIs
failed_ban_kpis AS (
SELECT 
  COUNT(*) as odf_failed_ban_ccrs_count, -- KPI 7
    SUM(COALESCE(
      CASE WHEN ban_bccmmyy_max_rerate_version_billed_rated_usages.ban IS NULL 
        THEN (ban_bccmmyy_max_rerate_ver_ratedusage.bytes - COALESCE(ban_bccmmyy_max_rerate_ver_ratedusage.unapplied_bytes, 0))/1048576
      ELSE (ban_bccmmyy_max_rerate_version_billed_rated_usages.bytes - COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.unapplied_bytes,0))/1048576 END, 0)) 
      AS odf_ban_failed_ccrs_volume, -- KPI 8
  COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.ATST, ban_bccmmyy_max_rerate_ver_ratedusage.ATST) AS ATST,
  COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.bcc, ban_bccmmyy_max_rerate_ver_ratedusage.bcc) AS bcc,
  COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.mm, ban_bccmmyy_max_rerate_ver_ratedusage.mm) AS mm,
  COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.yy, ban_bccmmyy_max_rerate_ver_ratedusage.yy) AS yy,
  COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.month_skey, ban_bccmmyy_max_rerate_ver_ratedusage.month_skey) AS month_skey
FROM billed_failed_ban
LEFT JOIN ban_bccmmyy_max_rerate_version_billed_rated_usages
ON ban_bccmmyy_max_rerate_version_billed_rated_usages.ban = billed_failed_ban.ban
  AND ban_bccmmyy_max_rerate_version_billed_rated_usages.bcc = billed_failed_ban.bcc
  AND ban_bccmmyy_max_rerate_version_billed_rated_usages.mm = billed_failed_ban.mm
  AND ban_bccmmyy_max_rerate_version_billed_rated_usages.yy = billed_failed_ban.yy
LEFT JOIN ban_bccmmyy_max_rerate_ver_ratedusage
ON ban_bccmmyy_max_rerate_ver_ratedusage.ban = billed_failed_ban.ban
  AND ban_bccmmyy_max_rerate_ver_ratedusage.bcc = billed_failed_ban.bcc
  AND ban_bccmmyy_max_rerate_ver_ratedusage.mm = billed_failed_ban.mm
  AND ban_bccmmyy_max_rerate_ver_ratedusage.yy = billed_failed_ban.yy
-- only get the data that is in the rated usages table
WHERE COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.ban, ban_bccmmyy_max_rerate_ver_ratedusage.ban) IS NOT NULL 
  AND COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.bcc, ban_bccmmyy_max_rerate_ver_ratedusage.bcc) IS NOT NULL
  AND COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.mm, ban_bccmmyy_max_rerate_ver_ratedusage.mm) IS NOT NULL
  AND COALESCE(ban_bccmmyy_max_rerate_version_billed_rated_usages.yy, ban_bccmmyy_max_rerate_ver_ratedusage.yy) IS NOT NULL
GROUP BY month_skey, yy, mm, bcc, ATST)

-- Combine KPI 1 - 8
SELECT 
  month_skey,
  bcc,
  mm,
  yy,
  ATST,
  COALESCE(chf_failed_ccr_count, 0) AS chf_failed_ccr_count,
  COALESCE(chf_failed_ccr_volume, 0) AS chf_failed_ccr_volume,
  COALESCE(odf_failed_ccrs_count, 0) AS odf_failed_ccrs_count,
  COALESCE(odf_failed_ccrs_volume, 0) AS odf_failed_ccrs_volume,
  COALESCE(odf_failed_ban_ccrs_count, 0) AS odf_failed_ban_ccrs_count,
  COALESCE(odf_ban_failed_ccrs_volume, 0) AS odf_ban_failed_ccrs_volume
FROM
  failed_ccr_successful_ban
FULL OUTER JOIN
  chf_failed_KPIs
USING
  (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN
  failed_ban_kpis
USING
  (month_skey, yy, mm, bcc, ATST)