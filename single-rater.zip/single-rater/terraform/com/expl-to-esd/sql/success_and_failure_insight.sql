DELETE `{{ project_id }}.{{ sr_esd_dataset }}.success_and_failure_insight`
WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH));

INSERT `{{ project_id }}.{{ sr_esd_dataset }}.success_and_failure_insight`
  (month_skey,
  total_bans_processed_by_odf,	
  total_subscribers_processed_by_odf,
  total_count_of_daily_records,
  total_volume_of_daily_records,
  bcc,
  mm,
  yy,
  ATST,
  total_overage,
  total_bans_marked_as_failed_by_odf,
  total_subscribers_marked_failed_by_odf,
  total_count_of_ccrs_related_to_failed_ban,
  total_count_of_success_ccrs_related_to_failed_ban,
  total_count_of_partial_ccrs_related_to_failed_ban,
  total_count_of_failure_ccrs_related_to_failed_ban,
  total_volume_of_ccrs_related_to_failed_ban,
  total_volume_of_success_ccrs_related_to_failed_ban,
  total_volume_of_partial_ccrs_related_to_failed_ban,
  total_volume_of_failure_ccrs_related_to_failed_ban,
  rate_of_successful_bans)

-- Needed KPI columns where record is in wnc_odf_que_daily_summary but NOT IN wnc_odf_que_unique_reject_summary 
WITH
  non_rejected_daily_summary AS (
  SELECT 
    daily.ban,
    daily.subscriber_no,
    daily.at_call_dur_round_min,
    daily.cycle_code bcc,
    CAST(daily.cycle_run_month AS INT) AS mm,
    CAST(daily.cycle_run_year AS INT) AS yy,
    daily.month_skey
  FROM
    {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_daily_summary_temp daily
  LEFT JOIN
    {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp reject
  ON 
    daily.cycle_code = reject.cycle_code
    AND daily.cycle_run_month = reject.cycle_run_month
    AND daily.cycle_run_year = reject.cycle_run_year
    AND daily.ban = reject.ban
  WHERE 
    reject.cycle_code IS NULL AND reject.cycle_run_month IS NULL and reject.cycle_run_year IS NULL AND reject.ban IS NULL
  ),


-- KPI1 - 4 
  daily_KPIs AS (
    SELECT 
      COUNT(DISTINCT(non_rejected_daily_summary.ban)) AS total_bans_processed_by_odf,
      COUNT(DISTINCT(subscriber_no)) AS total_subscribers_processed_by_odf,
      COUNT(*) AS total_count_of_daily_records,
      SUM(at_call_dur_round_min) AS total_volume_of_daily_records,
      non_rejected_daily_summary.bcc,
      non_rejected_daily_summary.mm,
      non_rejected_daily_summary.yy,
      COALESCE(ATST, 'unknown ATST') ATST,
      non_rejected_daily_summary.month_skey
    FROM
    non_rejected_daily_summary
    LEFT JOIN
      {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy latest_ATST_BAN_BCCMMYY
    ON non_rejected_daily_summary.ban = latest_ATST_BAN_BCCMMYY.ban
      AND non_rejected_daily_summary.bcc = latest_ATST_BAN_BCCMMYY.bcc
      AND non_rejected_daily_summary.mm = latest_ATST_BAN_BCCMMYY.mm
      AND non_rejected_daily_summary.yy = latest_ATST_BAN_BCCMMYY.yy
    GROUP BY non_rejected_daily_summary.month_skey, bcc, mm, yy, ATST),

-- records that are in wnc_odf_que_au_aggr_record_type_1 but not in wnc_odf_que_unique_reject_summary
non_rejected_au_type_1 AS (
  SELECT chrg_amt,
    au.cycle_code AS bcc,
    CAST(au.cycle_run_month AS INT) AS mm,
    CAST(au.cycle_run_year AS INT) AS yy,
    COALESCE(latest_ATST_BAN_BCCMMYY.ATST, 'unknown ATST') AS ATST,
    au.subscriber_no,
    au.ban,
    au.rating_start_time,
    au.month_skey
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_au_aggr_record_type_1_temp au
    LEFT JOIN 
      {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp reject
    ON 
      au.cycle_code = reject.cycle_code
      AND au.cycle_run_month = reject.cycle_run_month
      AND au.cycle_run_year = reject.cycle_run_year 
      AND au.ban = reject.ban
    LEFT JOIN 
      {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy latest_ATST_BAN_BCCMMYY 
    ON au.ban = latest_ATST_BAN_BCCMMYY.ban 
      AND au.cycle_code = latest_ATST_BAN_BCCMMYY.bcc
      AND CAST(au.cycle_run_month AS INT) = latest_ATST_BAN_BCCMMYY.mm
      AND CAST(au.cycle_run_year AS INT) = latest_ATST_BAN_BCCMMYY.yy
    WHERE 
      reject.cycle_code IS NULL AND reject.cycle_run_month IS NULL AND reject.cycle_run_year IS NULL AND reject.ban IS NULL 
),

-- find subscriber number that is purged and the maximum rating start time of the purged record
latest_purged_subscribers AS (
  SELECT
    subscriber_no,
    rating_start_time,
    ban,
    bcc,
    mm,
    yy,
    month_skey
  FROM (
  SELECT
    subscriber_no,
    ROW_NUMBER() OVER (partition by cycle_run_year, cycle_run_month, cycle_code, ban ORDER BY rating_start_time DESC) AS ratingStartTime_rank,
    rating_start_time,
    ban,
    cycle_code AS bcc,
    CAST(cycle_run_month AS INT) AS mm,
    CAST(cycle_run_year AS INT) AS yy,
    month_skey
  FROM
      {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_au_aggr_record_type_1_temp
  WHERE
    soc = "PURGESOC"
  )
  WHERE ratingStartTime_rank = 1
),

-- records in non_rejected_au_type_1 which are not purged and needs to be included in the aggregation
non_purged_successful_aggr_record AS (
  SELECT 
    non_rejected_au_type_1.chrg_amt,
    non_rejected_au_type_1.bcc,
    non_rejected_au_type_1.mm,
    non_rejected_au_type_1.yy,
    COALESCE(non_rejected_au_type_1.ATST, 'unknown ATST') AS ATST,
    non_rejected_au_type_1.subscriber_no,
    non_rejected_au_type_1.month_skey
  FROM non_rejected_au_type_1
  LEFT JOIN latest_purged_subscribers
  ON non_rejected_au_type_1.subscriber_no = latest_purged_subscribers.subscriber_no
    AND non_rejected_au_type_1.ban = latest_purged_subscribers.ban
    AND non_rejected_au_type_1.bcc = latest_purged_subscribers.bcc
    AND non_rejected_au_type_1.mm = latest_purged_subscribers.mm
    AND non_rejected_au_type_1.yy = latest_purged_subscribers.yy
    WHERE
     -- include results where 1.subscriber has nopurge OR 2.the subscriber's newer record is not "PURGESOC"
    (latest_purged_subscribers.subscriber_no IS NULL
    OR
    (latest_purged_subscribers.subscriber_no IS NOT NULL 
      AND non_rejected_au_type_1.rating_start_time > latest_purged_subscribers.rating_start_time))
),

-- KPI5 
total_overage AS (
  SELECT
    SUM(chrg_amt) AS total_overage,
    bcc,
    mm,
    yy,
    ATST,
    month_skey
  FROM non_purged_successful_aggr_record
  GROUP BY month_skey, yy, mm, bcc, ATST),

-- KPI 6 - count of bans grouped by ATST & bcc_mm_yy
failed_bans AS (
    SELECT
      COUNT(reject.ban) AS total_bans_marked_as_failed_by_odf,
      reject.cycle_code AS bcc,
      CAST(reject.cycle_run_month AS INT) AS mm,
      CAST(reject.cycle_run_year AS INT) AS yy,
      COALESCE(latest_ATST_BAN_BCCMMYY.ATST, 'unknown ATST') AS ATST,
      reject.month_skey
  FROM
    {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp reject
  LEFT JOIN
    {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy latest_ATST_BAN_BCCMMYY
  ON
    reject.ban = latest_ATST_BAN_BCCMMYY.ban
    AND reject.cycle_code = latest_ATST_BAN_BCCMMYY.bcc
    AND CAST(reject.cycle_run_month AS INT) = latest_ATST_BAN_BCCMMYY.mm
    AND CAST(reject.cycle_run_year AS INT) = latest_ATST_BAN_BCCMMYY.yy
  GROUP BY reject.month_skey, reject.cycle_run_year, reject.cycle_run_month, reject.cycle_code, latest_ATST_BAN_BCCMMYY.ATST),

-- get the records on the subscriber level which has max rerate version
subscribers_with_max_rerate_version AS (
  SELECT * except(rerateVersion_rank, bytesIn, bytesOut, unapplied_bytes, ratingStatus),
  CASE WHEN ratingStatus = "SUCCESS" THEN 1 ELSE 0 END AS success_record,
  CASE WHEN ratingStatus = "PARTIALLY_RATED" THEN 1 ELSE 0 END AS partial_record,
  CASE WHEN ratingStatus = "FAILURE" THEN 1 ELSE 0 END AS failure_record,
  CASE WHEN ratingStatus = "SUCCESS" THEN (COALESCE(bytesIn, 0) + COALESCE(bytesOut, 0) - COALESCE(unapplied_bytes, 0)) ELSE 0 END AS success_volume,
  CASE WHEN ratingStatus = "PARTIALLY_RATED" THEN (COALESCE(bytesIn, 0) + COALESCE(bytesOut, 0) - COALESCE(unapplied_bytes, 0)) ELSE 0 END AS partial_volume,
  CASE WHEN ratingStatus = "FAILURE" THEN (COALESCE(bytesIn, 0) + COALESCE(bytesOut, 0) - COALESCE(unapplied_bytes, 0)) ELSE 0 END AS failure_volume
  FROM (
    SELECT bcc,
      EXTRACT(MONTH FROM month_skey) AS mm,
      EXTRACT(YEAR FROM month_skey) AS yy,
      ban,
      subscriberId,
      bytesIn,
      bytesOut,
      ratingStatus,
      (SELECT COALESCE(SUM(COALESCE(una.usedServiceUnits,0)),0) FROM UNNEST(usageNotApplied) AS una) AS unapplied_bytes,
      RANK() OVER (PARTITION BY EXTRACT(YEAR FROM month_skey), EXTRACT(MONTH FROM month_skey), bcc, ban, subscriberId 
      ORDER BY rerateVersion DESC) as rerateVersion_rank -- get latest subscriber rerate version per bccmmyy and ban
    FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_arc_que_ratedusages_temp
    WHERE month_skey IN (DATE_TRUNC(CURRENT_DATE("America/Toronto"), MONTH), DATE_TRUNC(DATE_ADD(CURRENT_DATE("America/Toronto"), INTERVAL 1 MONTH), MONTH))
      AND source IN ("RATE", "RERATE") 
      AND ratingStatus IN ("SUCCESS","PARTIALLY_RATED", "FAILURE")
    )
  WHERE rerateVersion_rank = 1
),

-- KPI 7, 8, 9
failed_ccr AS (
SELECT 
  reject.cycle_code AS bcc,
  CAST(reject.cycle_run_month AS INT) AS mm,
  CAST(reject.cycle_run_year AS INT) AS yy,
  COALESCE(ATST, "unknown ATST") AS ATST,
  COUNT(DISTINCT subscribers_with_max_rerate_version.subscriberId) total_subscribers_marked_failed_by_odf,
  SUM(COALESCE(success_record, 0)) + SUM(COALESCE(partial_record, 0)) + SUM(COALESCE(failure_record, 0)) AS total_count_of_ccrs_related_to_failed_ban,
  SUM(COALESCE(success_record, 0)) AS total_count_of_success_ccrs_related_to_failed_ban,
  SUM(COALESCE(partial_record, 0)) AS total_count_of_partial_ccrs_related_to_failed_ban,
  SUM(COALESCE(failure_record, 0)) AS total_count_of_failure_ccrs_related_to_failed_ban,
  (SUM(COALESCE(success_volume, 0)) + SUM(COALESCE(partial_volume, 0)) + SUM(COALESCE(failure_volume, 0))) /1048576 AS total_volume_of_ccrs_related_to_failed_ban,
  SUM(COALESCE(success_volume, 0)) /1048576 AS total_volume_of_success_ccrs_related_to_failed_ban,
  SUM(COALESCE(partial_volume, 0)) /1048576 AS total_volume_of_partial_ccrs_related_to_failed_ban,
  SUM(COALESCE(failure_volume, 0)) /1048576 AS total_volume_of_failure_ccrs_related_to_failed_ban,
  reject.month_skey
FROM {{ project_id }}.{{ sr_esd_dataset }}.wnc_odf_que_unique_reject_summary_temp reject
LEFT JOIN subscribers_with_max_rerate_version
  ON reject.ban = subscribers_with_max_rerate_version.ban AND reject.cycle_code = subscribers_with_max_rerate_version.bcc 
    AND CAST(reject.cycle_run_month AS INT) = subscribers_with_max_rerate_version.mm AND CAST(reject.cycle_run_year AS INT) = subscribers_with_max_rerate_version.yy
  LEFT JOIN {{ project_id }}.{{ sr_esd_dataset }}.latest_ATST_by_using_ban_bccmmyy ru
  ON reject.ban = ru.ban AND reject.cycle_code = ru.bcc AND CAST(reject.cycle_run_month AS INT) = ru.mm AND CAST(reject.cycle_run_year AS INT) = ru.yy
  GROUP BY month_skey, yy, mm, bcc, ATST
),

-- KPI 10
successful_ban_rate AS (
  SELECT 
    -- Adding CASE WHEN because when total_bans_processed_by_odf & total_bans_marked_as_failed_by_odf = 0, 0/0 gives error. 0/1 = 0
    COALESCE((total_bans_processed_by_odf / (CASE WHEN (total_bans_processed_by_odf + coalesce(total_bans_marked_as_failed_by_odf, 0)) = 0 THEN 1 ELSE (total_bans_processed_by_odf + coalesce(total_bans_marked_as_failed_by_odf,0)) END)), 0) 
    AS rate_of_successful_bans,    
    COALESCE(daily_KPIs.ATST, failed_bans.ATST) as ATST, 
    COALESCE(daily_KPIs.bcc, failed_bans.bcc) AS bcc,
    COALESCE(daily_KPIs.mm, failed_bans.mm) AS mm,
    COALESCE(daily_KPIs.yy, failed_bans.yy) AS yy,
    COALESCE(daily_KPIs.month_skey, failed_bans.month_skey) AS month_skey
  FROM daily_KPIs 
  FULL OUTER JOIN failed_bans
  USING (month_skey, yy, mm, bcc, ATST)
)

-- Combine KPI 1 - 10
SELECT
  month_skey,
  COALESCE(total_bans_processed_by_odf, 0) AS total_bans_processed_by_odf,	
  COALESCE(total_subscribers_processed_by_odf, 0) AS total_subscribers_processed_by_odf,
  COALESCE(total_count_of_daily_records, 0) AS total_count_of_daily_records,
  COALESCE(total_volume_of_daily_records, 0) AS total_volume_of_daily_records,
  bcc,
  CAST(mm AS STRING) AS mm,
  CAST(yy AS STRING) AS yy,
  ATST,
  COALESCE(total_overage.total_overage, 0) AS total_overage,
  COALESCE(total_bans_marked_as_failed_by_odf, 0) AS total_bans_marked_as_failed_by_odf,
  COALESCE(total_subscribers_marked_failed_by_odf, 0) AS total_subscribers_marked_failed_by_odf,
  COALESCE(total_count_of_ccrs_related_to_failed_ban, 0) AS total_count_of_ccrs_related_to_failed_ban,
  COALESCE(total_count_of_success_ccrs_related_to_failed_ban, 0) AS total_count_of_success_ccrs_related_to_failed_ban,
  COALESCE(total_count_of_partial_ccrs_related_to_failed_ban, 0) AS total_count_of_partial_ccrs_related_to_failed_ban,
  COALESCE(total_count_of_failure_ccrs_related_to_failed_ban, 0) AS total_count_of_failure_ccrs_related_to_failed_ban,
  COALESCE(total_volume_of_ccrs_related_to_failed_ban, 0) AS total_volume_of_ccrs_related_to_failed_ban,
  COALESCE(total_volume_of_success_ccrs_related_to_failed_ban, 0) AS total_volume_of_success_ccrs_related_to_failed_ban,
  COALESCE(total_volume_of_partial_ccrs_related_to_failed_ban, 0) AS total_volume_of_partial_ccrs_related_to_failed_ban,
  COALESCE(total_volume_of_failure_ccrs_related_to_failed_ban, 0) AS total_volume_of_failure_ccrs_related_to_failed_ban,
  COALESCE(rate_of_successful_bans, 0) AS rate_of_successful_bans
FROM
  daily_KPIs
FULL OUTER JOIN
  total_overage
USING
  (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN
  failed_bans
USING
  (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN
  failed_ccr
USING
  (month_skey, yy, mm, bcc, ATST)
FULL OUTER JOIN
  successful_ban_rate
USING
  (month_skey, yy, mm, bcc, ATST)