"""
Module - expl-to-esd.py
"""

# *****************************************************
# INITIALIZATION
# *****************************************************

# import python libraries


import logging
import os
from datetime import datetime, timedelta

import yaml
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.utils.trigger_rule import TriggerRule


# *****************************************************
# CONFIGURATIONS
# *****************************************************

# Import configurations


current_dir = os.path.dirname(os.path.abspath(__file__))
configuration_file_path = os.path.join(current_dir, "config.yaml")
with open(configuration_file_path, encoding="utf-8") as yaml_file:
    configuration = yaml.safe_load(yaml_file)
domain = configuration["configs"]["domain"]
env = configuration["configs"]["env"]
use_case = configuration["configs"]["use_case"]
dataeng_project_id = configuration["configs"]["dataeng_project_id"]
relative_sql_path = configuration["configs"]["relative_sql_path"]
region = configuration["configs"]["region"]
impersonation_chain = configuration["configs"]["impersonation_chain"]
expl_dataset = configuration["configs"]["expl_dataset"]
esd_dataset = configuration["configs"]["esd_dataset"]
sql_path = os.path.join(
    os.path.dirname(os.path.dirname(current_dir)), relative_sql_path
)
schedule_interval = configuration["configs"]["schedule_interval"]


# log the config options that were passed in


logging.info("domain: " + domain)
logging.info("env: " + env)
logging.info("use_case: " + use_case)
logging.info("dataeng_project_id: " + dataeng_project_id)
logging.info("relative_sql_path: " + relative_sql_path)
logging.info("region: " + region)
logging.info("impersonation_chain: " + impersonation_chain)
logging.info("expl_dataset: " + expl_dataset)
logging.info("esd_dataset: " + esd_dataset)
logging.info("schedule_interval: " + schedule_interval)


# *****************************************************
# METHODS
# *****************************************************
# this read query file returns which query we want to read


def read_query_files(query_file):
    file_path = os.path.join(sql_path, (query_file + ".sql"))
    with open(file_path, encoding="utf-8") as file:
        query = file.read()
        query = (
            str(query)
            .replace("{{ project_id }}", dataeng_project_id)
            .replace("{{ sr_esd_dataset }}", esd_dataset)
            .replace("{{ sr_expl_dataset }}", expl_dataset)
        )
    return query


# *****************************************************
# DAG
# *****************************************************

# Default arguments for DAG


default_args = {
    "depends_on_past": False,  # Prevents future DAG run to fail if the previous run failed
    "dagrun_timeout": timedelta(hours=1),  # DAG timeout
    "location": region,
    "start_date": datetime(2024, 5, 30),
}

# Instantiate a DAG


dag = DAG(
    dag_id=f"{domain}-{env}-{region}-{use_case}-expl-to-esd",
    default_args=default_args,
    schedule_interval=schedule_interval,
    catchup=False,
)

# Define Operators


generate_staging_tables_all = BigQueryInsertJobOperator(
    task_id="generate_staging_tables_all",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("generate_staging_tables_all"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

generate_staging_table_ratedusages = BigQueryInsertJobOperator(
    task_id="generate_staging_table_ratedusages",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("generate_staging_table_ratedusages"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

generate_staging_tables_multi_dashboard = BigQueryInsertJobOperator(
    task_id="generate_staging_tables_multi_dashboard",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("generate_staging_tables_multi_dashboard"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

daily_reconciliation_without_atst = BigQueryInsertJobOperator(
    task_id="daily_reconciliation_without_atst",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("daily_reconciliation_without_atst"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

daily_reconciliation_with_atst = BigQueryInsertJobOperator(
    task_id="daily_reconciliation_with_atst",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("daily_reconciliation_with_atst"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

inmonth_usage_per_cycle_close = BigQueryInsertJobOperator(
    task_id="inmonth_usage_per_cycle_close",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("inmonth_usage_per_cycle_close"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

success_and_failure_insight = BigQueryInsertJobOperator(
    task_id="success_and_failure_insight",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("success_and_failure_insight"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

billed_rerate_insight = BigQueryInsertJobOperator(
    task_id="billed_rerate_insight",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("billed_rerate_insight"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

revenue_loss_report = BigQueryInsertJobOperator(
    task_id="revenue_loss_report",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("revenue_loss_report"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)

freezone = BigQueryInsertJobOperator(
    task_id="freezone",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("freezone"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=60),  # set timeout for operator
    impersonation_chain=impersonation_chain,
)


drop_staging_tables = BigQueryInsertJobOperator(
    task_id="drop_staging_tables",
    project_id=dataeng_project_id,
    gcp_conn_id=dataeng_project_id,
    configuration={
        "query": {
            "query": read_query_files("drop_staging_tables"),
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=10),  # set timeout for operator
    impersonation_chain=impersonation_chain,
    trigger_rule=TriggerRule.ALL_DONE,  # Regardless if the previous tasks succeed or fail, we want to delete the temp tables
)

await_tasks_completion = EmptyOperator(
    task_id="await_tasks_completion", dag=dag
)  # had to add this because we cannot do [list] >> [list] in task dependencies

# Define the task dependencies


([generate_staging_tables_all, generate_staging_table_ratedusages])
generate_staging_table_ratedusages >> generate_staging_tables_multi_dashboard
(
    [generate_staging_tables_all, generate_staging_tables_multi_dashboard]
    >> await_tasks_completion
    >> [
        daily_reconciliation_without_atst,
        inmonth_usage_per_cycle_close,
        success_and_failure_insight,
        revenue_loss_report,
        freezone,
    ]
)
(
    daily_reconciliation_without_atst
    >> daily_reconciliation_with_atst
    >> drop_staging_tables
)
(success_and_failure_insight >> billed_rerate_insight >> drop_staging_tables)
[
    inmonth_usage_per_cycle_close,
    revenue_loss_report,
    freezone,
] >> drop_staging_tables
