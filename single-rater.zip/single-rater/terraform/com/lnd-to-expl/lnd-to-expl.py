"""
Module - lnd-to-expl.py
"""

import logging

# ****************************************************
# STEP 1 - Importing library needed for the operations
# *****************************************************


import os
from datetime import datetime, timedelta

import yaml
from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from jinja2 import Template

# ****************************************************
# STEP 2 - Default Arguments
# *****************************************************


current_dir = os.path.dirname(
    os.path.abspath(__file__)
)  # get the directory of the current DAG file
configuration_file_path = os.path.join(
    current_dir, "config.yaml"
)  # join with config.yaml as the file path
with open(configuration_file_path, encoding="utf-8") as yaml_file:
    configuration = yaml.safe_load(yaml_file)  # loads the config file
domain = configuration["configs"]["domain"]  # get the domain value
env = configuration["configs"]["env"]  # get the env value
use_case = configuration["configs"]["use_case"]  # get the use_case value
dataeng_project_id = configuration["configs"][
    "dataeng_project_id"
]  # get the project ID where the data is in
region = configuration["configs"]["region"]  # get the region value
relative_sql_path = configuration["configs"][
    "relative_sql_path"
]  # get the path to the folder that stores all the sql files


landing_dataset = configuration["configs"][
    "landing_dataset"
]  # gets the branch specific landing dataset
expl_dataset = configuration["configs"][
    "expl_dataset"
]  # gets the branch specific expl dataset
wnc_arc_bell_usage_ingest_error_table_name = configuration["configs"][
    "wnc_arc_bell_usage_ingest_error_table_name"
]  # gets the table name for wnc_arc_bell_usage_ingest_error
bell_table_name = configuration["configs"][
    "bell_table_name"
]  # gets the table name for bell
wnc_arc_guided_ccr_table_name = configuration["configs"][
    "wnc_arc_guided_ccr_table_name"
]  # gets the table name for wnc_arc_guided_ccr
impersonation_chain = configuration["configs"][
    "impersonation_chain"
]  # service account to be impersonated
schedule_interval = configuration["configs"]["schedule_interval"]

# log the config options that were passed in


logging.info("Domain value: " + domain)
logging.info("Env value: " + env)
logging.info("Use Case value: " + use_case)
logging.info("Domain value: " + domain)
logging.info("Data Eng Project ID value: " + dataeng_project_id)
logging.info("Region value: " + region)
logging.info("Relative SQL Path value: " + relative_sql_path)
logging.info("Landing Dataset value: " + landing_dataset)
logging.info("Expl Dataset value: " + expl_dataset)
logging.info(
    "wnc_arc_bell_usage_ingest_error table name value: "
    + wnc_arc_bell_usage_ingest_error_table_name
)
logging.info("bell table name value: " + bell_table_name)
logging.info("wnc_arc_guided_ccr table name value: " + wnc_arc_guided_ccr_table_name)
logging.info("Impersonated Service Account value: " + impersonation_chain)
logging.info("schedule_interval: " + schedule_interval)

default_args = {
    "depends_on_past": False,  # Prevents future DAG run to fail if the previous run failed
    "start_date": datetime.now() - timedelta(days=1),
    "dagrun_timeout": timedelta(hours=1),  # Set DAG timeout
    "location": region,
}

# ****************************************************
# STEP 3 - Define DAG: Set ID and assign default args and schedule interval
# *****************************************************

# Instantiate a DAG


dag = DAG(
    dag_id=f"{domain}-{env}-{region}-{use_case}-lnd-to-expl",
    default_args=default_args,
    schedule_interval=schedule_interval,
    catchup=False,
)

# Read SQL files


sql_path = os.path.join(
    os.path.dirname(os.path.dirname(current_dir)), relative_sql_path
)
wnc_arc_bell_usage_ingest_error_file_path = os.path.join(
    sql_path, "wnc_arc_bell_usage_ingest_error.sql"
)  # join sql_path with sql file name to get full path to wnc_arc_bell_usage_ingest_error.sql file
bell_file_path = os.path.join(
    sql_path, "bell.sql"
)  # join sql_path with sql file name to get full path to bell.sql file
wnc_arc_guided_ccr_file_path = os.path.join(
    sql_path, "wnc_arc_guided_ccr.sql"
)  # join sql_path with sql file name to get full path to wnc_arc_guided_ccr.sql file

with open(wnc_arc_bell_usage_ingest_error_file_path, encoding="utf-8") as file:
    wnc_arc_bell_usage_ingest_error_query = (
        file.read()
    )  # read the SQL file for wnc_arc_bell_usage_ingest_error
    wnc_arc_bell_usage_ingest_error_template = Template(
        wnc_arc_bell_usage_ingest_error_query
    )  # Make the file a template to be evaluated for rendering values in placeholders
    wnc_arc_bell_usage_ingest_error_rendered_form = wnc_arc_bell_usage_ingest_error_template.render(
        project_id=dataeng_project_id,
        sr_expl_dataset=expl_dataset,
        sr_lnd_dataset=landing_dataset,
        wnc_arc_bell_usage_ingest_error_table_name=wnc_arc_bell_usage_ingest_error_table_name,
    )  # rendering the values into the placeholders
with open(bell_file_path, encoding="utf-8") as file:
    bell_query = file.read()  # read the SQL file for bell
    bell_query_template = Template(
        bell_query
    )  # Make the file a template to be evaluated for rendering values in placeholders
    bell_query_rendered_form = bell_query_template.render(
        project_id=dataeng_project_id,
        sr_expl_dataset=expl_dataset,
        sr_lnd_dataset=landing_dataset,
        bell_table_name=bell_table_name,
    )  # rendering the values into the placeholders
with open(wnc_arc_guided_ccr_file_path, encoding="utf-8") as file:
    wnc_arc_guided_ccr_query = file.read()  # read the SQL file for wnc_arc_guided_ccr
    wnc_arc_guided_ccr_query_template = Template(
        wnc_arc_guided_ccr_query
    )  # Make the file a template to be evaluated for rendering values in placeholders
    wnc_arc_guided_ccr_query_rendered_form = wnc_arc_guided_ccr_query_template.render(
        project_id=dataeng_project_id,
        sr_expl_dataset=expl_dataset,
        sr_lnd_dataset=landing_dataset,
        wnc_arc_guided_ccr_table_name=wnc_arc_guided_ccr_table_name,
    )  # rendering the values into the placeholders
# Define Operators


start_operator = DummyOperator(task_id="start", dag=dag)

wnc_arc_bell_usage_ingest_error_sql_call = BigQueryInsertJobOperator(
    task_id="wnc_arc_bell_usage_ingest_error_sql_call",
    project_id=dataeng_project_id,
    configuration={
        "query": {
            "query": wnc_arc_bell_usage_ingest_error_rendered_form,
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=10),
    gcp_conn_id=dataeng_project_id,
    impersonation_chain=impersonation_chain,
)

bell_sql_call = BigQueryInsertJobOperator(
    task_id="bell_sql_call",
    project_id=dataeng_project_id,
    configuration={"query": {"query": bell_query_rendered_form, "useLegacySql": False}},
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=10),
    gcp_conn_id=dataeng_project_id,
    impersonation_chain=impersonation_chain,
)

wnc_arc_guided_ccr_sql_call = BigQueryInsertJobOperator(
    task_id="wnc_arc_guided_ccr_sql_call",
    project_id=dataeng_project_id,
    configuration={
        "query": {
            "query": wnc_arc_guided_ccr_query_rendered_form,
            "useLegacySql": False,
        }
    },
    dag=dag,
    location=region,
    execution_timeout=timedelta(minutes=10),
    gcp_conn_id=dataeng_project_id,
    impersonation_chain=impersonation_chain,
)

end_operator = DummyOperator(task_id="end", dag=dag)

# Define the task dependencies


(
    start_operator
    >> [
        wnc_arc_bell_usage_ingest_error_sql_call,
        bell_sql_call,
        wnc_arc_guided_ccr_sql_call,
    ]
    >> end_operator
)
