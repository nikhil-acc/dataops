-- script for loading from LND to EXPL for wnc_wnc_arc_guided_ccr (PARTITIONED ON reporting_date (DAY), CLUSTER ON roamingIndicator)
DECLARE reporting_date_list ARRAY<DATE>;

BEGIN TRANSACTION;

##############################################################
# Create a temp table with 2 day of LND newly ingested data:
##############################################################
CREATE TEMP TABLE lnd_snapshot AS (
    SELECT
        DISTINCT
        subMarketId, 
        subscriberId, 
        ban, 
        xCorrelationId, 
        bytesIn, 
        imei, 
        ingested_on,
        bytesOut, 
        roamingIndicator, 
        createdDate, 
        carrierGroupId, 
        IMSI, 
        ratingGroup, 
        endTime, 
        mccmnc, 
        startTime, 
        startUDR, 
        msisdn, 
        usageType, 
        APN, 
        acctProvince, 
        sessionId,
        dt_skey,
        PARSE_DATE('%Y%m%d', LEFT(CAST(startTime AS STRING), 8)) AS reporting_date,
        TO_HEX(SHA256(TO_JSON_STRING(STRUCT(
            subMarketId, 
            subscriberId, 
            ban, 
            xCorrelationId, 
            bytesIn, 
            imei, 
            ingested_on,
            bytesOut, 
            roamingIndicator, 
            createdDate, 
            carrierGroupId, 
            IMSI, 
            ratingGroup, 
            endTime, 
            mccmnc, 
            startTime, 
            startUDR, 
            msisdn, 
            usageType, 
            APN, 
            acctProvince, 
            sessionId,
            dt_skey
        )))) AS hex_delta
    FROM {{ project_id }}.{{ sr_lnd_dataset }}.{{ wnc_arc_guided_ccr_table_name}}
    WHERE DATE(dt_skey) IN (DATE(CURRENT_TIMESTAMP()), DATE(DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)))
);


###################################################################
# Get the list of partitions needed for update (DAYs)
###################################################################
EXECUTE IMMEDIATE 
"""
SELECT ARRAY(SELECT distinct reporting_date FROM lnd_snapshot)
""" 
INTO reporting_date_list;


######################################
# Merge into EXPL using lnd_snapshot
######################################

MERGE {{ project_id }}.{{ sr_expl_dataset }}.{{ wnc_arc_guided_ccr_table_name}} EXPL
USING lnd_snapshot LND
ON EXPL.dt_skey = LND.reporting_date
AND EXPL.dt_skey IN UNNEST(reporting_date_list)
AND EXPL.hex_delta = LND.hex_delta
WHEN NOT MATCHED THEN
INSERT (
    subMarketId, 
    subscriberId, 
    ban, 
    xCorrelationId, 
    bytesIn, 
    imei, 
    ingested_on_lnd,
    bytesOut, 
    roamingIndicator, 
    createdDate, 
    carrierGroupId, 
    IMSI, 
    ratingGroup, 
    endTime, 
    mccmnc, 
    startTime, 
    startUDR, 
    msisdn, 
    usageType, 
    APN, 
    acctProvince, 
    sessionId,
    partition_col_lnd,
    dt_skey,
    hex_delta,
    ingested_on
)
VALUES (
    LND.subMarketId, 
    LND.subscriberId, 
    LND.ban, 
    LND.xCorrelationId, 
    LND.bytesIn, 
    LND.imei, 
    LND.ingested_on,
    LND.bytesOut, 
    LND.roamingIndicator, 
    LND.createdDate, 
    LND.carrierGroupId, 
    LND.IMSI, 
    LND.ratingGroup, 
    LND.endTime, 
    LND.mccmnc, 
    LND.startTime, 
    LND.startUDR, 
    LND.msisdn, 
    LND.usageType, 
    LND.APN, 
    LND.acctProvince, 
    LND.sessionId,
    LND.dt_skey,
    LND.reporting_date,
    LND.hex_delta,
    CURRENT_TIMESTAMP()
);

######################################
# Clean-up the temp table lnd_snapshot
######################################

DROP TABLE lnd_snapshot;

COMMIT TRANSACTION;
