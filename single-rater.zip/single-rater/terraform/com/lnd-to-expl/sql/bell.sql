-- script for loading from LND to EXPL for wnc_bell  (PARTITIONED ON reporting_date (DAY), CLUSTER ON roamingIndicator)
DECLARE reporting_date_list ARRAY<DATE>;

BEGIN TRANSACTION;

##############################################################
# Create a temp table with 2 day of LND newly ingested data:
##############################################################
CREATE TEMP TABLE lnd_snapshot AS (
    SELECT
        DISTINCT
        BAN, 
        subscriberType, 
        ratingGroup, 
        bytesOut, 
        externalSubId, 
        sessionId, 
        startUDR,
        featureSeqID, 
        bytesIn, 
        roamingIndicator, 
        mccmnc, 
        featureCode, 
        startTime, 
        APN, 
        transactionType, 
        duration, 
        MDN, 
        IMEI, 
        accountType, 
        endTime, 
        carrierGroupId, 
        bucketCode, 
        socId, 
        IMSI, 
        xCorrelationId, 
        firstMonthIndicator, 
        ingested_on,
        billCycleCode, 
        usageType, 
        accountSubType,
        dt_skey,
        PARSE_DATE('%Y%m%d', LEFT(CAST(startTime AS STRING), 8)) AS reporting_date,
        TO_HEX(SHA256(TO_JSON_STRING(STRUCT(
            BAN, 
            subscriberType, 
            ratingGroup, 
            bytesOut, 
            externalSubId, 
            sessionId, 
            startUDR,
            featureSeqID, 
            bytesIn, 
            roamingIndicator, 
            mccmnc, 
            featureCode, 
            startTime, 
            APN, 
            transactionType, 
            duration, 
            MDN, 
            IMEI, 
            accountType, 
            endTime, 
            carrierGroupId, 
            bucketCode, 
            socId, 
            IMSI, 
            xCorrelationId, 
            firstMonthIndicator, 
            ingested_on,
            billCycleCode, 
            usageType, 
            accountSubType,
            dt_skey
        )))) AS hex_delta
    FROM {{ project_id }}.{{ sr_lnd_dataset }}.{{ bell_table_name }}
    WHERE DATE(dt_skey) IN (DATE(CURRENT_TIMESTAMP()), DATE(DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)))
);


###################################################################
# Get the list of partitions needed for update (DAYs)
###################################################################
EXECUTE IMMEDIATE 
"""
SELECT ARRAY(SELECT distinct reporting_date FROM lnd_snapshot)
""" 
INTO reporting_date_list;


######################################
# Merge into EXPL using lnd_snapshot
######################################

MERGE {{ project_id }}.{{ sr_expl_dataset }}.{{ bell_table_name }} EXPL
USING lnd_snapshot LND
ON EXPL.dt_skey = LND.reporting_date
AND EXPL.dt_skey IN UNNEST(reporting_date_list)
AND EXPL.hex_delta = LND.hex_delta
WHEN NOT MATCHED THEN
INSERT (
    BAN, 
    subscriberType, 
    ratingGroup, 
    bytesOut, 
    externalSubId, 
    sessionId, 
    startUDR,
    featureSeqID, 
    bytesIn, 
    roamingIndicator, 
    mccmnc, 
    featureCode, 
    startTime, 
    APN, 
    transactionType, 
    duration, 
    MDN, 
    IMEI, 
    accountType, 
    endTime, 
    carrierGroupId, 
    bucketCode, 
    socId, 
    IMSI, 
    xCorrelationId, 
    firstMonthIndicator, 
    ingested_on_lnd,
    billCycleCode, 
    usageType, 
    accountSubType,
    partition_col_lnd,
    dt_skey,
    hex_delta,
    ingested_on
)
VALUES (
    LND.BAN, 
    LND.subscriberType, 
    LND.ratingGroup, 
    LND.bytesOut, 
    LND.externalSubId, 
    LND.sessionId, 
    LND.startUDR,
    LND.featureSeqID, 
    LND.bytesIn, 
    LND.roamingIndicator, 
    LND.mccmnc, 
    LND.featureCode, 
    LND.startTime, 
    LND.APN, 
    LND.transactionType, 
    LND.duration, 
    LND.MDN, 
    LND.IMEI, 
    LND.accountType, 
    LND.endTime, 
    LND.carrierGroupId, 
    LND.bucketCode, 
    LND.socId, 
    LND.IMSI, 
    LND.xCorrelationId, 
    LND.firstMonthIndicator, 
    LND.ingested_on,
    LND.billCycleCode, 
    LND.usageType, 
    LND.accountSubType,
    LND.dt_skey,
    LND.reporting_date,
    LND.hex_delta,
    CURRENT_TIMESTAMP()
);

######################################
# Clean-up the temp table lnd_snapshot
######################################

DROP TABLE lnd_snapshot;

COMMIT TRANSACTION;
