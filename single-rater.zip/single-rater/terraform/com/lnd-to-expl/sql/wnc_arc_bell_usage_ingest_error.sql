-- script for loading from LND to EXPL for nbd_wnc_arc_bell_usage_ingest_error (PARTITIONED ON reporting_date (DAY), CLUSTER ON roamingIndicator)
DECLARE reporting_date_list ARRAY<DATE>;

BEGIN TRANSACTION;

##############################################################
# Create a temp table with 2 day of LND newly ingested data:
##############################################################
CREATE TEMP TABLE lnd_snapshot AS (
    SELECT
        DISTINCT
        totalVolume,
        recordSequenceNumber,
        featureCode,
        servingNodeIp,
        errorCode,
        socId,
        servingNodePlmn,
        roamingZone,
        mccmnc,
        firstMonthIndicator,
        nfFqdn,
        subscriberType,
        chargingId,
        locationNcgi,
        payZoneFilter,
        ratingGroup,
        mdn,
        ratTypeString,
        sliceServiceDifferentiator,
        locationTac,
        imsi,
        ingested_on,
        nfIp,
        latestRetryTime,
        duration,
        nfPlmnId,
        xCorrelationId,
        startTime,
        payZoneInd,
        usageType,
        bytesOut,
        bytesIn,
        timestamp,
        sliceId,
        networkTriggerType,
        payZone,
        errorMessage,
        userIpV6,
        locationUeTimeZone,
        recordOpeningTime,
        sessionId,
        roamingIndicator,
        transactionType,
        retryCountTotal,
        ratTypeNumber,
        userIp,
        imei,
        endTime,
        qosId,
        qos5qi,
        startUDR,
        APN,
        dt_skey,
        PARSE_DATE('%Y%m%d', LEFT(CAST(startTime AS STRING), 8)) AS reporting_date,
        TO_HEX(SHA256(TO_JSON_STRING(STRUCT(
            totalVolume,
            recordSequenceNumber,
            featureCode,
            servingNodeIp,
            errorCode,
            socId,
            servingNodePlmn,
            roamingZone,
            mccmnc,
            firstMonthIndicator,
            nfFqdn,
            subscriberType,
            chargingId,
            locationNcgi,
            payZoneFilter,
            ratingGroup,
            mdn,
            ratTypeString,
            sliceServiceDifferentiator,
            locationTac,
            imsi,
            ingested_on,
            nfIp,
            latestRetryTime,
            duration,
            nfPlmnId,
            xCorrelationId,
            startTime,
            payZoneInd,
            usageType,
            bytesOut,
            bytesIn,
            timestamp,
            sliceId,
            networkTriggerType,
            payZone,
            errorMessage,
            userIpV6,
            locationUeTimeZone,
            recordOpeningTime,
            sessionId,
            roamingIndicator,
            transactionType,
            retryCountTotal,
            ratTypeNumber,
            userIp,
            imei,
            endTime,
            qosId,
            qos5qi,
            startUDR,
            APN,
            dt_skey
        )))) AS hex_delta
    FROM {{ project_id }}.{{ sr_lnd_dataset }}.{{ wnc_arc_bell_usage_ingest_error_table_name }}
    WHERE DATE(dt_skey) IN (DATE(CURRENT_TIMESTAMP()), DATE(DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)))
);


###################################################################
# Get the list of partitions needed for update (DAYs)
###################################################################
EXECUTE IMMEDIATE 
"""
SELECT ARRAY(SELECT distinct reporting_date FROM lnd_snapshot)
""" 
INTO reporting_date_list;


######################################
# Merge into EXPL using lnd_snapshot
######################################

MERGE {{ project_id }}.{{ sr_expl_dataset }}.{{ wnc_arc_bell_usage_ingest_error_table_name }} EXPL
USING lnd_snapshot LND
ON EXPL.dt_skey = LND.reporting_date
AND EXPL.dt_skey IN UNNEST(reporting_date_list)
AND EXPL.hex_delta = LND.hex_delta
WHEN NOT MATCHED THEN
INSERT (
    totalVolume,
    recordSequenceNumber,
    featureCode,
    servingNodeIp,
    errorCode,
    socId,
    servingNodePlmn,
    roamingZone,
    mccmnc,
    firstMonthIndicator,
    nfFqdn,
    subscriberType,
    chargingId,
    locationNcgi,
    payZoneFilter,
    ratingGroup,
    mdn,
    ratTypeString,
    sliceServiceDifferentiator,
    locationTac,
    imsi,
    ingested_on_lnd,
    nfIp,
    latestRetryTime,
    duration,
    nfPlmnId,
    xCorrelationId,
    startTime,
    payZoneInd,
    usageType,
    bytesOut,
    bytesIn,
    timestamp,
    sliceId,
    networkTriggerType,
    payZone,
    errorMessage,
    userIpV6,
    locationUeTimeZone,
    recordOpeningTime,
    sessionId,
    roamingIndicator,
    transactionType,
    retryCountTotal,
    ratTypeNumber,
    userIp,
    imei,
    endTime,
    qosId,
    qos5qi,
    startUDR,
    APN,
    partition_col_lnd,
    dt_skey,
    hex_delta,
    ingested_on
)
VALUES (
    LND.totalVolume,
    LND.recordSequenceNumber,
    LND.featureCode,
    LND.servingNodeIp,
    LND.errorCode,
    LND.socId,
    LND.servingNodePlmn,
    LND.roamingZone,
    LND.mccmnc,
    LND.firstMonthIndicator,
    LND.nfFqdn,
    LND.subscriberType,
    LND.chargingId,
    LND.locationNcgi,
    LND.payZoneFilter,
    LND.ratingGroup,
    LND.mdn,
    LND.ratTypeString,
    LND.sliceServiceDifferentiator,
    LND.locationTac,
    LND.imsi,
    LND.ingested_on,
    LND.nfIp,
    LND.latestRetryTime,
    LND.duration,
    LND.nfPlmnId,
    LND.xCorrelationId,
    LND.startTime,
    LND.payZoneInd,
    LND.usageType,
    LND.bytesOut,
    LND.bytesIn,
    LND.timestamp,
    LND.sliceId,
    LND.networkTriggerType,
    LND.payZone,
    LND.errorMessage,
    LND.userIpV6,
    LND.locationUeTimeZone,
    LND.recordOpeningTime,
    LND.sessionId,
    LND.roamingIndicator,
    LND.transactionType,
    LND.retryCountTotal,
    LND.ratTypeNumber,
    LND.userIp,
    LND.imei,
    LND.endTime,
    LND.qosId,
    LND.qos5qi,
    LND.startUDR,
    LND.APN,
    LND.dt_skey,
    LND.reporting_date,
    LND.hex_delta,
    CURRENT_TIMESTAMP()
);

######################################
# Clean-up the temp table lnd_snapshot
######################################

DROP TABLE lnd_snapshot;

COMMIT TRANSACTION;
