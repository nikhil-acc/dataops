#!/usr/bin/env bash

if [[ $# -lt 3 ]]
then echo "$(basename "$0") DOTENV_FILE VAR_NAME VALUE" 1>&2
     exit 1
fi

DOTENV_FILE="$1"
VAR_NAME="$2"
VAR_VALUE="$3"

if [[ -f $DOTENV_FILE ]] && grep -q "$VAR_NAME=" "$DOTENV_FILE"
then echo "Variable already set:"
     grep "$VAR_NAME=" "$DOTENV_FILE"
     echo "Replacing with:"
     echo "$VAR_NAME=$VAR_VALUE"
     sed -i "s|$VAR_NAME=.*\$|$VAR_NAME=$VAR_VALUE|" "$DOTENV_FILE"
else echo "$VAR_NAME=$VAR_VALUE" >> "$DOTENV_FILE"
fi