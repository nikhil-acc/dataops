# DataPlatform SFTP Module

## Table of Contents

* [Overview](#overview)
* [Prerequisites](#prerequisites)
* [CI/CD](#cicd)
* [Terraform Modules](#terraform-modules)
* [Helm Parameters](#helm-parameters)
* [Custom SFTP Users Configuration](#custom-sftp-users-configuration)
* [Contribution](#contribution)
* [Summary](#summary)


## Overview
The SFTP with GCS Integration application is designed to create and manage all resources required for secure SFTP access, including Kubernetes deployments, GCS buckets, a DNS record and other necessary configurations. This application uses the OpenSSH server to provide SFTP functionality and gcsfuse to mount Google Cloud Storage (GCS) buckets into the GKE cluster pods, allowing seamless interaction with cloud storage.

This module leverages Terraform and Helm for resource provisioning and management, ensuring a streamlined and automated deployment process. All necessary resources, including Kubernetes ConfigMaps, Secrets, Services, and Deployments, are configured through Helm charts, which can be easily customized to fit specific use cases.

The deployment and management of these resources are orchestrated through a CI pipeline, allowing for continuous integration and delivery of updates and configurations. This ensures that the SFTP service is always up-to-date and securely configured, providing reliable and efficient access to GCS-stored data via SFTP.


## Prerequisites

* Docker
* Terraform 1.5.0+
* openssh server 1:9.2p1-2+deb12u3
* gcsfuse 2.2.0
* Helm

## CI/CD
The CI pipeline for this project is configured to handle various stages of development, testing, and ephemeral deployment. This ensures a seamless process from code changes to production deployment.

### Branch Pipelines
The pipelines focus on testing and validating changes before they are merged into the main branch. The following stages are included in branch pipelines:

1. **Test**: Runs tests and static analysis tools to ensure code quality and security.
2. **Compliance**: Checks compliance with organizational policies and coding standards.
3. **Release**: Builds and release the Docker image and Terraform module.
5. **Terraform Plan**: Plans infrastructure changes without applying them.
6. **Terraform Apply**: Applies planned infrastructure changes to the production environment.
7. **Integration Test**: Runs final integration tests in the production environment.
8. **Terraform Destroy**: Optionally, destroys ephemeral infrastructure used for testing.

### Snapshots and Releases Artifact Repositories
Artifacts, including Helm charts and terraform code are pushed to different endpoints depending on whether they are snapshots or releases.

- npdaadp-terraform-snapshot
Snapshots are interim builds used for testing and integration purposes. They are automatically published during branch pipelines.
- npdaadp-terraform-release
Releases are stable versions intended for production use. They are created and published during release pipelines.

### Secret Management
Secrets are managed using HashiCorp Vault and injected into the pipeline using GitLab CI/CD's secret management features. This ensures secure handling of sensitive data such as SSH keys.


## Terraform Modules
This repository contains Terraform configurations for managing GCS buckets, Kubernetes, secrets, service accounts, a DNS record and deploying Helm charts in a GCP environment.

### Variables

| Variable                   | Description                                                                                                          | Optional | Default                             |
| -------------------------- | -------------------------------------------------------------------------------------------------------------------- | -------- | ----------------------------------- |
| `buckets_data`             | A map of objects for defining multiple buckets per use case. The map key is a bucket suffix, e.g., "raw-01".         | Yes      | `{}`                                |
| `service_account_email`    | Service account email to be used for all resources                                                                   | No       |                                     |
| `project_id`               | GCP project ID                                                                                                       | No       |                                     |
| `domain`                   | Business domain name                                                                                                 | No       |                                     |
| `env`                      | Environment name                                                                                                     | No       |                                     |
| `force_delete_data`        | Force delete data                                                                                                    | Yes      | `false`                             |
| `owner_primary_pein`       | Primary owner                                                                                                        | No       |                                     |
| `owner_secondary_pein`     | Secondary owner                                                                                                      | No       |                                     |
| `gitlab_project`           | GitLab project                                                                                                       | No       |                                     |
| `gke_cluster_name`         | The name of the Kubernetes cluster                                                                                   | No       |                                     |
| `kub_namespace`            | Kubernetes namespace                                                                                                 | No       |                                     |
| `kub_sa`                   | Kubernetes service account name                                                                                      | No       |                                     |
| `static_internal_ip`       | The static internal IP address                                                                                       | No       | ``                     |
| `subnetwork`               | The subnetwork for the static IP                                                                                      | No       | `projects/prj-netw-dev-nane1-gke-01/regions/northamerica-northeast1/subnetworks/snet-npda-nane1-dev-01` |
| `address_type`             | The static internal IP address type                                                                                  | No       | `INTERNAL`                          |
| `static_ip_name`           | Name of the static IP                                                                                                 | No       | `ip-sftp-internal`                  |
| `dns_host`                 | If set, a DNS record with a name equal to \<dns_host\>.services-\<env\>-edp.gcp.int.bell.ca. is provisioned and mapped to static_ip_name or to the IP set by the Google API  | Yes       | ``                                   |
| `users`                    | List of users with details for SFTP access                                                                            | No       |                                     |
| `service_port`             | Port for the Kubernetes service                                                                                      | Yes      | `2022`                              |
| `image_repository`         | Docker image repository                                                                                              | Yes      | `default_repository`                |
| `image_tag`                | Docker image tag                                                                                                     | Yes      | `latest`                            |
| `resources_requests_memory`| Memory requests for the container                                                                                    | Yes      | `256Mi`                             |
| `resources_requests_cpu`   | CPU requests for the container                                                                                       | Yes      | `100m`                              |
| `resources_limits_memory`  | Memory limits for the container                                                                                      | Yes      | `512Mi`                             |
| `resources_limits_cpu`     | CPU limits for the container                                                                                         | Yes      | `500m`                              |
| `deployment_replicacount`  | Number of replicas for deployment                                                                                    | Yes      | `1`                                 |
| `deployment_maxsurge`      | Maximum surge for deployment                                                                                         | Yes      | `1`                                 |
| `deployment_maxunavailable`| Maximum unavailable replicas for deployment                                                                          | Yes      | `0`                                 |
| `helm_release_version`     | Helm release version                                                                                                 | No       |                                     |

### Bucket Object Structure

All object's fields are mandatory and don't have default values:

| Variable                     | Description                                                                                                          |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `region`                     | Bucket region, allowed values are `nane1` and `nane2`.                                                               |
| `storage_class`              | Bucket storage class: `STANDARD`, `REGIONAL`, `NEARLINE`, `COLDLINE`, `ARCHIVE`. See [documentation](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket#storage_class) for more details. |
| `versioning`                 | Enables objects versioning.                                                                                          |
| `data_tier`                  | Data tier, possible values: `raw`, `temp`, `lnd`, `expl`, `esd`.                                                     |
| `lifecycle_rules`            | The list of predefined lifecycle rules, e.g., "retention-14days" - data retention of 14 days. Existing lifecycle rules are defined in [locals.tf](locals.tf). If the rule you need is missing, you can create it and submit a merge request. |
| `external_access`            | List of permissions to be granted to xfer account on the bucket. Follow the principle of least required privileges. Don't grant storage admin if external application needs only object creator. Full list of storage roles can be found in the [official documentation](https://cloud.google.com/iam/docs/understanding-roles#cloud-storage-roles). |


## Helm Parameters

The following table lists the configurable parameters of the SFTP-GCS chart and their default values.

| Parameter                        | Description                                                                                              | Default                                |
|----------------------------------|----------------------------------------------------------------------------------------------------------|----------------------------------------|
| `namespace`                      | Kubernetes namespace where the resources will be created                                                 | `default`                              |
| `image.repository`               | Docker image repository                                                                                  | `your-docker-repo/sftp-gcs`            |
| `image.tag`                      | Docker image tag                                                                                         | `latest`                               |
| `image.pullPolicy`               | Docker image pull policy                                                                                 | `Always`                               |
| `serviceAccountName`             | Kubernetes service account name                                                                          | `sftp-gcs-sa`                          |
| `users`                          | List of users for SFTP access with their configurations                                                  | `[]`                                   |
| `deployment.replicaCount`        | Number of replicas for the deployment                                                                    | `1`                                    |
| `deployment.strategy`            | Deployment strategy type                                                                                 | `RollingUpdate`                        |
| `deployment.maxUnavailable`      | Maximum unavailable replicas during update                                                               | `0`                                    |
| `deployment.maxSurge`            | Maximum surge during update                                                                              | `1`                                    |
| `resources`                      | Resource requests and limits for the container                                                           | `{}`                                   |
| `service.type`                   | Type of Kubernetes service                                                                               | `ClusterIP`                            |
| `service.port`                   | Port for the Kubernetes service                                                                          | `2022`                                 |
| `service.loadBalancerIP`         | Static IP for the service (if type is LoadBalancer)                                                      | `nil`                                  |
| `podAnnotations`                 | Annotations for the pods                                                                                 | `{}`                                   |
| `imagePullSecrets`               | Secrets for Docker image registry credentials                                                            | `[]`                                   |
| `nodeSelector`                   | Node selector for pod scheduling                                                                         | `{}`                                   |
| `affinity`                       | Affinity settings for pod scheduling                                                                     | `{}`                                   |
| `tolerations`                    | Tolerations for pod scheduling                                                                           | `[]`                                   |
| `livenessProbe`                  | Liveness probe configuration                                                                             | `{}`                                   |
| `readinessProbe`                 | Readiness probe configuration                                                                            | `{}`                                   |
| `podSecurityContext`             | Security context for the pod                                                                             | `{}`                                   |
| `securityContext`                | Security context for the container                                                                       | `{}`                                   |

## Custom SFTP Users Configuration

The `users` parameter allows you to define multiple users for SFTP access. Each user should have the following structure:

| Parameter       | Description                                                |
|-----------------|------------------------------------------------------------|
| `user`          | Username for the SFTP user                                 |
| `uid`           | User ID for the SFTP user                                  |
| `bucket`        | GCS bucket to mount for the user                           |
| `onlyDir`       | Specific directory within the GCS bucket to mount          |
| `vault_public_key` | Path to the Vault secret containing the user's public key  |

**Note:** The `vault_public_key` field should contain the path to the Vault secret that holds the user's public key. Terraform will pull the key from Vault and create a file with the public key text for each user.

### Example

```yaml
users:
  - user: "user1"
    uid: 1001
    vault_public_key: "cross-platform-tooling/data/deployment/datapltf-modules/38857/datapltf-sftp-module/46716/dev/sftp/user_1_keys"
    bucket: "my-gcs-bucket"
    onlyDir: "dir1"
  - user: "user2"
    uid: 1002
    vault_public_key: "cross-platform-tooling/data/deployment/datapltf-modules/38857/datapltf-sftp-module/46716/dev/sftp/user_2_keys"
    bucket: "my-gcs-bucket"
    onlyDir: "dir2"
```

## Contribution
Make your changes in the feature branch and merge to master only when everything is tested and working. Master must always be clean and run without errors. Pipeline is configured to run on master or when merge request targets master or when commit is added to merge request that targets master.

## Summary:
This SFTP application uses the OpenSSH server for secure file transfer and gcsfuse to mount Google Cloud Storage (GCS) buckets into GKE cluster pods.

The deployment creates an SFTP server in the Kubernetes cluster.
Each user is configured with specific GCS buckets mounted to their /ftp directory using gcsfuse.
User configurations and SSH keys are managed through Kubernetes ConfigMaps and Secrets.
The Helm chart allows customizable parameters, such as image repository, service configurations, and user-specific settings.
The CI pipeline automates the deployment, ensuring continuous integration and deploy to ephemeral environment.
