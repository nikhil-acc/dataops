import os
import subprocess

import paramiko
import pytest
from google.cloud import storage
from sftp_operations import (
    connect_sftp,
    create_directory,
    get_file,
    list_directory,
    put_file,
    remove_directory,
    remove_file,
)


@pytest.fixture(scope="module")
def sftp_client(sftp_config):
    ssh, sftp = connect_sftp(
        sftp_config["hostname"],
        sftp_config["port"],
        sftp_config["username"],
        sftp_config["primary_key_path"],
    )
    yield sftp
    sftp.close()
    ssh.close()


@pytest.fixture(scope="module")
def secondary_sftp_client(sftp_config):
    ssh, sftp = connect_sftp(
        sftp_config["hostname"],
        sftp_config["port"],
        sftp_config["username"],
        sftp_config["secondary_key_path"],
    )
    yield sftp
    sftp.close()
    ssh.close()


@pytest.fixture(scope="module")
def gcs_client():
    return storage.Client()


def test_only_sftp_allowed(sftp_config):
    command = [
        "ssh",
        "-i",
        sftp_config["primary_key_path"],
        "-p",
        str(sftp_config["port"]),
        f"{sftp_config['username']}@{sftp_config['hostname']}",
    ]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert "Host key verification failed." in result.stderr.decode("utf-8")


def test_user_jailed_to_ucrf(sftp_client, sftp_config):
    sftp_client.chdir(sftp_config["ucrf_path"])
    remote_working_directory = sftp_client.getcwd()
    assert remote_working_directory == sftp_config["ucrf_path"]


def test_put_file(sftp_client, sftp_config):
    remote_path = os.path.join(sftp_config["ucrf_path"], sftp_config["put_me_file"])
    remote_path_overide = os.path.join(
        sftp_config["ucrf_path"], sftp_config["override_me_file"]
    )
    remote_path_list = os.path.join(
        sftp_config["ucrf_path"], sftp_config["list_me_file"]
    )
    remote_path_gcs = os.path.join(
        sftp_config["ucrf_path"], sftp_config["gcs_remove_me_file"]
    )
    try:
        sftp_client.remove(remote_path)
    except FileNotFoundError:
        pass
    with open(sftp_config["put_me_file"], "w") as f:
        f.write("This is a test file.")
    put_file(sftp_client, sftp_config["put_me_file"], remote_path)
    put_file(sftp_client, sftp_config["override_me_file"], remote_path_overide)
    put_file(sftp_client, sftp_config["list_me_file"], remote_path_list)
    put_file(sftp_client, sftp_config["gcs_remove_me_file"], remote_path_gcs)
    assert sftp_config["put_me_file"] in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )


def test_override_file(sftp_client, sftp_config):
    remote_path = os.path.join(
        sftp_config["ucrf_path"], sftp_config["override_me_file"]
    )
    assert sftp_config["override_me_file"] in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )
    with open(sftp_config["override_me_file"], "w") as f:
        f.write("Initial content.")
    put_file(sftp_client, sftp_config["override_me_file"], remote_path)
    get_file(sftp_client, remote_path, sftp_config["override_me_file"])
    with open(sftp_config["override_me_file"], "r") as f:
        content = f.read()
    assert content == "Initial content."
    with open(sftp_config["override_me_file"], "w") as f:
        f.write("New content.")
    put_file(sftp_client, sftp_config["override_me_file"], remote_path)
    get_file(sftp_client, remote_path, sftp_config["override_me_file"])
    with open(sftp_config["override_me_file"], "r") as f:
        new_content = f.read()
    assert new_content == "New content."
    files_in_ucrf = list_directory(sftp_client, sftp_config["ucrf_path"])
    assert files_in_ucrf.count(sftp_config["override_me_file"]) == 1


def test_remove_file(sftp_client, sftp_config):
    remote_path = os.path.join(
        sftp_config["ucrf_path"], sftp_config["sftp_remove_me_file"]
    )
    put_file(sftp_client, sftp_config["sftp_remove_me_file"], remote_path)
    assert sftp_config["sftp_remove_me_file"] in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )
    remove_file(sftp_client, remote_path)
    files_in_ucrf = list_directory(sftp_client, sftp_config["ucrf_path"])
    assert sftp_config["sftp_remove_me_file"] not in files_in_ucrf


def test_list_directory(sftp_client, sftp_config, gcs_client):
    remote_path = os.path.join(sftp_config["ucrf_path"], sftp_config["list_me_file"])
    assert sftp_config["list_me_file"] in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )


def test_gcs_remove_file(sftp_client, sftp_config, gcs_client):
    remote_path = os.path.join(
        sftp_config["ucrf_path"], sftp_config["gcs_remove_me_file"]
    )
    bucket_name = sftp_config["bucket_name"]
    gcs_path = f"Hadoopshare/ExtUpload/FB1/{sftp_config['gcs_remove_me_file']}"
    bucket = gcs_client.bucket(bucket_name)
    blob = bucket.blob(gcs_path)
    assert blob.exists()
    blob.delete()
    files = list_directory(sftp_client, sftp_config["ucrf_path"])
    assert sftp_config["gcs_remove_me_file"] not in files


def test_create_directory(sftp_client, sftp_config):
    remote_path = os.path.join(
        sftp_config["ucrf_path"], sftp_config["create_me_folder"]
    )
    try:
        remove_directory(sftp_client, remote_path)
    except FileNotFoundError:
        pass
    create_directory(sftp_client, remote_path)
    assert sftp_config["create_me_folder"] in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )


def test_remove_directory(sftp_client, sftp_config):
    remote_path = os.path.join(
        sftp_config["ucrf_path"], sftp_config["remove_me_folder"]
    )
    create_directory(sftp_client, remote_path)
    assert sftp_config["remove_me_folder"] in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )
    remove_directory(sftp_client, remote_path)
    assert sftp_config["remove_me_folder"] not in list_directory(
        sftp_client, sftp_config["ucrf_path"]
    )


def test_put_file_with_secondary_key(secondary_sftp_client, sftp_config):
    remote_path = os.path.join(sftp_config["ucrf_path"], sftp_config["put_me_file"])
    try:
        secondary_sftp_client.remove(remote_path)
    except FileNotFoundError:
        pass
    with open(sftp_config["put_me_file"], "w") as f:
        f.write("This is a test file with secondary sftp client.")
    put_file(secondary_sftp_client, sftp_config["put_me_file"], remote_path)
    assert sftp_config["put_me_file"] in list_directory(
        secondary_sftp_client, sftp_config["ucrf_path"]
    )


def test_user_not_authenticated(sftp_config, valid_users):
    if sftp_config["nonexistent_user"] not in valid_users:
        print("User fails to authenticate to the SFTP server.")
        return
    with pytest.raises(paramiko.ssh_exception.AuthenticationException):
        connect_sftp(
            sftp_config["hostname"],
            sftp_config["port"],
            sftp_config["nonexistent_user"],
            sftp_config["primary_key_path"],
        )


def test_block_password_authentication(sftp_config):
    with pytest.raises(paramiko.ssh_exception.AuthenticationException):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            sftp_config["hostname"],
            port=sftp_config["port"],
            username=sftp_config["username"],
            password=sftp_config["password"],
        )
