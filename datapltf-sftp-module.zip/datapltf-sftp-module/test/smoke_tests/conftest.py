import pytest


def pytest_addoption(parser):
    parser.addoption(
        "--hostname",
        action="store",
        default="35.203.4.234",
        help="SFTP server hostname",
    )
    parser.addoption(
        "--port", action="store", default=2022, type=int, help="SFTP server port"
    )
    parser.addoption(
        "--username", action="store", default="sftpuser1", help="SFTP username"
    )
    parser.addoption(
        "--primary_key_path",
        action="store",
        default="ssh_key_sftpuser1",
        help="Path to primary SSH key",
    )
    parser.addoption(
        "--secondary_key_path",
        action="store",
        default="ssh_key_sftpuser1",
        help="Path to secondary SSH key",
    )
    parser.addoption(
        "--ucrf_path", action="store", default="/ftp", help="User-chroot folder path"
    )
    parser.addoption(
        "--put_me_file",
        action="store",
        default="put-me.txt",
        help="Specify the name of the file to be put in ucrf.",
    )
    parser.addoption(
        "--override_me_file",
        action="store",
        default="override-me.txt",
        help="Specify the name of the file to test override.",
    )
    parser.addoption(
        "--list_me_file",
        action="store",
        default="list-me.txt",
        help="Specify the name of the file to list.",
    )
    parser.addoption(
        "--gcs_remove_me_file",
        action="store",
        default="gcs-remove-me.txt",
        help="Specify the name of the file to remove from gcs.",
    )
    parser.addoption(
        "--sftp_remove_me_file",
        action="store",
        default="sftp-remove-me.txt",
        help="Specify the name of the file to remove.",
    )
    parser.addoption(
        "--create_me_folder",
        action="store",
        default="create-me",
        help="Create folder name",
    )
    parser.addoption(
        "--remove_me_folder",
        action="store",
        default="sftp-remove-me",
        help="Remove folder name",
    )
    parser.addoption(
        "--nonexistent_user",
        action="store",
        default="i-dont-exist",
        help="Non-existent username for authentication test",
    )
    parser.addoption(
        "--password",
        action="store",
        default=False,
        help="Specify if password authentication test should be run",
    )
    parser.addoption(
        "--bucket_name",
        action="store",
        default="first-sftp-bucket",
        help="Specify the GCS bucket name",
    )


@pytest.fixture(scope="module")
def sftp_config(request):
    return {
        "hostname": request.config.getoption("--hostname"),
        "port": request.config.getoption("--port"),
        "username": request.config.getoption("--username"),
        "primary_key_path": request.config.getoption("--primary_key_path"),
        "secondary_key_path": request.config.getoption("--secondary_key_path"),
        "ucrf_path": request.config.getoption("--ucrf_path"),
        "put_me_file": request.config.getoption("--put_me_file"),
        "override_me_file": request.config.getoption("--override_me_file"),
        "list_me_file": request.config.getoption("--list_me_file"),
        "gcs_remove_me_file": request.config.getoption("--gcs_remove_me_file"),
        "sftp_remove_me_file": request.config.getoption("--sftp_remove_me_file"),
        "create_me_folder": request.config.getoption("--create_me_folder"),
        "remove_me_folder": request.config.getoption("--remove_me_folder"),
        "nonexistent_user": request.config.getoption("--nonexistent_user"),
        "password": request.config.getoption("--password"),
        "bucket_name": request.config.getoption("--bucket_name"),
    }


@pytest.fixture(scope="module")
def valid_users():
    with open("users.txt", "r") as f:
        return [line.strip() for line in f.readlines()]
