import paramiko


def connect_sftp(hostname, port, username, private_key_path):
    private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, port=port, username=username, pkey=private_key)
    return ssh, ssh.open_sftp()


def put_file(sftp, local_path, remote_path):
    sftp.put(local_path, remote_path)


def get_file(sftp, remote_path, local_path):
    sftp.get(remote_path, local_path)


def remove_file(sftp, remote_path):
    sftp.remove(remote_path)


def list_directory(sftp, remote_path):
    return sftp.listdir(remote_path)


def create_directory(sftp, remote_path):
    sftp.mkdir(remote_path)


def remove_directory(sftp, remote_path):
    sftp.rmdir(remote_path)
