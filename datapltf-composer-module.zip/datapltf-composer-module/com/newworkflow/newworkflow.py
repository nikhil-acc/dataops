'''
Description : DAG to ingest data from realtime to historical tables for pcrf usecase
Author: Gunjan
Date : 20/04/2022
Modified Date : 25/04/2022
Usage: DAG file and config.yaml will be placed in the dags folder
(respective composer folder structure) dependency files such as .sql files
will be placed in the data/SQL folder
Documentation : Detailed documentation , usage and steps to modify
DAG will be explained in the SOP document created '''

# ****************************************************
# STEP 1 - Importing library needed for the operations
# *****************************************************
import airflow
import os
from airflow import DAG
from airflow import models
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
from airflow.contrib.operators.gcs_to_bq import GoogleCloudStorageToBigQueryOperator
from airflow.models import Variable
import yaml
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryCheckOperator,
    BigQueryCreateEmptyDatasetOperator,
    BigQueryCreateEmptyTableOperator,
    BigQueryDeleteDatasetOperator,
    BigQueryGetDataOperator,
    BigQueryInsertJobOperator,
    BigQueryIntervalCheckOperator,
    BigQueryValueCheckOperator,
)
# ****************************************************
# STEP 2 - Default Arguments
# *****************************************************
default_args = {
    'owner': 'test-project-npe',
    'depends_on_past': False,
    'start_date': airflow.utils.dates.days_ago(1),
    'email': ['Your email address'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=2),

}

# ****************************************************
# STEP 3 - Define DAG: Set ID and assign default args and schedule interval
# *****************************************************
my_dir = os.path.dirname(os.path.abspath(__file__))
configuration_file_path = os.path.join(my_dir, "config.yaml")
with open(configuration_file_path) as yaml_file:
    configuration = yaml.safe_load(yaml_file)

    print(configuration['configs']['project_id'])
    print(configuration['configs']['zone'])
    print(configuration['configs']['gs_bucket'])
    print(configuration['configs']['sqlpath'])

project_id = configuration['configs']['project_id']
gs_bucket = configuration['configs']['gs_bucket']

with DAG('pcrf-realtime_to_history_withconfig', schedule_interval='0 9 * * *',
         template_searchpath=['/home/airflow/gcs/data/'],
         max_active_runs=1, catchup=True, default_args=default_args) as dag:

    start_pipeline = DummyOperator(
        task_id='start_pipeline',
        dag=dag)

    check_count = BigQueryCheckOperator(
        task_id="check_count",
        sql="SELECT COUNT(*) FROM (SELECT 1 AS ONE)",
        use_legacy_sql=False,
        location=configuration['configs']['zone'],
    )
    print("BigQuery Check Successful")
    check_value = BigQueryValueCheckOperator(
        task_id="check_value",
        sql="SELECT COUNT(*) FROM (SELECT 1 AS ONE)",
        pass_value=4,
        use_legacy_sql=False,
        location=configuration['configs']['zone'],
    )

    insert_realtime_to_history = BigQueryOperator(
        task_id='insert_realtime_to_history',
        sql=configuration['configs']['sqlpath'],
        # destination_dataset_table='project-name.DataSetName.TableName${{ds_nodash}}',
        write_disposition='WRITE_APPEND',
        bigquery_conn_id='bigquery_default',
        location=configuration['configs']['zone'],
        use_legacy_sql=False,
        dag=dag
    )
    finish_pipeline = DummyOperator(
        task_id='finish_pipeline',
        dag=dag)

# Task dependencies
start_pipeline >> check_count >> check_value >> insert_realtime_to_history >> finish_pipeline
