# Composer

BigQuery operator by default uses compute from the same project where Airflow is deployed. Ingestion workflow should always use compute from dataeng project, so we create connection from Airflow to dataeng project, connection name is the same as dataeng project name. If you forget to specify connection for BQ operator then your workflow fails, because use case service account has to privileges to run BQ jobs in airflow GCP project.

<a name="com-folders"/>

#### Folders

<a name="com-folders"/>

The composer workflow source code structure is as follows:

```
.
├── com
│   └── dag1
│     └── config.yaml
      └── sql-name.sql
│     └── dag1.py
│   └── dag2
│     └── config.yaml
│     └── dag2.py
│     └── sql
│         └── sql-name.sql
```

All composer workflow source code should be placed under `com` folder in the gitlab project repo.
  - The first level subfolders are the composer workflow names. These names should match the keys used in the "composer_workflow" variable.

In each dag subfolder there are 3 types of files:

- Exactly one `.py` file whose name matches the dag subfolder name. All the dag code should be in this file. It is uploaded into the Cloud Composer bucket `dags/DAG_NAME/` folder.
- One or more `.sql` files to be used by the dag `.py` code. These .sql files can be placed next to the code or in an sql/ directory for cleaner organization. They will be uploaded into the `data/DAG_NAME/sql/` subfolder in the composer bucket.
- One `config.yaml` file which is a terraform template used to pass terraform apply time values to the composer dags. Avoid 
hardcoding static values and instead make use of the terraform template variables such as `tf_env`. By using terraform template variables, the config will be valid in any environment. If more variables are required, contact the common module development team. Below is the list of terraform template variables availble to your config.yaml ([Example config.yaml](df/newworkflow/config.yaml)).

```
tf_airflow_project
tf_dataeng_project
tf_domain
tf_env
tf_region
tf_short_region
tf_use_case
tf_com_bucket 
tf_com_dag
tf_custom_parameters
```

<a name="com-variables"/>

#### Variables

| Variable | Description | Optional | Default   |
| ----------------- | ------------------------------------- | -------- | --------- |
| `composer_environment_name` | Name of the target composer environment. | No |  |
| `composer_workflows` | Map of DAG_NAME to custom parameters. The custom parameters will be available to the config.yaml as `tf_custom_parameters` terraform template variable. | Yes | `{}` |
| `com_path` | Optional path to where the com/ files are located. | Yes | `${path.root}` |
