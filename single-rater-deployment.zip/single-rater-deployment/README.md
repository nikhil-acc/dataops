# Overview
This repo contains all the automation for deploying single-rater to the different environments.

## Failover Data Storage Transition
In the event of a failover, data storage will be shifted from the primary source location in Quebec to a backup location in Ontario. This transition ensures continued data accessibility and operational resilience. To initiate the failover, update the `source_location` variable in the `main.tf` file. Specifically, change the `source_location` value from "QUE" to "ONT." Additionally, update the `bootstrap_servers` to match the Ontario location to ensure that the data and application services are correctly routed to the new servers. These configuration changes will redirect data requests and storage services to Ontario, facilitating a seamless transition during the failover event.

*Example Update in `main.tf`:
 "source_location" = "ont"  # Change from "QUE" to "ONT" during failover

 "bootstrap_servers" = ["ont-server-1", "ont-server-2"] 
*

list of servers according to different environment can be found form the document here [here](https://confluence.bell.corp.bce.ca/pages/viewpage.action?pageId=854678982&preview=%2F854678982%2F866375630%2Fsingle-rater-kafka-prod-guide.docx)
