## Project Description

This project was created by a scaffolder. It builds a GCS bucket in GCP project. 
The data engineer is expected to provide his own business logic make adjustments to the project.
